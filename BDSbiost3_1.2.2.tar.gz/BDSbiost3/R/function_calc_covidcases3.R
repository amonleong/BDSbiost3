###########################################################################################
#funcion de densidad de casos y de distribucion (acumulados) y su analisis
######################################################################################
######################################################################################
# MODELO AD-HOC BASADO EN MODELO PARAMETRICO WEIBULL + NORMAL + LOESS
# PERMITE PREDECIR CASOS DE PERSONAS AFECTADAS POR COVID-19
#####################################################################################




#toni monleon (15-04-2020) #modificacion de la ver3 en 12-4-20

##################################################################################################
# FUNCTION TO CALCULATE CASES AND CUM CASES OF COVID-19 PANDEMIA
#################################################################################################
#' FUNCTION TO CALCULATE CASES AND CUM CASES OF COVID-19 PANDEMIA USING A PARAMETRIC MODEL AND LOESS
#'
#' @param X day number
#' @param Y cases affected by disease
#' @param max.cases.free parameter a (asymptote value) free value (max.cases.free=F)
#' @param max.cases value of parameter a (aymptote) defect= 8000
#' @param sdv_dias1 value of sdv of days for the model (descent part)
#' @param rest99.1 value of sdv of days for the model (plateau part)
#' @param lim.days number of days to represent (temporal horizon)
#' @param iterations number of iterations in the nlr calculations
#' @param label.ind label for the plot
#' @return plot and calculations related with time and projection in time
#' @export
#'
#' @examples
#' #COVID19 cases in Spain (February-April 2020)
#' COVID19.Spain<- data.frame(n.day=  seq(1:48),
#'                           Cases = c(0,    0,    0,    0,    1,    7,    6,   13,   14,   22,   48,   35,   46,   44,  126,   22,  140,  480,
#'                                     600,  511,  812, 1201, 1714, 1854, 1451, 2029, 2538, 3431, 2833, 4946, 3646, 4517, 6584, 7937, 8578, 7871,
#'                                     8189, 6549, 6398, 9222, 7719, 8102, 7472, 7026, 6023, 4273, 5478, 6180) )
#' plot(COVID19.Spain$n.day,COVID19.Spain$Cases, xlim=c(0,100), col="red", main="Projection plot and parameters estimation", sub="using a Weibull function 4p")

#' #Predict evolution of cases in Spain with an "ad-hoc" model ()
#' pred.Casos.diarios<-covid.cases.cumcases2(X=COVID19.Spain$n.day, Y=COVID19.Spain$Cases, max.cases.free=T, max.cases = max(COVID19.Spain$Cases), lim.days=100,iterations = 20, label.ind="SPAIN: PREDICTION COVID-19 (DAY1: 20/2/2020)", duration_pandemic=200)
#' @references
#'
#' Monleon-Getino, T; Canela, J. Next weeks of SARS-CoV-2: Projection model to predict time evolution scenarios of accumulated cases in Spain. medrxiv. (https://www.medrxiv.org/content/10.1101/2020.04.09.20059881v1
#')


#modificacion de esta para optimizarla y que vaya mas rapido
#funcion nueva----mas simple basada en funcion exponencial alveo y en saber cuando va a llegar a 0----------------------
covid.cases.cumcases3<- function(X=country$n.day, Y=country$Cases, max.cases.free=F, max.cases = 15000, lim.days=300, iterations=10, label.ind="label title plot", duration_pandemic=120, join.mod2=F){


  # sir models in R SIR models in R


  library(BDSbiost3)
  library(minpack.lm)
  library(nls2)
  library(rcompanion)


  if(max.cases.free==F){
    max.cases.f<-max.cases
  }
  if(max.cases.free==T){
    max.cases.f <- max(Y)
  }
      #casos
      plot(Y ~ X,ylim=c(1,2*max(Y)), xlim=c(1,lim.days), ylab="cases COVID-19",xlab="days from day1", col="red", main=label.ind, sub=" (Prediction by T.Monleon-Getino[BIOST3/GRBIO-UB])")
      #casos obtenidos por derivacion F(X)-> f(X)

      #subida, meseta y bajada puntos
      XX<-c(X,duration_pandemic, duration_pandemic+1)
      YY<-c(Y,0.01, 0.01)


      #FORZAR EL MAXIMO EN EL PUNTO MEDIO DE LA CURVA
      if(max.cases.free==F){
        max.cases.f<-max.cases

        XX<-c(X,max.cases.f, duration_pandemic, duration_pandemic+1)
        YY<-c(Y,(duration_pandemic/2), 0.01, 0.01)

      }


      #XX<-c(X[days99],200)
      #YY<-c(Y[days99],0)

      lines(XX,YY , col="yellow")

      #MODELO DE SUBIDA Y MESETA, COMO EN ALVEO########### modelo ALVEO ########################################3
      fo <-  YY ~ exp(a*log(XX) + b*XX + c)
      model.exp_neg <- nlsLM( fo,
                              control = nls.lm.control(ftol = 1e-5, ptol = 1e-5,maxiter = 500),
                              start = list(a=0, b=0, c=1),
                              lower = c(a=-Inf, b = -Inf, c = -Inf),
                              upper = c(a = Inf,  b = Inf, c = Inf))
      #parametros estimados
      a.alveo<-as.numeric(coef(model.exp_neg)[1])
      b.alveo<-as.numeric(coef(model.exp_neg)[2])
      c.alveo<-as.numeric(coef(model.exp_neg)[3])
      #representacion de la curva
      curve(expr = exp(a.alveo*log(x) + b.alveo*x + c.alveo), col = "black", lty=2, lwd=2, add = TRUE)
      library(rcompanion) #r2
      good.fit.model<-accuracy(list(model.exp_neg),
                               plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
      #print("Efron.r.squared: weibull4p nls2: ")
      #print(good.fit.model)
      r2_cases1<- good.fit.model[3]
      #coordenadas para la meseta y bajada
      x11.alveo<- seq(1, lim.days, length=100)
      y11.alveo<- ceiling(round(exp(a.alveo*log(x11.alveo) + b.alveo*x11.alveo + c.alveo),1))
      ############################################################################################

      ############ modelo GAMMA ########################################
      #https://r.789695.n4.nabble.com/using-nls-for-gamma-distribution-a-b-d-td1899967.html

      #gamma farmacocinetico
      #fo <-  YY ~ a*(XX^b) * exp(-c*XX) #gamma

      #model.gamma <- nlsLM( fo,
      #                        control = nls.lm.control(ftol = 1e-15, ptol = 1e-15,maxiter = 500),
      #                        start = list(a=3, b=5, c=-1),
      #                        lower = c(a=-Inf, b = -Inf, c = -Inf),
      #                        upper = c(a = Inf,  b = Inf, c = Inf))
      #parametros estimados
      #a.gamma<-as.numeric(coef(model.gamma)[1])
      #b.gamma<-as.numeric(coef(model.gamma)[2])
      #c.gamma<-as.numeric(coef(model.gamma)[3])




      #representacion de la curva
      #curve(expr =  a.gamma*(x^b.gamma) * exp(-1*c.gamma*x), col = "green", lty=2, lwd=2, add = TRUE)

      #curve(expr =  a.gamma*x^b.gamma * exp(-c.gamma*x), col = "green", lty=2, lwd=2, add = TRUE)
      #library(rcompanion)
      #good.fit.model1<-accuracy(list(model.gamma),
      #                         plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
      #print("Efron.r.squared: weibull4p nls2: ")
      #print(good.fit.model)
      #r2_cases<- good.fit.model1[3]
      #coordenadas para la meseta y bajada
      #x11.gamma<- seq(1, lim.days, length=100)
    #y11.gamma<- ceiling(round(a.gamma*x11.gamma^b.gamma * exp(-c.gamma*x11.gamma),1))
      ############################################################################################

      #############################3 gamma density ###############################
      #fun <- function(x, alpha, beta, theta){
      #  x*(alpha+beta*x)^(-1/theta)
      #}
      #ejemplo
      #da <- data.frame(x=1:20)
      #da$y <- fun(da$x, 1, 2, 0.9)+rnorm(da$x,0,0.001)

      #plot(y~x, da)
      #curve(fun(x, 1,2,0.9), 1, 100, add=TRUE)

      #n0 <- nls(YY~fun(XX, alpha, beta, theta), data=da,
      #          start=list(alpha=1, beta=2, theta=0.9))



      #DETERMINAR QUE DIA SE LLEGA AL MAXIMO DE CASOS
      res.BTI<-Calculate.BTI(maxim=max(y11.alveo),vector.X =x11.alveo,  vector.Y=cumsum(y11.alveo ))
      abline(v=res.BTI[c(1,2,3)],col="magenta",lwd=0.5, lty =2)
      d90_loess<-round(res.BTI[[1]],0)
      d95_loess<-round(res.BTI[[2]],0)
      d99_loess<-round(res.BTI[[3]],0)

      #determinar el maximo y si llega al maximo los casos:
      #Calcular el maximo de la funcion y en que punto esta
      res.busqueda.maxim0<- buscar.maximo.vector(vect =as.vector(y11.alveo))
      max_number_cases<- res.busqueda.maxim0[[1]]
      dia.max_number_cases<- round(x11.alveo[res.busqueda.maxim0[[2]]],0) #dia sobre la escala X
      llego.maxim<-F
      if(dia.max_number_cases<=length(X)){
        llego.maxim<-T

        #REPRESENTAR EL DIA QUE SE LLEGA AL maximo
        abline(v=dia.max_number_cases,col="red",lwd=0.5, lty =2)
      }




      #solo para el caso para mejorar la curva, por el DESAJUSTE DE LOS MAXIMOS de maximos entre f(x) y max real
      r2_cases2<-NA
      if(max(y11.alveo)>max.cases){

        XX<-c(X, dia.max_number_cases,  duration_pandemic)
        YY<-c(Y,max.cases, 0.01)
        points(dia.max_number_cases,max.cases)

        #MODELO DE SUBIDA Y MESETA, COMO EN ALVEO
        fo <-  YY ~ exp(a*log(XX) + b*XX + c)
        model.exp_neg11 <- nlsLM( fo,
                                control = nls.lm.control(ftol = 1e-5, ptol = 1e-5),
                                start = list(a=0, b=0, c=0),
                                lower = c(a=-Inf, b = -Inf, c = -Inf),
                                upper = c(a = Inf,  b = Inf, c = Inf))
        #parametros estimados
        a.alveo11<-as.numeric(coef(model.exp_neg11)[1])
        b.alveo11<-as.numeric(coef(model.exp_neg11)[2])
        c.alveo11<-as.numeric(coef(model.exp_neg11)[3])
        #representacion de la curva
        curve(expr = exp(a.alveo*log(x) + b.alveo*x + c.alveo), col = "green", lty=2, lwd=2, add = TRUE)

        #R2 modelo casos
        library(rcompanion) #r2 - goodness of fit
        good.fit.model1<-accuracy(list(model.exp_neg11),
                                 plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
        #print("Efron.r.squared: weibull4p nls2: ")
        #print(good.fit.model)
        r2_cases1<- good.fit.model1[3]

        #datos
        x11.alveo<- seq(1, lim.days, length=100)
        y11.alveo<- exp(a.alveo*log(x11.alveo) + b.alveo*x11.alveo + c.alveo)

        #round(y11.alveo,0)
        #R2 modelo casos
        #good.fit.model1<-accuracy(list(model.exp_neg),
        #                       plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
        #print("Efron.r.squared: weibull4p nls2: ")
        #print(good.fit.model)
        #r2_cases<- good.fit.model1[3]

        #determinar el maximo y si llega al maximo los casos:
        #Calcular el maximo de la funcion y en que punto esta
        res.busqueda.maxim0<- buscar.maximo.vector(vect =as.vector(y11.alveo))
        max_number_cases<- res.busqueda.maxim0[[1]]
        dia.max_number_cases<- round(x11.alveo[res.busqueda.maxim0[[2]]],0) #complicado!
        llego.maxim<-F
        if(dia.max_number_cases>length(y11.alveo)){
          llego.maxim<-T
        }

      }


      #lo junto todo con un LOESS Y LO REPRESENTO!!!!!!!!!!!!!!!!!!!!!!!
      #casos
      plot(Y ~ X, ylim=c(1,1.2*max(y11.alveo,max(Y))), xlim=c(1,lim.days), ylab="cases COVID-19",xlab="days from day1", col="red", main=label.ind, sub=" (Prediction by T.Monleon-Getino[BIOST3/GRBIO-UB])")

      X1<-c(X, x11.alveo)
      X2<-c(Y, y11.alveo)


      #SI HAY UN MAXIMO Y SE HA LLEGADO AL TIEMPO DEL 95% DE LOS CASOS
      ############################################################################
      #if(llego.maxim==T){
      #SI LOS CASOS LLEGARON AL MAXIMO
      if(llego.maxim==T){
          XX3<-XX[dia.max_number_cases:length(XX)]
          YY3<-YY[dia.max_number_cases:length(XX)]
      }
      #SI LOS CASOS NO LLEGARON AL MAXIMO ENTONCES
      if(llego.maxim==F){
        #XX3<-x11.alveo[dia.max_number_cases:length(x11.alveo)]
        #YY3<-y11.alveo[dia.max_number_cases:length(x11.alveo)]

        XX3<-round(x11.alveo,0)[round(x11.alveo,0)>=dia.max_number_cases]
        YY3<-round(y11.alveo,0)[round(x11.alveo,0)>=dia.max_number_cases]


      }




          #XX3<-as.numeric(c(round(d95_loess,0),duration_pandemic))
          #YY3<-c(Y[round(d95_loess,0)],0.01)

          #segunda funcion exponencial
          #funcion monotona decreciente final alveograma (caida desde maximo a final)
          fo <-  YY3 ~ exp(a*log(XX3)  + c)
          model.exp_neg12 <- nlsLM( fo,
                                   control = nls.lm.control(ftol = 1e-5, ptol = 1e-5),
                                   start = list(a=1, c=1),
                                   lower = c(a=-Inf, c = -Inf),
                                   upper = c(a = Inf, c = Inf))


          #parametros estimados
          a.alveo2<-as.numeric(coef(model.exp_neg12)[1])
          c.alveo2<-as.numeric(coef(model.exp_neg12)[2])
          #representacion de la curva
          curve(expr = exp(a.alveo2*log(x)  + c.alveo2), col = "pink", lty=2, lwd=2, add = TRUE)
          #R2 modelo casos
          library(rcompanion) #r2 - goodness of fit
          good.fit.model12<-accuracy(list(model.exp_neg12),
                                    plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
          #print("Efron.r.squared: weibull4p nls2: ")
          #print(good.fit.model)
          r2_cases2<- good.fit.model12[3]

          #coordenadas para la meseta y bajada
          #XX[dia.max_number_cases:length(XX)]
          x3.alveo<- seq(dia.max_number_cases, lim.days, length=100)
          y3.alveo<- exp(a.alveo2*log(x3.alveo)  + c.alveo2)


          #add to the loess la caida del alveo para que sea mas alta la curva de los casos
          if(join.mod2==T){

            #X1<-c(X, x11.alveo, x3.alveo)
            #X2<-c(Y, y11.alveo, y3.alveo)

            #si hay maximo
            if(llego.maxim==T){
              #juntar los dias
              #1-39    #algoritmo copa
              #39-120  #algoritmo bajada-relajacion
              X1<-c(XX, round(x11.alveo,0)[round(x11.alveo,0)<=39], x3.alveo)
              X2<-c(YY, y11.alveo[1:length(round(x11.alveo,0)[round(x11.alveo,0)<=39])], y3.alveo)
            }
            #SI LOS CASOS NO LLEGARON AL MAXIMO ENTONCES lo junta todo ??
            if(llego.maxim==F){
              X1<-c(XX, x11.alveo, x3.alveo)
              X2<-c(YY, y11.alveo, y3.alveo)
            }
          }



          #Calcular el maximo de la funcion y en que punto esta
          #res.busqueda.maxim2<- buscar.maximo.vector(y3.alveo)
          #max_number_cases<- res.busqueda.maxim2[[1]]
          #dia.max_number_cases<- res.busqueda.maxim2[[2]]

      #}

      #############################################################################3







      #LINEAS MEDIAS DEL MODELO PREDICHO CON LOESS()
      plx<-loess(X2 ~ X1, se=T,span=0.1,control = loess.control(surface =  "direct"))
      aaa<- predict(plx, data.frame(X1 = 1:lim.days), se = TRUE)
      x.1.1 <- 1:lim.days
      lines(x.1.1, aaa$fit, col = "magenta", lwd=2, lty=1) #casos predichos
      lines(x.1.1,aaa$fit - qt(0.975,aaa$df)*aaa$se, lwd=1, lty=2, col = "magenta")
      lines(x.1.1,aaa$fit + qt(0.975,aaa$df)*aaa$se, lwd=1, lty=2, col = "magenta")
      #dia actual
      abline(v=max(X),col="yellow",lwd=2, lty =2)


      #cumcases
      plot(cumsum(Y) ~ X, xlim=c(0,lim.days), ylim=c(0,max(cumsum(round(aaa$fit,0)),max(cumsum(Y)))), ylab="CUM-cases COVID-19",xlab="days from day1", col="red", main=label.ind, sub=" (Prediction by T.Monleon-Getino[BIOST3/GRBIO-UB])")

      #casos acumulados: reales + predichos modelo
      cumcases_pred<-cumsum( c(Y[1:length(X)], round(aaa$fit,0)[(length(X)+1):lim.days]) )      #reales + predichos
      lines(x.1.1, cumcases_pred, col = "magenta", lwd=2, lty=1) #casos predichos
      cumcases_pred_ll<-cumsum( c(Y[1:length(X)], round(aaa$fit- qt(0.975,aaa$df),0)[(length(X)+1):lim.days]) )
      lines(x.1.1, cumcases_pred_ll, col = "magenta", lwd=1, lty=1) #casos predichos
      cumcases_pred_ul<-cumsum( c(Y[1:length(X)], round(aaa$fit+ qt(0.975,aaa$df),0)[(length(X)+1):lim.days]) )
      lines(x.1.1, cumcases_pred_ul, col = "magenta", lwd=1, lty=1) #casos predichos
      #old
      #lines(x.1.1, cumsum(round(aaa$fit,0)), col = "magenta", lwd=2, lty=1) #casos predichos
      #lines(x.1.1, cumsum(aaa$fit - qt(0.975,aaa$df)), col = "magenta", lwd=1, lty=1) #casos predichos
      #lines(x.1.1, cumsum(aaa$fit + qt(0.975,aaa$df)), col = "magenta", lwd=1, lty=1) #casos predichos


      #maximum of cases acumulated cases
      #round(aaa$fit - qt(0.975,aaa$df),0)
      m<-cumcases_pred #round(cumsum(round(aaa$fit,0)),0)
      m.ll<-cumcases_pred_ll #round(cumsum(aaa$fit - qt(0.975,aaa$df)),0)
      m.ul<-cumcases_pred_ul #round(cumsum(aaa$fit + qt(0.975,aaa$df)),0)

    #plot(m ~ x.1.1)
    #modelo de casos acumulados parametros
    #res.model.weibull1<-Weibull4p.monle1(X=x.1.1,  Y=m, a=max(m), b=a, c=-20, d=12, Print.curve = T, force.a = T, brfr.it=30)

    #res.model.weibull1
    #abline(v=res.model.weibull1[c(5,6,7)],col="green",lwd=0.5, lty =2)
    #dia actual en el que estamos
    abline(v=max(X),col="yellow",lwd=2, lty =2)

    #REPRESENTAR EL DIA QUE SE LLEGA AL 99% DE LOS CASOS SEGUN W(x)
    #abline(v=day.maximo,col="red",lwd=0.5, lty =2)

    #calculo con funcion loess del tiempo hasta 90,95 y 99%
    res.BTI<-Calculate.BTI(maxim=max(m),vector.X =x.1.1,  vector.Y=m, PUNTO.Y.INTERES = sum(Y) )
    #90,95,99%
    abline(v=res.BTI[c(1,2,3)],col="magenta",lwd=0.5, lty =2)
    #50%
    abline(v=res.BTI[c(4)],col="pink",lwd=2, lty =2)

    #saturation
    saturation.actual<-round(as.numeric(res.BTI[5]),1)
    text(50,1,paste("Sat=",saturation.actual,"%",sep=))


    #parametros calculados con una W(X)
    #c<-round(res.model.weibull1[[3]],1)
    #d<-round(res.model.weibull1[[4]],1)
    #d90<-round(res.model.weibull1[[5]],0)
    #d95<-round(res.model.weibull1[[6]],0)
    #d99<-round(res.model.weibull1[[7]],0)
    d<-NA
    d90<-NA
    d95<-NA
    d99<-NA

    #parametros calculados con una funcion loess
    #res.BTI
    d90_loess1<-round(res.BTI[[1]],0)
    d95_loess1<-round(res.BTI[[2]],0)
    d99_loess1<-round(res.BTI[[3]],0)
    #d90_loess1<-NA
    #d95_loess1<-NA
    #d99_loess1<-NA
    c<-NA

    #print("################################################################")
    #print(paste("Maximum number of accumulated cases. Mean=", max(m), ",CI95% = (", max(m.ll), "-",max(m.ul), ")",sep=""))
    #print(paste("Parameters cum cases W(X). c=", c, ",d=", d, ", day90%=",d90, ", day95%=",d95, ", day99%=",d99, sep=""))

    #prediccion casos nuevos proximos dias
    cases_pred<- c(Y[1:length(X)], round(aaa$fit,0)[(length(X)+1):lim.days])       #reales + predichos
    cases_pred_ll<- c(Y[1:length(X)], round(aaa$fit- qt(0.975,aaa$df),0)[(length(X)+1):lim.days]) #reales + predichos
    cases_pred_ul<- c(Y[1:length(X)], round(aaa$fit+ qt(0.975,aaa$df),0)[(length(X)+1):lim.days]) #reales + predichos
    next.days.cases<-cases_pred[(length(X)+1):lim.days]
    next.days.cases_ll<-cases_pred_ll[(length(X)+1):lim.days]
    next.days.cases_ul<-cases_pred_ul[(length(X)+1):lim.days]
    next.days.cumcases<-cumcases_pred[(length(X)+1):lim.days]

    #devuelvve las variables solicitadas
    r2_cases1<- r2_cases1  #modelo1 exponencial
    r2_cases2<- r2_cases2 #modelo1 exponencial2
    return(list(duration_pandemic, max(X), c, d, d90_loess1, d95_loess1, d99_loess1, max(m),
                next.days.cases, next.days.cases_ll, next.days.cases_ul, a.alveo,
                b.alveo,c.alveo,NA, d90_loess, d95_loess, d99_loess, next.days.cumcases,
                r2_cases1, r2_cases2, max_number_cases, dia.max_number_cases, llego.maxim,saturation.actual))
}

#uso de la funcion para españa
#covid.cases.cumcases(X=country$n.day, Y=country$Cases, max.cases.free=F, max.cases = 8000 , sdv_dias1=3, rest99 = 0, lim.days=120)


#########################################################################
#calcular el maximo y los BTI mediante un spline
#calcula tambien la saturacion actual
#vector.Y<- vector.Y
Calculate.BTI<- function(maxim, vector.X, vector.Y,PUNTO.Y.INTERES=0 ){
  maxim <- max(vector.Y)
  num.row <- length(vector.Y) #num of rows data-frame
  #toni-aquiii 30-11-2016
  i<-1
  while(vector.Y[i]<maxim ){
    punt_t <- vector.X[i]
    i <- i + 1
  }

  #calculo el 90% maximo
  y.i <- 0.5*maxim
  data.x.y <- data.frame(x=vector.X, y=vector.Y)
  x.para.maximo.50<- inverse.function(data.x.y, y.i, punt_t)


  #calculo el 90% maximo
  y.i <- 0.90*maxim
  data.x.y <- data.frame(x=vector.X, y=vector.Y)
  x.para.maximo.90<- inverse.function(data.x.y, y.i, punt_t)

  print("effort to reach a time of the 90% of the maximum of the cumulative.survival curve")
  print(x.para.maximo.90)


  #calculo el 95% maximo
  maxim <- max(vector.Y)

  y.i <- 0.95*maxim
  data.x.y <- data.frame(x=vector.X, y=vector.Y)
  x.para.maximo.95<- inverse.function(data.x.y, y.i, punt_t)

  print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve")
  print(x.para.maximo.95)

  #calculo el 95% maximo
  maxim <- max(vector.Y)
  y.i <- 0.99*maxim
  data.x.y <- data.frame(x=vector.X, y=vector.Y)
  x.para.maximo.99<- inverse.function(data.x.y, y.i, punt_t)

  #SATURACION ACTUAL
  porcentaje.saturacion.actual<- 100*PUNTO.Y.INTERES/maxim




  print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
  print(x.para.maximo.99)

  return(list(x.para.maximo.90[1], x.para.maximo.95[1], x.para.maximo.99[1],x.para.maximo.50[1],porcentaje.saturacion.actual))
}


#funcion que busca el maximo de un vector (para las funciones, he de derivar)
buscar.maximo.vector<- function(vect = vector1){
  max<-0
  pos_max<-1
  for(i in 1:length(vect)){
    if(vect[i]>max){
      max<-vect[i]
      pos_max<-i}
  }
  return(list(max,pos_max))
}
#ejemplo
#vector1<-c(2,6,7,12,1,34,55,2,3,23)
#max
#pos_max


#funcion que busca el punto de inflexion de Weibull() y en que tiempo se produce
#para los casos acumulados utilizando Weibull pasando el X a logX
#ejemplo
#buscar.porc.saturacion.weibull(X=COVID19.Spain$n.day, Y=COVID19.Spain$Cases,lim.days=120, label.ind="Inflexion point W(t)")
buscar.porc.saturacion.weibull<- function(X=country$n.day, Y=country$Cases, lim.days=120, label.ind="Label for the plot"){


  #representar los casos acumulados y logaritmicos
  plot(log2(cumsum(Y)+1) ~ X,ylim=c(1,2*max((log2(cumsum(Y)+1)))), xlim=c(1,lim.days), ylab="log(cumY) cases",xlab="days from day1", col="red", main=label.ind, sub=" (Prediction by T.Monleon-Getino[BIOST3/GRBIO-UB])")
  #casos obtenidos por derivacion F(X)-> f(X)

  res.1<-Weibull4p.monle1(X=X,  Y=log2(cumsum(Y)+1), a=max(log2(cumsum(Y)+1)), b=a, c=-20, d=12, Print.curve = T, force.a = F, brfr.it=10)

  #PTO INFLEXION
  a<-res.1[[1]]
  b<-res.1[[2]]
  c<-res.1[[3]]
  d<-res.1[[4]]
  inflexion.point<- (1/c)*(((d-1)/d)^(1/d))


  y <- 0.5*a
  x.para.maximo.50_1<- as.numeric((log((a-y)/b)/-exp(c))^(1/d) )

  #momento actual % casos
  max.actual<-max((log2(cumsum(Y)+1)))
  #porcentaje.saturacion.actual<- as.numeric((log((a-max.actual)/b)/-exp(c))^(1/d) )
  #x<-length(X) #dia actual
  porcentaje.saturacion.actual<- 100*(max(log2(cumsum(Y)+1))/a)  #a-b*exp(-exp(c)*x^d)

  return(list(x.para.maximo.50_1,porcentaje.saturacion.actual))

  #max<-0
  #pos_max<-1
  #for(i in 1:length(vect)){
  #  if(vect[i]>max){
  #    max<-vect[i]
  #    pos_max<-i}
  #}
  #return(list(max,pos_max))
}


#covid.cases.cumcases2<- function(X=country$n.day, Y=country$Cases, max.cases.free=F, max.cases = 15000, lim.days=300, iterations=10, label.ind="label title plot", duration_pandemic=120, join.mod2=F){


  # sir models in R SIR models in R


