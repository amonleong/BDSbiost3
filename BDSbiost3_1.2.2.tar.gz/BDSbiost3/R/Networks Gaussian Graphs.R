
#toni monleon (5-4-2019) (8-11-2017)

#MIRIAM NETWORK: NETWORK AND GAUSSIAN GRAPHS, ESPECTRAL ANALYSIS USING NETWORK

##################################################################################################
# MIRIAM NETWORK: NETWORK AND GAUSSIAN GRAPHS, ESPECTRAL ANALYSIS USING NETWORK
#################################################################################################
#' Network analysis for frequencies (taxon, omic data, counts) - correlation nwtworking, bayesian networks and Gaussian Graphs with complexity index
#'
#' Function to create networkss and Gaussian Graphs
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param vector.labels parameter
#' @param nrows parameter
#' @param qgraph model graphs network (Yes/Not)
#' @param nsimul number of simulations
#' @param gaussiangraphs Gaussian graphs network (Yes/Not)
#' @param bayesian.graph Bayesian graphs network (Yes/Not)
#' @param cut parameter for the bayesian nets
#' @return Network plots and complexity index
#' @export
#' #'
#' @examples
#' library(HMP) #16S rRNA Sequencing Data from the Human Microbiome Proje
#' data(saliva) #saliva metagenomic test (sample vs taxa)
#' saliva1<- data.frame(t(saliva))
#' #define the experimental groups
#' labels1<- c(rep("G1", 8),rep("G2", 8),rep("G3", 8))
#' colnames(saliva1)<-labels1
#' #EXPERIMENTAL GROUPS CORRELATION NETWORKING
#' Miriam.Network(matriu=saliva1, nrows=dim(saliva1)[1], qgraph1=T, vector.labels=labels1, cor.type=1, gaussiangraphs=F, bayesian.graph=F, cut = 0.9, nsimul=1000, print.graph=T)
#' #TAXA NETWORKING USING GAUSSIAN GRAPHS AND COMPLEXITY ANALYSIS
#' Miriam.Network(matriu=saliva1, nrows=12, qgraph1=F,  cor.type=1, gaussiangraphs=T, nsimul=3000, print.graph=T)

#' @references
#' CI Rodríguez-Casado, A Monleon-Getino, M Cubedo, M Ríos- Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32





#####################################################################################
###                  Miriam Network
#####################################################################################

#matriu matriz de frecuencias (OTUxsamples)
Miriam.Network <- function(matriu, nrows=50, qgraph1=T, vector.labels, cor.type=2, gaussiangraphs=T, bayesian.graph=F, cut = 0.8, nsimul=1000, print.graph=T){
#bayesian.graph=T, cut = 0.65, nsimul=1000, nrows=10







  ######### (paso 1 ##################################
  #vector.labels <- vector.labels2
  #Selecciono las nrows más abundantes por suma de las filas y
  #selecciono nrows
  Rsum <- rowSums(matriu,na.rm=TRUE)
  matriu.ordered<-matriu[order(-Rsum),]
  matriu.ordered.selected <- matriu.ordered[1:nrows, ]

  ############# grafo entre observaciones ##############################
  #CORRELACIONES ENTRE NIVELES DE LOS FACTORES PARA VER QUE OCURRE
  #only if option qgraph is true
  if(qgraph1==T){
        #Graphical Model Estimation
        #seleccionar por grupo de labels y agruparlos segun suma
        print("Number of groups: ")
        print(length(levels(factor(vector.labels))))
        #print("GROUPS  ###################")
        if (length(levels(factor(vector.labels))<=1)){
          print("There is only a group. This analysis is necessary > 1 group")


          #alternativa
          #matriu.analisis3<-matriu.ordered.selected
          #colnames(matriu.analisis3)<-rep(1:ncol(matriu.ordered.selected),1)
        }
        if (length(levels(factor(vector.labels)))>1){
          j<-1
          for (i in levels(factor(vector.labels))){
            #i<-"V"
            matriu.analisis<-matriu.ordered.selected
            colnames(matriu.analisis)<-vector.labels
            matriu.analisis1<-matriu.analisis[,grep(i, colnames(matriu.analisis))]
            #View(matriu.analisis1)
            matriu.analisis2<-as.matrix(rowSums(matriu.analisis1))
            colnames(matriu.analisis2)[1]<-i #etqiueta nombre grupo
            #View(matriu.analisis2)
            #class(matriu.analisis2)
            if(j==1){
              matriu.analisis3 <- matriu.analisis2
            }
            if(j>1){
              matriu.analisis3 <- cbind(matriu.analisis3, matriu.analisis2)
            }
            j<-j+1
          }
          #View(matriu.analisis3)

        #Network and Graphs:
        #http://sachaepskamp.com/files/Cookbook.html
        #vector.labels <- vector.labels2
        #corMat <- cor(matriu, use = "pairwise.complete.obs") # Correlate data
        #View(round(corMat, 2))
        #posibilidades de correlacion entre datos de contajes
        #Polyserial Correlation - This would be the most exotic of the 3 options and involves an approximation of a latent, continuous variable used to build the discrete variable (Ni in your case) as well as a maximum likelihood estimation procedure for the most likely ρ that could result between that latent continuous variable and the real one, Xi
        #, when treated as bivariate normal samples (example implementation in R: polycor). There are several references to this idea out there, but this is the original publication on the subject from 1974: Estimation of the Correlation Between a Continuous and a Discrete Variable.
        #Nonparametric Correlation - Spearman's Rank Correlation Coefficient is likely a good option in this case. The calculation for Spearman's Rho works based on the ranks of the values of each variable rather than the values themselves which makes it more widely applicable in the presence of nonlinear relationships or mixed datatypes.
        #Modeling - I know you mentioned in the comments that you're not trying to do any kind of modeling, but I still think a parameter estimate or two from a well-fitting, functional relationship between the two variables is a whole lot more informative than any correlation coefficient you'll find (unless the discrete variable was really created from one half of a bivariate normal distribution's values -- which I'd doubt).

          library("qgraph")
          if(cor.type==1){ #correlacion por defecto en qgraph
            corMat <- cor_auto(matriu.analisis3,detectOrdinal = T) # Correlate data
          }
          if(cor.type==2){ #correlacion por defecto en qgraph
            # run a polyserial correlation
            corMat <- cor(matriu.analisis3, method = c("spearman"))
          }
          #Graph_pcor <- qgraph(corMat, graph = "pcor", layout = "spring")

          #The threshold argument can be used to remove edges that are not significant. For example:
          Graph_pcor <- qgraph(corMat, graph = "pcor", layout = "spring", threshold = "bonferroni",
                               sampleSize = nrow(matriu), alpha = 0.01,groups = levels(factor(vector.labels)),
          legend = TRUE, borders = FALSE)
          title("Network with Bonferroni th.", line = 2.5)

          #Estimating a partial correlation network using LASSO regularization and EBIC model selection can be done by setting graph = "glasso". The tuning argument sets the EBIC hyperparameter. Set between 0 (more connections but also more spurious connections) and 0.5 (more parsimony, but also missing more connections):
          Graph_lasso <- qgraph(corMat, graph = "glasso", layout = "spring", tuning = 0.25,
                                sampleSize = nrow(matriu),groups = levels(factor(vector.labels)),
                                legend = TRUE, borders = FALSE)
          title("Network with LASSO regularization.", line = 2.5)

        }
  }




  ################ Grafo gausiano ####################
  if(gaussiangraphs==T){
        #otus
        #### GGMselect - net ##############################
        if (ncol((matriu.ordered.selected)) <=3){
          print("input matrix<=3 columns, please add more sample data")
        }
        #minimo numero de columnas es 3
        if (ncol((matriu.ordered.selected)) >3){
          library(GGMselect)
          library(ggm)
          #matrix
          X <- t(matriu.ordered.selected)
          #View(X)
          # estimate graph
          #GQE <- selectQE(X)
          GQE<-selectFast(X,family=c("C01","LA")) #no va
          adj3<-GQE$C01.LA$G
          #colnames(adj3)<-colnames(X)
          rownames(adj3)<-colnames(X) #labels
          #rownames(adj3)<-rownames(matriz_compuesta.graf.1)
          # plot the result (solo permite 180)
          if(print.graph==T){
            ggm::plotGraph(adj3,tcltk=T)
          }

          # print("Gaussian graph matrix: ")
          # print(adj3)#imprimirla para el analisis


          #complexity index monleon 2018-julio
          #print("Matriz de adya") adj3 es la matriz de adyacencia 1 y 0
          #pero en este caso es de dependencia la red o grafo
          save(adj3,file = "adj3.txt")
          print("dimension matriz de adycencia")
          print(dim(adj3))
          #calculo complejidad, indice de Monleon
          res.monle<-monle.complexity.adjacency1(mm = as.matrix(adj3))
          print("calculo complejidad, indice de Monleon")
          print(res.monle)
          if(print.graph==T){
            barplot(table(res.monle[1]),
                    main = "MONLE-COMPLEXITY GG N CONECTIONS", col ="red",
                    xlab = "connexion nodes by OTU", ylab = "frequency")
          }

          print("Complejidad Monle (edges-groups)")
          print(res.monle[1]) #los grupos que se han formado
          print("Indice de complejidad Monle (Mean edges)")
          print(res.monle[2]) #los grupos que se han formado
          print("Indice de complejidad Monle (Mean edges>1)")
          print(res.monle[3])#los grupos que se han formado

          #return los indices de complejidad y el numero de grupos
          return(c(res.monle[2], res.monle[3], nlevels(as.factor(table(res.monle[1])))))



          #complexity index?
          #print("Complexity index-----------")
          #print("Mean nodes connexion by OTU: ")
          #rowSums.adj3 <- colSums(adj3,na.rm = T) #COMPUTE THE SUM OF THE ROWS OF THE TRANSFORMED ADJACENCY MATRIX
          #rowSums.adj4<-rowSums.adj3 #se anade 1 para formar los grupos (1 conexion, 2 conexiones, ...)

          #colSums(adj3)
          #print(mean(rowSums.adj3))
          #print("Table with nodes by row: ")
          #print(table(rowSums.adj4))


          #barplot for complexity
          #barplot(table(res.monle[1]),
          #        main = "SAMPLE COMPLEXITY GG-MONLE-INDEX", col =blues9,
          #        xlab = "connexion nodes by OTU", ylab = "frequency")
          #text("HOLA")

          ####################################################
          #creo que desde aqui no tiene sentido BORRA:
          #trasnformar matriz para su analisis de grafos
          #ver centralidad, comunidades, etc (Python)
          ##adj4<-adj3
          ##rownames(adj4)<-rep(1:nrow(adj4)) #labels
          #View(adj4)
          #write.table(adj4, file = "networkmatrix.csv",
          #            sep = ",", col.names = NA,
          #            qmethod = "double")


          ##################################################
          #analisis geometrico de la matriz de adyacencia
          ##################################################

          ##library(igraph)
          ##g <-  graph_from_adjacency_matrix(adj4)

          #plot(g)
          #hist(degree(g))
          #The diameter of the network is the
          #largest geodesic. This gives a good idea of the effective size of the network
          ##print("network diameter: effective size of the network")
          ##print(diameter(g))

          ##print("community detection using cluster walktrap")
          ##print(cluster_walktrap(g))
          #str(cluster_walktrap(g))

          #Finding communities in graphs based on statistical meachanics
          #g <- induced_subgraph(g, subcomponent(g, 1))
          #cluster_spinglass(g, spins=2)
          #cluster_spinglass(g, vertex=1)

          #Normalized Shannon Entropy Score
          #graph.diversity(g, weights = NULL, vids = V(g))

          #Jaccard Similarity
          ##similarity(g, method = "jaccard")
          # set seed to make the layout reproducible
          #set.seed(3952)
          ##E(g)$color <- "grey"
          ##V(g)$color <- "grey"
          #V(g)[degree(g, mode="in")>10]$color <- "yellow"  #Destinguishing High Degree Nodes as yellow
          ##V(g)$label.cex <- seq(0.5,5,length.out=0.5)         ## text size
          ##V(g)$size      <- seq(10,60,length.out=0.5)         ## circle size proportional to text size
          ##layout1 <- layout.kamada.kawai(g)
          ##tkplot(g, layout=layout1)   #tkplot allows us to manually manipulte the visualization if we want

          #Finding Strongly Connected Components
          ##scc <- clusters(g, "strong")     #Type scc in the console to have the strongly connected components reported
          #Membership: Top number indicates the node ID, the bottom the component to which it belongs (e.g., node 1 belongs to the 2 component)
          #csize: Component Size, the number of nodes in the component.
          #no: no indicates the number of components in the graph. We have 7 components, 1 central component and 6 nodes that recieve but do not send ties.

          ##v_idx=which (scc$csize>1) #Type v_idx in the console to get this report
          #In graphs with multiple components, it can be helpful to distinguish connected components from isolates.
          #Community Detection Algorithms in iGraph: Approaches Supported by iGraph
          #Detecting communitities by iteratively calculating edge betweeness (e.g., Girvan & Newman 2001)
          #Detecting communities by using eigenvector matrices (e.g., Newman 2006)
          #Detecting communities by iteratively optimizing for modularity (e.g., Blondel, Guillaume, Lambiotte, & Lefebvre 2008)
          #Detecting communities using random walk methods (e.g, Pons & Latapy 2005; Reichardt & Bornholdt 2006)
          #Detecting communities using label propogation techniques (e.g., Ragavan, Albert, & Kumara 2007)

          #Edge-Betweeness: Girvan-Newman (2001)
          ##title(main="Girvan-Newman detection of communities")
          ##GNC <- cluster_edge_betweenness(g, weights = NULL)
          ##V(g)$color <-membership(GNC)              #Plot setting specifying the coloring of vertices by community
          ##g$palette <- diverging_pal(length(GNC))   #Plot setting specifying the color pallette I am using (iGraph supports 3)
          ##V(g)$label.cex <- seq(0.5,5,length.out=0.5)         ## text size
          ##V(g)$size      <- seq(10,60,length.out=0.5)         ## circle size proportional to text size
          ##layout1 <- layout.kamada.kawai(g)
          ##plot(g, edge.arrow.size=.5, edge.arrow.width=.5)
          ##title(main="Girvan-Newman detection of communities")
          ##plot_dendrogram(GNC)
          ##title(main="cluster Girvan-Newman detection of communities")
          #otro plot mas bonito
          ##coords = layout_with_fr(g)
          ##plot(GNC, g, layout=coords)
          #print("modularidad")
          #print(modularity(GNC))
          ##membership(GNC)
          #head(GNC, n=21)   #Looking at what nodes got assigned to the communities (23 communities in all)


        }
  }



  # Bayesian Structure Learning in Graphical Models
  #Grafo bayesiano
  #bdgraph( data, n = NULL, method = "ggm", algorithm = "bdmcmc", iter = 5000,
  #         burnin = iter / 2, g.start = "empty", g.space = NULL, g.prior = 0.5,
  #         prior.df = 3, multi.update = NULL, save.all = FALSE, print = 1000,
  #         cores = "all" )
  #bdgraph
  #From BDgraph v2.41
  #by Abdolreza Mohammadi
  #Search Algorithm In Graphical Models
  #As the main function of the BDgraph package, this function consists of several sampling algorithms for Bayesian model determination in undirected graphical models. To speed up the computations, the birth-death MCMC sampling algorithms are implemented in parallel using OpenMP in C++.
  # Generating mixed data from a 'scale-free' graph
  if( bayesian.graph==T){

      library(BDgraph)
      #data.sim <- bdgraph.sim( n = 50, p = 6, type = "mixed", graph = "scale-free", vis = TRUE )


      #bdgraph.obj <- bdgraph( data = data.sim, method = "gcgm", iter = 100 )
      #plot(bdgraph.obj)
      #bayesian.graph=T, cut = 0.9999, nsimul=1000
      #bayesian graphs
      X <- t(matriu.ordered.selected)
      bdgraph.obj <- bdgraph( data = X, method = "gcgm", iter = nsimul )
      #plot( bdgraph.obj )
      plot( bdgraph.obj, cut = cut )
      #plot( bdgraph.obj, number.g = 4 )
      #tarda mucho:
      #bdgraph.obj <- bdgraph( data = X, method = "ggm", algorithm = "bdmcmc", iter = 67 )
      #plot( bdgraph.obj, cut = 0.65 )



      ## Not run:
      # Generating multivariate normal data from a 'random' graph
      #data.sim <- bdgraph.sim( n = 50, p = 6, size = 7, vis = TRUE )
      #bdgraph.obj <- bdgraph( data = data.sim )
      #plot( bdgraph.obj )
      #bdgraph.obj <- bdgraph( data = data.sim, save.all = TRUE )
      #plot( bdgraph.obj, number.g = 4 )

      #plot( bdgraph.obj, cut = 0.4 )
      ## End(Not run)
  }
}




