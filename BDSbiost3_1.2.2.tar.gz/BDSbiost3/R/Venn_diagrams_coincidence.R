
#############################################################################3
# COINCIDENCE ANALYSIS
##############################################################################

# Toni Monleon. Biost3. 12-2019




#' Function to compute coincidencies using Venn diagrams and upset plots (coincidence analysis)
#' @param matriu1 data-set matrix with data containing the metegenomic frequencies
#' @return Coincidence plots and print results
#' @export
#'
#' @examples
#############################
#' #First example with a metagenomic raw data (taxon x samples: 3 groups)
#' library(HMP) #16S rRNA Sequencing Data from the Human Microbiome Proje
#' data(saliva) #saliva metagenomic test (sample vs taxa)
#' saliva1<- data.frame(t(saliva))
#' #define the experimental groups
#' labels1<- c(rep("G1", 8),rep("G2", 8),rep("G3", 8)) #3 groups
#' colnames(saliva1)<-labels1
#'
#' #Do grouping by group and venn diagram (Number of rows coincident between groups)
#' coincidence.analysis(matriu1=saliva1)
#'
#' #Second example
#' #Generate Multinomial Random Variables With Varying Probabilities
#' my_prob <- c(0.2,0.3,0.1,0.3, 0.01, 0.02, 0.01,0.01, 0.01, 0.01, 0.01, 0.01, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001 )
#' #sum(my_prob)
#' number_of_experiments <- 35
#' number_of_samples <- 80
#' #generate a matrix
#' experiments <- data.frame(rmultinom(n=number_of_experiments, size=number_of_samples, prob=my_prob))
#' experiments
#' labels2<- c(rep("G1", 5),rep("G2", 5),rep("G3", 5), rep("G4", 5), rep("G5", 5), rep("G6", 5), rep("G7", 5)) #7 groups
#' colnames(experiments)<-labels2
#'
#' #Do grouping by group and venn diagram (Number of rows coincident between groups)
#' coincidence.analysis(matriu1=experiments)



#' @references
#' CI Rodríguez-Casado, A Monleon-Getino, M Cubedo, M Ríos- Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32


#####################################################
# analisis de coincidencia entre columnas
###################################################
coincidence.analysis<- function(matriu1){

    #sum columns with similar names in R
    groups<-names(table(colnames(matriu1))) #How many groups->maximum 5 groups
    if(mean(table(colnames(matriu1)))==1){ #solo hay una columna por grupo
      matriu1_sum<-matriu1
      matriu1_sum.original<-matriu1_sum
    }
    if(mean(table(colnames(matriu1)))!=1){ # hay mas de una columna por grupo
      prefixes = groups
      matriu1_sum<- data.frame(sapply(prefixes, function(x)rowSums(matriu1[,startsWith(colnames(matriu1), x)])))
      matriu1_sum.original<-matriu1_sum
    }


    #convert 0 to na
    matriu1_sum[matriu1_sum == 0] <- NA
    matriu1_sum.NA<-matriu1_sum
    #prepare data to venn
    ngroups<-nlevels(as.factor(groups))
    #componer las listas para los grupos analizados
    matriu1_sum.NA$row_label<-rownames(matriu1_sum.NA)
    bef<-""
    input<-""
    for(i in 1:ngroups){
        #i<-1
        #i<-2
        #i<-3
        #i<-4
        #paste("G",i,sep="") #G1
        #asignacion
        assign(paste("G",i,sep=""), matriu1_sum.NA[!is.na(matriu1_sum.NA[,i]),"row_label"])
        #componer las listas
        #G2
        if(i==1){
            input <- list(get(paste("G",i,sep="")))
            names(input)[i] <- groups[i] #paste("G",i,sep="")
        }
        if(i>1){
            input <- c(bef, list(get(paste("G",i,sep=""))))
            names(input)[i] <-  groups[i] #paste("G",i,sep="")
        }
        #names(input)[i] <- paste("G",i,sep="")
        input
        bef<-input
    }

    #if(ngroups>1){
    #    require(gplots)
    #    matriu1_sum.NA$row_label<-rownames(matriu1_sum.NA)
    #    G1 <- matriu1_sum.NA[!is.na(matriu1_sum.NA[,1]),"row_label"]
    #    G2 <- matriu1_sum.NA[!is.na(matriu1_sum.NA[,2]),"row_label"]
    #    input <- list(G1=G1, G2=G2)
    #    if(ngroups>2){
    #        G3 <- matriu1_sum.NA[!is.na(matriu1_sum.NA[,3]),"row_label"]
    #        input <- list(G1=G1, G2=G2, G3=G3)
    #    }
    #    if(ngroups>3){
    #        G4 <- matriu1_sum.NA[!is.na(matriu1_sum.NA[,4]),"row_label"]
    #        input <- list(G1=G1, G2=G2, G3=G3, G4=G4)
    #    }
    #    if(ngroups>4){
    #        G5 <- matriu1_sum.NA[!is.na(matriu1_sum.NA[,5]),"row_label"]
    #        input <- list(G1=G1, G2=G2, G3=G3, G4=G4, G5=G5)
    #    }
    #    G6 <- matriu1_sum.NA[!is.na(matriu1_sum.NA[,5]),"row_label"]
    #    input <- list(G1=G1, G2=G2, G3=G3, G4=G4, G5=G5,G6=G6)
    #    if(ngroups>5){
    #        print("Maximum number of groups = 5. Please check columns ang groups")
    #    }
        #G6 <- matriu1_sum.NA[!is.na(matriu1_sum.NA[,6]),"row_label"]
        #G7 <- matriu1_sum.NA[!is.na(matriu1_sum.NA[,3]),"row_label"]
        #G8 <- matriu1_sum.NA[!is.na(matriu1_sum.NA[,3]),"row_label"]
        #G4 <- matriu1_sum.NA[!is.na(matriu1_sum.NA[,4]),"row_label"]
        #input <- list(G1=G1, G2=G2, G3=G3, G4=G4, G5=G5)
        #venn(input)


        #Do the Venn Diagram
        #library(DescTools)
        #PlotVenn(x=(input))

        #install.packages("VennDiagram")


        library(venn)
        #venn(data = input)
        a<-venn::venn(x = input, zcolor = "style",
                   # Increase font size for labels and values
                   cexsn = 2,
                   cexil = 2,
                   borders = FALSE)
        print("Coincidence analysis with Venn analysis")
        print(a)
        #UpSetR is an R implementation of the upset plot format (originally invented by Lex et al., source), that can be used for the visualisation of intersections of multiple sets. The UpsetR library was originally developed for the analysis of genomic data, and published in the journal Bioinformatics in 2017 (source).

        library(UpSetR)
        upset(fromList(input),matrix.color = c("red"),sets.bar.color = "blue",
              number.angles = 20, point.size = 2.5, line.size = 1.5,
              mainbar.y.label = "read intersection", sets.x.label = "read set size",
              text.scale = c(1.5, 1.5, 1.25, 1.25, 1.5, 1.5), mb.ratio = c(0.65, 0.35),
              group.by = "freq", keep.order = TRUE
              )
        #upset(fromList(input), sets = groups)

        #upset(fromList(input),sets = groups,
        #      query.legend = "bottom", number.angles = 30, point.size = 3.5, line.size = 2,
        #      boxplot.summary = c("minAgeRange")
        #)



}


