#algoritmos que tienen que ver con el articulo jordi frias: predecir maximo otus-genes





###############################################################3
# algoritmo para la prediccion maximo otus/genes y reads para llegar al 95% 90% y 99% maximo otu/genes
#input 1: matriz de otus/genes vs muestras, celdas con reads (ej: matriz de otus)
#input 2: vector con contajes de genes/otus cada cierta cantidad de reads (ej: datos de Jordi Frias)
#############################################################################################################
monle.predict.max <- function(type.vector=T, X.reads, Y.otu.gen, n.rounds=100, n.iter=10, max.lim=15e6){
  ######################################################################
  # ALGORITMO PARA PREDECIR NUMERO DE OTUS MAXIMO Y ESFUERZO DE MUESTREO 10-2018
  #######################################################################
  library(xgboost)
  library(nls2)
  library(rcompanion)
  options(show.error.messages=T) # turn off
  #ejemplo con un vector de otus-genes vs reads
  #Y.otu.gen<-c( 6953.333, 12418.333, 17158.000, 21572.667, 25482.000,
  #              29164.333, 32683.333, 36010.000, 39040.000, 41989.000,
  #              42071.000)
  #X.reads<-c(1.0e+05, 2.0e+05, 3.0e+05, 4.0e+05, 5.0e+05, 6.0e+05, 7.0e+05,
  #           8.0e+05, 9.0e+05, 1.0e+06, 2.0e+06)

  vector.reads <- data.frame(X.reads, Y.otu.gen)


  if (type.vector==T){
    #check that the vector is correct: Y.otu.gen, X.reads
    if (dim(vector.reads)[1] < 5){
      print("Wrong lenght, please check carefully the vector")
      break
    }
  }

  #llamar al fichero que tiene las simulaciones y parametros de una serie de 100
  load("simulacionesoct2018.Rda") #llamo al fichero de datos

  #paso1: se estima un modelo weibull de 4 parámetros para ver si lo hace bien o no
  #se hace una aproximacion para dividir el intervalo de reads en 20 partes iguales
  model.SSweibull.W<-NA
  #WEIBULL 4P CON LOS DATOS DEL VECTOR
  res.weib.4p<-Weibull4p(X=X.reads, Y=Y.otu.gen, a=max(Y.otu.gen), b=a, c=-10, d=0.9,Print.curve = F,brfr.it = 10)
  asindota.weibull.W<- as.numeric(res.weib.4p[1])
  b.w4p =as.numeric(res.weib.4p[2])
  c.w4p =as.numeric(res.weib.4p[3])
  d.w4p =as.numeric(res.weib.4p[4])
  #maximo de la primera derivada
  max1p_w4p <-max(b.w4p * (exp(-exp(c.w4p) * X.reads^d.w4p) * (exp(c.w4p) * (X.reads^(d.w4p - 1) * d.w4p))))





  #out.W <- try(model.SSweibull.W <- nls2(Y.otu.gen ~ SSweibull(X.reads, a, b, c, d)))
  #if (substr(out.W[1],1,5) != "Error"){
    #todo correcto
  #  res.5<-accuracy(list(model.SSweibull.W),
  #                  plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
  #  asindota.weibull.W <- coef(model.SSweibull.W)[1]
  #    print("SSweibull.4P CON PRIMEROS DATOS")
  #  print(res.5)
    #parametros del modelo
  #  b.w4p =as.numeric(coef(model.SSweibull.W)[2])
  #  c.w4p =as.numeric(coef(model.SSweibull.W)[3])
  #  d.w4p =as.numeric(coef(model.SSweibull.W)[4])
    #}
  #UTILIZAR METODO DE LM
    #if (substr(out.W[1],1,5) == "Error"){
   #Si el modelo weibull de 4p no se puede calcular entonces hay que hacer una aproximacion numerica
    #print("MODELO WEIBULL4P ALTERNATIVE")
    #MODEL4P_ALT<-(with(resultados.iNEXT.simulacion, lm(max.otu.observado ~ a.logis+ b.logis + c.logis)))#CON LOS LOGISTIC Y MICAELIS MENTEN
    #logis.m <- try(model.SSlogis.mod <- nls(Y.otu.gen ~ SSlogis(X.reads, a, b, c)))
    #if (substr(model.SSlogis.mod[1],1,5) != "Error"){
    # a.logis.m =as.numeric(coef(model.SSlogis.mod)[1])
     #b.logis.m =as.numeric(coef(model.SSlogis.mod)[2])
     #c.logis.m =as.numeric(coef(model.SSlogis.mod)[3])

    # Set initial values for the parameters
    #asindota.weibull.W<-a.logis.m; b <- a.logis.m;     c <- mean(resultados.iNEXT.simulacion$c.weib4p,na.rm = T);     d <- mean(resultados.iNEXT.simulacion$d.weib4p,na.rm = T)
     #c.max <- 2*max(resultados.iNEXT.simulacion$c.weib4p,na.rm = T)
     #d.max <- 2*max(resultados.iNEXT.simulacion$d.weib4p,na.rm = T)
     #c.min <- min(resultados.iNEXT.simulacion$c.weib4p,na.rm = T)/2
     #d.min <- min(resultados.iNEXT.simulacion$d.weib4p,na.rm = T)/2

     # Fit the data with a weibull 3p
    #library(minpack.lm)
    #model.SSweibull.W <- nlsLM(formula = Y.otu.gen ~ asindota.weibull.W-b*exp(-exp(c)*X.reads^d),
    #                 control = nls.lm.control(ftol = 1e-5, ptol = 1e-5),
    #                 data=vector.reads,
    #                  start = list(b=b, c=c, d=d),
    #                  lower = c(b = 0, c = -Inf, d = -Inf),
    #                  upper = c( b = Inf, c = 0, d = Inf))

     #parametros del modelo
    #b.w4p =as.numeric(coef(model.SSweibull.W)[1])
    #c.w4p =as.numeric(coef(model.SSweibull.W)[2])
    #d.w4p =as.numeric(coef(model.SSweibull.W)[3])

     #maximo de la primera derivada
    #max1p_w4p <-max(b.w4p * (exp(-exp(c.w4p) * x^d.w4p) * (exp(c.w4p) * (x^(d.w4p - 1) * d.w4p))))

    #}
    #if (substr(model.SSlogis.mod[1],1,5) == "Error"){
    #  print("Error de todo se recomienda algoritmo fuerza bruta")
     #fALLA TODO
     #aa<-Weibull4p(X=samples, Y=Y.otu.gen, a=max(X.reads), b=a, c=-10, d=0.9,Print.curve = T)
     #aa

     #parametros del modelo
     #a.w4p=as.numeric(coef(model.SSweibull.W)[1])
     #b.w4p =as.numeric(coef(model.SSweibull.W)[1])
     #c.w4p =as.numeric(coef(model.SSweibull.W)[2])
     #d.w4p =as.numeric(coef(model.SSweibull.W)[3])

     #maximo de la primera derivada
     #max1p_w4p <-max(b.w4p * (exp(-exp(c.w4p) * x^d.w4p) * (exp(c.w4p) * (x^(d.w4p - 1) * d.w4p))))

    #}

      #Ahora se pueden utilizar los dos algoritmos para hacer los calculos de las estimaciones del modelo Weibull
      #model.weibull4P.ALT <-nlsLM(Y.otu.gen ~ Asym1-Drop*exp(-exp(lrc)*X.reads^pwr), start = list(Drop=Asym1, lrc=1, pwr=1 ))
      #b.w4p<-summary(model.weibull4P.ALT )$parameters[1]
      #c<-summary(model.weibull4P.ALT )$parameters[2]
      #d<-summary(model.weibull4P.ALT )$parameters[3]

      #grafica en pantalla estimada a partir del primer millon 1M
      #curve(Asym1.es1-Drop*exp(-exp(lrc)*x^pwr), col = "red", lty=1, add = TRUE)
      ########(lwr)#########################################

      #break
  #}

  #prediccion usando una weibull 4p
  out.W <- try(model.SSweibull.W <- nlsLM(formula = Y.otu.gen ~ asindota.weibull.W-b.w4p*exp(-exp(c.w4p)*X.reads^d),
                                          control = nls.lm.control(ftol = 1e-5, ptol = 1e-5),
                                          data=vector.reads,
                                          start = list( d=d.w4p),
                                          lower = c(  d = 0),
                                          upper = c(  d = 100)))
  if (substr(out.W[1],1,5) != "Error"){
    #no hay error
    #ver los par?metros estimados
    #summary(model.SSweibull)
    seq.a<-seq(min(X.reads), max(X.reads), length.out = 20)
    #100 predicciones por cada curva
    predicio.W<-predict(model.SSweibull.W,newdata = data.frame(X.reads=seq.a))
    #aqui llamar a la linea 253 de PILI3.MetagenSample.size.READS.OTU.GENES
    #reads<-as.matrix(a) #m son las READS - m
    #otu<-as.matrix(predicio) #m son las otus - qD
    #contiuar en PILI3.MetagenSample.size.READS.OTU.GENES
    ##AnalysismodelWeibull(readsX=reads, otuY=otu)
  }
  if (substr(out.W[1],1,5) == "Error"){
    #problema grande
    print("Big error in line 158")
    break

  }



  reads<-as.vector(seq.a)
  otu<-as.vector(predicio.W) #prediccion hecha con Weibull 4p del primero trocillo
  newdata <- data.frame(X2=reads[1],
                        X3=reads[2],
                        X4=reads[3],
                        X5=reads[4],
                        X6= reads[5],
                        X7= reads[6],
                        X8= reads[7],
                        X9= reads[8],
                        X10= reads[9],X11= reads[10],X12= reads[11],X13= reads[12],X14= reads[13],X15= reads[14],
                        X16= reads[16], X17= reads[17], X18= reads[18], X19= reads[19], X20= reads[20],
                        Y2= otu[1],
                        Y3= otu[2],
                        Y4= otu[3],
                        Y5= otu[4],
                        Y6= otu[5],
                        Y7= otu[6],
                        Y8= otu[7],
                        Y9= otu[8],
                        Y10= otu[9],Y11= otu[10],Y12= otu[11],Y13= otu[12],Y14= otu[13],Y15= otu[14],
                        Y16= otu[15],Y17= otu[16],Y18= otu[17],Y19= otu[18],Y20= otu[19])

  #newdata1 <- data.frame(X2=reads[1],
  #                      X3=reads[2],
  #                      Y2= otu[1],
  #                      Y3= otu[2])
#a.logis, a.weib4p, minotu.vector, maxotu.vector, minreads.vector, maxreads.vector
  #ANADIR A LOGISTIC---------->
  y=as.numeric(newdata[,20:38])
  x=as.numeric(newdata[,1:19])
  #View(zzz)
  out222 <- try(model.SSlogis22 <- nls(y ~ SSlogis(x, a, b, c)))
  if (substr(out222[1],1,5) != "Error"){
    a.logis22 =as.numeric(coef(model.SSlogis22)[1])
    b.logis22 =as.numeric(coef(model.SSlogis22)[2])
    c.logis22 =as.numeric(coef(model.SSlogis22)[3])
  }
  if (substr(out222[1],1,5) == "Error"){
    a.logis22 =NA
    b.logis22 =NA
    c.logis22 =NA
  }
  #AÑADIR A MICAELIS-MENTEN------>
  model.SSweibull33<-NA
  out333 <- try(model.SSweibull33 <- nls2(y ~ SSmicmen(x, a, b)))
  if (substr(out333[1],1,5) != "Error"){
    a.SSmicmen =as.numeric(coef(model.SSweibull33)[1])
    b.SSmicmen =as.numeric(coef(model.SSweibull33)[2])
  }
  if (substr(out333[1],1,5) == "Error"){
    a.SSmicmen =NA
    b.SSmicmen =NA
  }

  #dataframe para predecir max otus y maximo reads
  # ESTE MODELO SALE BASTANTE BIEN EN LAS PRUEBAS CON UN MENOR MAE
  newdata1 <- data.frame(a.logis<-a.logis22,
                         a.weib4p<-as.numeric(asindota.weibull.W),
                         minotu.vector<-min(Y.otu.gen),
                         maxotu.vector<-max(Y.otu.gen),
                         minreads.vector<-min(X.reads),
                         maxreads.vector<-max(X.reads))

  colnames(newdata1)<-c("a.logis","a.weib4p", "minotu.vector", "maxotu.vector", "minreads.vector", "maxreads.vector")
  #newdata1$a.logis<-a.logis22
  #newdata$b.logis<-b.logis22
  #newdata$c.logis<-c.logis22
  #newdata$a.MIME<-a.SSmicmen
  #newdata$b.MIME<-b.SSmicmen
  #newdata1$a.weib4p<-as.numeric(asindota.weibull.W)
  #newdata$b.weib4p<- b.w4p
  #newdata$max1p.w4p<-as.numeric(max1p_w4p)
  #newdata$max1p.w4p<-as.numeric(max1p_w4p)
  #newdata1$minotu.vector<-min(Y.otu.gen)
  #newdata1$maxotu.vector<-max(Y.max.otu)
  #newdata1$minreads.vector<-min(X.reads)
  #newdata1$maxreads.vector<-max(X.reads)
  #a.logis, a.weib4p, minotu.vector, maxotu.vector, minreads.vector, maxreads.vector
  #X.reads, Y.otu.gen
  #llamar al fichero que tiene las siulaciones y parametros de una serie de 100
  #load("simulacionesoct2018.Rda") #llamo al fichero de dato
  #n.iter<-100
  res.model.OTUS  <- array(NA, dim=c(n.iter,10)) #DONDE SE GUARDAN RESULTADOS OTUS
  res.model.READS95  <- array(NA, dim=c(n.iter,10)) #DONDE SE GUARDAN RESULTADOS READS 95% MAX
  #se hacen iteraciones del modelo Xboost para tener un buen IC
  for(l in 1:n.iter){
    #l=1
    #TODO REPETIDO VARIAS VECES
    clase.todo<- resultados.iNEXT.simulacion$max.otu.observado #MAXIMO DE OTUS
    clase.todo1<- resultados.iNEXT.simulacion$reads_95 #MAXIMO 95%

    #PREDICTOR XBOOST PARA MAXIMO NUMERO DE OTUS
    #dtodo <- xgb.DMatrix(data = as.matrix(resultados.iNEXT.simulacion[,c(2:20,22:40,50, 57)]), label = clase.todo)
    dtodo <- xgb.DMatrix(data = as.matrix(resultados.iNEXT.simulacion[,c(50, 57, 63:66)]), label = clase.todo)

    xgb_model3 <- xgboost(data = dtodo,
                          nrounds=n.rounds,
                          objective = "reg:linear",
                          eval_metric = "rmse",
                          subsample = .8,
                          colsample_bytree = .8  )
    pred.OTUS<-predict(xgb_model3, as.matrix(newdata1))

    #MODELO LINEAL-parece que sale mejor en las pruebas pero despues no es asi, mejor el xboost
    #lm_model3 <- lm(reads_95~a.logis + a.weib4p
    #              + minotu.vector +     maxotu.vector +
    #                minreads.vector +    maxreads.vector,
    #                data=resultados.iNEXT.simulacion)
    #head(resultados.iNEXT.simulacion[,c(50, 57, 63:66)])
    #head(resultados.iNEXT.simulacion$max.otu.observado)
    #summary(lm_model3)
    #pred.READS95<-predict(lm_model3, as.matrix(newdata1))
    #newdata2 <- data.frame(a.logis<-42990.46,
    #                       a.weib4p<-43063.07,
    #                       minotu.vector<-6953.333,
    #                       maxotu.vector<-42071,
    #                       minreads.vector<-1e+05,
    #                       maxreads.vector<-2e+06)
    #pred.OTUS<-predict(lm_model3, newdata2)




    #restriccion sobre valores ngativos
    if(pred.OTUS<0){pred.OTUS<-max(Y.otu.gen)}

    #pred.OTUS1<-predict(lm_model3, newdata=data.frame(a.logis<-7279.15, a.weib4p<-7270.084))
    res.model.OTUS[l]<-pred.OTUS

    #PREDICTOR XBOOST PARA READS PARA EL 95%
    #dtodo1 <- xgb.DMatrix(data = as.matrix(resultados.iNEXT.simulacion[,c(50, 57, 63:66)]), label = clase.todo1)

    #xgb_model4 <- xgboost(data = dtodo1,
    #                      nrounds=n.rounds,
    #                      objective = "reg:linear",
    #                      eval_metric = "rmse",
    #                      subsample = .8,
    #                      colsample_bytree = .8  )
    #pred.READS95<-predict(xgb_model4, as.matrix(newdata1))
    #seleccion al azar de resultados
    df<-resultados.iNEXT.simulacion
    n1<-round(0.8*dim(resultados.iNEXT.simulacion)[1],0)
    df1<-df[sample(nrow(df), n1), ]
    lm_model3 <- lm(reads_95~a.logis + a.weib4p
                  + minotu.vector +     maxotu.vector +
                    minreads.vector +    maxreads.vector,
                    data=df1)
    #head(resultados.iNEXT.simulacion[,c(50, 57, 63:66)])
    #head(resultados.iNEXT.simulacion$max.otu.observado)
    #summary(lm_model3)
    pred.READS95<-predict(lm_model3, (newdata1))
    res.model.READS95[l]<-pred.READS95
    #pred.READS95<-predict(xgb_model3, as.matrix(newdata1))
    #res.model.READS95[l]<-pred.READS95
  }

  #guardar LOS DATOS ESTIMADOS Y PREDICHOS------
  resultados.curvas.jordifrias  <- array(NA, dim=c(1,10))
  KK<-1
  resultados.curvas.jordifrias[KK,1]<- KK

  print("################################################")
  #ofrece como resultados las predicciones con su Ic percentil
  print("Prediccion OTUMAX ML 20% DATOS:-------------------")
  print(quantile(res.model.OTUS[,1], probs = c(0.025, 0.5, 0.975),na.rm = T))
  #guardar Prediccion OTUMAX ML 20% DATOS------
  resultados.curvas.jordifrias[KK,2]<- quantile(res.model.OTUS[,1], probs = c(0.025),na.rm = T)
  #guardar Prediccion OTUMAX ML 20% DATOS------
  resultados.curvas.jordifrias[KK,3]<- quantile(res.model.OTUS[,1], probs = c(0.5),na.rm = T)
  #guardar Prediccion OTUMAX ML 20% DATOS------
  resultados.curvas.jordifrias[KK,4]<- quantile(res.model.OTUS[,1], probs = c(0.975),na.rm = T)

  otumax.1q<-resultados.curvas.jordifrias[KK,2]
  #guardar Prediccion OTUMAX ML 20% DATOS------
  otumax.2q<-resultados.curvas.jordifrias[KK,3]
  #guardar Prediccion OTUMAX ML 20% DATOS------
  otumax.3q<-resultados.curvas.jordifrias[KK,4]
  diferencia.q3.q1 <-(otumax.3q-otumax.1q)/2

  print("################################################")
  #ofrece como resultados las predicciones con su Ic percentil
  print("Prediccion READS95% ML 20% DATOS:-------------------")
  print(quantile(res.model.READS95[,1], probs = c(0.025, 0.5, 0.975),na.rm = T))
  #guardar Prediccion OTUMAX ML 20% DATOS------
  resultados.curvas.jordifrias[KK,5]<- quantile(res.model.READS95[,1], probs = c(0.025),na.rm = T)
  #guardar Prediccion OTUMAX ML 20% DATOS------
  resultados.curvas.jordifrias[KK,6]<- quantile(res.model.READS95[,1], probs = c(0.5),na.rm = T)
  #guardar Prediccion OTUMAX ML 20% DATOS------
  resultados.curvas.jordifrias[KK,7]<- quantile(res.model.READS95[,1], probs = c(0.975),na.rm = T)

  print("################################################")

  #plot
  limotu<-as.numeric(quantile(res.model.OTUS[,1], probs = c(0.999),na.rm = T))
  limREAD<-as.numeric(quantile(res.model.READS95[,1], probs = c(0.999),na.rm = T))


  #plot
  plot(Y.otu.gen ~ X.reads, ylim=c(0,2*limotu), xlim=c(0,max.lim), col = "black", pch=8, xlab="Reads", ylab="Genes/OTUS")
  #
  #plot(Y.otu.gen ~ X.reads, main = "prediction Weibull Xboost", ylim=c(0,2*limotu), xlim=c(0,max.lim), col = 2, pch=8)
  #grafica en pantalla estimada a partir del primer millon 1M
  #calculos
  color.white=rgb(0,0,0,alpha=0) #para aumentar la transparencia
  q0.50<-curve(otumax.2q-otumax.2q*exp(-exp(c.w4p)*x^d.w4p), col = color.white, lwd=0, lty=2, add = TRUE)
  q0.025<-curve(otumax.1q-otumax.1q*exp(-exp(c.w4p)*x^d.w4p), col = color.white, lwd=0, lty=2, add = TRUE)
  q0.975<-curve(otumax.3q-otumax.3q*exp(-exp(c.w4p)*x^d.w4p), col = color.white, lwd=0, lty=2, add = TRUE)

  #quizas calcular los maximos reads
  #95% esfuerzo maximo
  #y <- 0.95*otumax.2q
  #x.para.maximo.95_2q1<- as.numeric((log((otumax.2q-y)/otumax.2q)/-exp(c.w4p))^(1/d.w4p) )
  #y <- 0.95*otumax.1q
  #x.para.maximo.95_2q2<- as.numeric((log((otumax.1q-y)/otumax.1q)/-exp(c.w4p))^(1/d.w4p) )
  #y <- 0.95*otumax.3q
  #x.para.maximo.95_2q3<- as.numeric((log((otumax.3q-y)/otumax.3q)/-exp(c.w4p))^(1/d.w4p) )
  #print("reads95% max otus: media(IC95% &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
  #print(x.para.maximo.95_2q1)
  #print(x.para.maximo.95_2q2)
  #print(x.para.maximo.95_2q3)
  #print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")

  #dibujo de las curvas predichas para maximo otu
  #curve(otumax.2q-otumax.2q*exp(-exp(c.w4p)*x^d.w4p), col = "green", lty=1, add = TRUE)
  #curve(otumax.1q-otumax.1q*exp(-exp(c.w4p)*x^d.w4p), col = "red", lty=2, add = TRUE)
  #curve(otumax.3q-otumax.3q*exp(-exp(c.w4p)*x^d.w4p), col = "red", lty=2, add = TRUE)


 #dibujo curva corregida final con w3p
  #curva sugerida con una W3p y una w4p

  #aqui se dibuja la curva w4p corregida y centrada:
  w1<-Weibull3p(X=X.reads, Y=Y.otu.gen,
                asindota.weibull.W = otumax.2q, b= otumax.2q, c=c.w4p, d=d.w4p,suggest.w4p=T,
                Print.curve = T)
  #q0.50<-curve(otumax.2q-otumax.2q*exp(-exp(c.w4p)*x^d.w4p), col = "green", lty=1, add = TRUE)
  #q0.025<-curve(otumax.1q-otumax.1q*exp(-exp(c.w4p)*x^d.w4p), col = "red", lty=2, add = TRUE)
  #q0.975<-curve(otumax.3q-otumax.3q*exp(-exp(c.w4p)*x^d.w4p), col = "red", lty=2, add = TRUE)

  #calcular las Curvas W4P que son intervalo de confianza, superior e inferior
  w1y<-unlist(sapply(w1[6], function(x) x)[2,])
  w1x<-unlist(sapply(w1[6], function(x) x)[1,])
  q0.025y<-unlist(sapply(q0.025, function(x) x)[,2])
  q0.50y<-unlist(sapply(q0.50, function(x) x)[,2])
  q0.975y<-unlist(sapply(q0.975, function(x) x)[,2])

  #lineas de intervalos de confianza 0.025-0.975
  #lineas del minimo y del maximo IC95%
  lines(w1x, q0.025y + (w1y-q0.50y), col = "blue", lty=2, lwd=1.5) #minimo IC95% (0.025)
  lines(w1x, q0.975y + (w1y-q0.50y), col = "blue", lty=2, lwd=1.5) #maximo IC95% (0.975)
  #calcular los reads del 90,95 y 99% numericamente
  #reads.curva.50 <- Weibull3p(X=X.reads, Y=Y.otu.gen, a=otumax.2q, b = a, c=c.w4p, d=d.w4p, Print.curve = F)
  reads.curva.05 <- Weibull3p(X=w1x, Y=q0.025y + (w1y-q0.50y), asindota.weibull.W=max(q0.025y + (w1y-q0.50y)), b = asindota.weibull.W, c=c.w4p, d=d.w4p, Print.curve = F)
  reads.curva.95 <- Weibull3p(X=w1x, Y=q0.975y + (w1y-q0.50y), asindota.weibull.W=max(q0.975y + (w1y-q0.50y)), b = asindota.weibull.W, c=c.w4p, d=d.w4p, Print.curve = F)
  #control de errores en esa parte:
  re.q2<-as.numeric(w1[8]) #quartil 2 50%
  re.q1<-as.numeric(reads.curva.05[8]) # 0.025
  re.q3<-as.numeric(reads.curva.95[8]) #0.0975
  if(re.q1>re.q2){re.q1<-0 }
  if(re.q3<re.q2){re.q3<-Inf }

  title(main = "Predicted model")
  text1<-paste( "Max=", round(max(q0.50y),1), " [",round(max(q0.025y + (w1y-q0.50y)),1) , "-",round(max(q0.975y + (w1y-q0.50y)),1), "]" ,
                " , R95% =", round(as.numeric(re.q2),0), " [", round(as.numeric(re.q1),0), "-", round(as.numeric(re.q3),0), " ]", sep = "")

  #CON READS95% CON BAGGING XBOOST o prediccion lm:
  q1reads95 <- resultados.curvas.jordifrias[KK,5]
  #guardar Prediccion OTUMAX ML 20% DATOS------
  q2reads95<-resultados.curvas.jordifrias[KK,6]
  #guardar Prediccion OTUMAX ML 20% DATOS------
  q3reads95<- resultados.curvas.jordifrias[KK,7]
  #text2<-paste( "Max=", round(max(q0.50y),1), " [",round(max(q0.025y + (w1y-q0.50y)),1) , "-",round(max(q0.975y + (w1y-q0.50y)),1), "]" ,
  #              " , R95% =", round(as.numeric(q1reads95),0), " [", round(as.numeric(q2reads95),0), "-", round(as.numeric(q3reads95),0), " ]", sep = "")
  #text1
  mtext(text1, side = 3) #si cojo el metodo de calculo numerico del reads95%
  #mtext(text2, side = 4) #si utilizo el metodo de bagging

  return(list(resultados.curvas.jordifrias))


}

############ EJEMPLO DE USO ###########################
#monle.predict.max(type.vector=T,
#                  X.reads<-c(1.0e+05, 2.0e+05, 3.0e+05, 4.0e+05, 5.0e+05, 6.0e+05, 7.0e+05,
#                  8.0e+05, 9.0e+05, 1.0e+06, 2.0e+06),
#                  Y.otu.gen<-c( 6953.333, 12418.333, 17158.000, 21572.667, 25482.000,
#                  29164.333, 32683.333, 36010.000, 39040.000, 41989.000,
#                  42071.000),n.rounds=100, n.iter=5)



#funcion complementaria para el calculo de los parametros de una funcion weibull de 3 parametros si se le da a (asintota)
#X= valores de X, Y = valores de Y
#sugiere tambienq ue se cambie si hay otro maximo mejor

Weibull3p<- function(X, Y, asindota.weibull.W, b = asindota.weibull.W, c, d, suggest.w4p=F, Print.curve = T, brfr.it=10){
  options(show.error.messages=T) # turn off

  best.is.4p1<-F
  a.w4p.suggested<-asindota.weibull.W

  library(minpack.lm)
  out222 <- try(model.SSweibull.W <-  nlsLM(formula = Y ~ asindota.weibull.W-b*exp(-exp(c)*X^d) ,
                                            control = nls.lm.control(ftol = 1e-5, ptol = 1e-5),
                                            start = list(b=b, c=c, d=d),
                                            lower = c(b = 0, c = -Inf, d = -Inf),
                                            upper = c( b = Inf, c = Inf, d = Inf)))
  #no hay errores de ningun tipo
  if (substr(out222[1],1,5) != "Error"){
    #parametros del modelo
    b.w4p =as.numeric(coef(model.SSweibull.W)[1])
    c.w4p =as.numeric(coef(model.SSweibull.W)[2])
    d.w4p =as.numeric(coef(model.SSweibull.W)[3])
  }

  if (substr(out222[1],1,5) == "Error"){
    #habra que poner un metodo numerico que lo calcule con un grid y fuerza bruta
    #Weibull 3 prametros
    print("Force brute algorithm nls2. Long time...Wait a moment")
    fo <- Y ~ asindota.weibull.W-b*exp(-exp(c)*X^d)
    st1 <- expand.grid(b = seq(0, asindota.weibull.W*3, len = brfr.it), c = seq(-30, 0, len = brfr.it), d=seq(0.5, 4, len=brfr.it))
    out2222 <- try(model.SSweibull.W2 <- nls2(fo, start = st1, algorithm = "brute-force"))
    if (substr(out2222[1],1,5) != "Error"){
      b.w4p =as.numeric(coef(model.SSweibull.W2)[1])
      c.w4p =as.numeric(coef(model.SSweibull.W2)[2])
      d.w4p =as.numeric(coef(model.SSweibull.W2)[3])
      #model.SSweibull.W<-model.SSweibull.W2
    }

  }


  if (suggest.w4p==T){
    #quizas esta parte la puedo subtituir por weibul4p
    #sugiere un nuevo punto a, a ver si es mejor y quizas unos intervalos de confianza?
    if (substr(model.SSweibull.W[1],1,5) != "Error"){
      aaAAA.W4P<-Weibull4p(X=X, Y=Y, a=asindota.weibull.W, b=b.w4p, c=c.w4p, d=d.w4p,Print.curve = F,brfr.it = 10)

      #model.SSweibull.W1 <- nlsLM(formula = Y ~ a-b*exp(-exp(c)*X^d),
      #                            control = nls.lm.control(ftol = 1e-5, ptol = 1e-5),
      #                            start = list(a=asindota.weibull.W, b=b.w4p, c=c.w4p, d=d.w4p),
      #                            lower = c(a=0, b = 0, c = -Inf, d = -Inf),
      #                            upper = c(b = Inf,  b = Inf, c = Inf, d = Inf))

      if( abs(a.w4p.suggested - max(Y)) < abs(asindota.weibull.W - max(Y))  | (max(Y)> asindota.weibull.W) ){
        best.is.4p1<-T
        a.w4p.suggested<-as.numeric(aaAAA.W4P[1])
        b.w4p =as.numeric(aaAAA.W4P[2])
        c.w4p =as.numeric(aaAAA.W4P[3])
        d.w4p =as.numeric(aaAAA.W4P[4])
      }

    }
  }

  #analisis de la curva: X para 90,95 y 99% maximo
  #grafica en pantalla estimada a partir del primer millon 1M
  #curve( (Asym1.es.upr)-Drop.upr*exp(-exp(lrc.upr)*x^pwr.upr), col = "red", lty=2, add = TRUE)
  ################ CALCULO DEL ESFUERZO 90 Y 95% DEL MAXIMO DE LOS GENES ##########################
  ##### metodo analitico (utilizando la funcion inversa)##########################
  #esfuerzo para el 90% del maximo de genes
  #La funcion inversa es: x <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
  #90% del esfuerzo maximo
  y <- 0.90*a.w4p.suggested
  x.para.maximo.90_1<- as.numeric((log((a.w4p.suggested-y)/b.w4p)/-exp(c.w4p))^(1/d.w4p) )
  #95% esfuerzo maximo
  y <- 0.95*a.w4p.suggested
  x.para.maximo.95_1<- as.numeric((log((a.w4p.suggested-y)/b.w4p)/-exp(c.w4p))^(1/d.w4p) )
  #99% esfuerzo maximo
  y <- 0.99*a.w4p.suggested
  x.para.maximo.99_1<- as.numeric((log((a.w4p.suggested-y)/b.w4p)/-exp(c.w4p))^(1/d.w4p) )
  #vector resultante
  #x<-seq(min(X), max(X), length.out = 200)

  #print curve
  if(Print.curve == T){
    #plot(X,Y)
    curve(a.w4p.suggested-b.w4p*exp(-exp(c.w4p)*x^d.w4p), col = "red", lty=1, lwd=2, add = TRUE)
  }
  color.white=rgb(0,0,0,alpha=0) #para aumentar la transparencia
  vec.curve<-curve(a.w4p.suggested-b.w4p*exp(-exp(c.w4p)*x^d.w4p), col = color.white, lty=2, lwd=0, add = TRUE,n = 50000)
  #metodo numerico
  reads.90.otu<-a.w4p.suggested*0.9
  reads.95.otu<-a.w4p.suggested*0.95
  reads.99.otu<-a.w4p.suggested*0.99
  #hay que aumentar el numero de puntos del vector (pueden ser muy pocos)
  #vec.curve.x1<-seq(min(vec.curve$x), max(vec.curve$x), length.out = 200)
  #100 predicciones por cada curva
  #vec.curve.y1<-predict(model.SSweibull.W,newdata = data.frame(X.reads=seq.a))
  #approx() toni por aquii
  #interp.vect<-approx(x=vec.curve$x, y=vec.curve$y,n = 200)
  #mat.res<-curva.rarefaccion.predicha.weibull
  #for (i in 1:length(vec.curve$y)){ #el metodo es regular-es una aproximacion
    #i<-1
    #y otu // x son reads
    #reads para cobertura segun ToniM
  #  if(vec.curve$y[i]<=reads.90.otu){ x.para.maximo.90=vec.curve$x[i]}
  #  if(vec.curve$y[i]<=reads.95.otu){ x.para.maximo.95=vec.curve$x[i]}
  #  if(vec.curve$y[i]<=reads.99.otu){ x.para.maximo.99=vec.curve$x[i]}
  #}
  color.white=rgb(0,0,0,alpha=0) #para aumentar la transparencia
  vec.curve<-curve(a.w4p.suggested-b.w4p*exp(-exp(c.w4p)*x^d.w4p), col = color.white, lty=2, lwd=0, add = TRUE)







  return(list(b.w4p, c.w4p, d.w4p, a.w4p.suggested,best.is.4p1, vec.curve, x.para.maximo.90_1, x.para.maximo.95_1, x.para.maximo.99_1))
}


############ EJEMPLO DE USO ###########################
#Weibull3p(X<-c(1.0e+05, 2.0e+05, 3.0e+05, 4.0e+05, 5.0e+05, 6.0e+05, 7.0e+05,
#                  8.0e+05, 9.0e+05, 1.0e+06, 2.0e+06),
#                  Y<-c( 6953.333, 12418.333, 17158.000, 21572.667, 25482.000,
#                  29164.333, 32683.333, 36010.000, 39040.000, 41989.000,
#                  42071.000), asindota.weibull.W = 42000, b = 42000, c=-10, d=0.9,Print.curve = T,suggest.w4p=T)

#aaa<-Weibull3p(X<-c(1.0e+05, 2.0e+05, 3.0e+05, 4.0e+05, 5.0e+05, 6.0e+05, 7.0e+05,
#               8.0e+05, 9.0e+05, 1.0e+06, 2.0e+06),
#          Y<-c( 6953.333, 12418.333, 17158.000, 21572.667, 25482.000,
#                29164.333, 32683.333, 36010.000, 39040.000, 41989.000,
#                42071.000), asindota.weibull.W = 42000, b = 42000, c=-10, d=0.9,Print.curve = T,suggest.w4p=T)



Weibull4p<- function(X, Y, a, b = a, c, d, Print.curve = T, brfr.it=10){

  options(show.error.messages=T) # turn off

  library(minpack.lm)
  library(nls2)

  out222 <- try(model.w4p <- nls(Y ~ SSweibull(X, a, b, c,d)))
  if (substr(out222[1],1,5) != "Error"){
    a.w4p =as.numeric(coef(model.w4p)[1])
    b.w4p =as.numeric(coef(model.w4p)[2])
    c.w4p =as.numeric(coef(model.w4p)[3])
    d.w4p =as.numeric(coef(model.w4p)[4])
    print("uno")
    #gooness of fit (R2)
    good.fit.model<-accuracy(list(model.w4p),
                    plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
    print("Efron.r.squared: weibull4p nls2")
    print(good.fit.model)
  }
  if (substr(out222[1],1,5) == "Error"){
      a.w4p =NA
      b.w4p =NA
      c.w4p =NA
      d.w4p =NA
      #sugiere un nuevo punto a, a ver si es mejor y quizas unos intervalos de confianza?
      print("dos")
      out333 <- try(model.SSweibull.W1 <- nlsLM(formula = Y ~ a-b*exp(-exp(c)*X^d),
                                  control = nls.lm.control(ftol = 1e-5, ptol = 1e-5),
                                  start = list(a=a, b=a, c=c, d=d),
                                  lower = c(a=0, b = 0, c = -Inf, d = -Inf),
                                  upper = c(b = Inf,  b = Inf, c = Inf, d = Inf)))

      if (substr(out333[1],1,5) != "Error"){
          a.w4p<-as.numeric(coef(model.SSweibull.W1)[1])
          b.w4p =as.numeric(coef(model.SSweibull.W1)[2])
          c.w4p =as.numeric(coef(model.SSweibull.W1)[3])
          d.w4p =as.numeric(coef(model.SSweibull.W1)[4])
          print("cuatro")

          #gooness of fit (R2)
          good.fit.model<-accuracy(list(model.SSweibull.W1),
                                   plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
          print("Efron.r.squared: weibull4p nls2")
          print(good.fit.model)
        }
      if (substr(out333[1],1,5) == "Error"){
        print("Force brute algorithm nls2. Long time...Wait a moment")
        fo <- Y ~ a-b*exp(-exp(c)*X^d)
        st1 <- expand.grid(a = seq(0, a*3, len = brfr.it),b = seq(0, a*3, len = brfr.it), c = seq(-30, 0, len = brfr.it), d=seq(0.5, 4, len=brfr.it))
        out2222 <- try(model.SSweibull.W3 <- nls2(fo, start = st1, algorithm = "brute-force"))
        print("cinco")

        if (substr(out2222[1],1,5) != "Error"){
          a.w4p<-as.numeric(coef(model.SSweibull.W3)[1])
          b.w4p =as.numeric(coef(model.SSweibull.W3)[2])
          c.w4p =as.numeric(coef(model.SSweibull.W3)[3])
          d.w4p =as.numeric(coef(model.SSweibull.W3)[4])
          print("seis")

          #gooness of fit (R2)
          good.fit.model<-accuracy(list(model.SSweibull.W3),
                                   plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
          print("Efron.r.squared: weibull4p nls2")
          print(good.fit.model)
        }


      }


    }

  if(is.na(a.w4p)==F){

    #numero de reads para el 95%---------------------
    #metodo analitico-con la inversa
    #analisis de la curva: X para 90,95 y 99% maximo
    #grafica en pantalla estimada a partir del primer millon 1M
    #curve( (Asym1.es.upr)-Drop.upr*exp(-exp(lrc.upr)*x^pwr.upr), col = "red", lty=2, add = TRUE)
    ################ CALCULO DEL ESFUERZO 90 Y 95% DEL MAXIMO DE LOS GENES ##########################
    #esfuerzo para el 90% del maximo de genes
    #La funcion inversa es: x <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
    #90% del esfuerzo maximo
    y <- 0.90*a.w4p
    x.para.maximo.90_1<- as.numeric((log((a.w4p-y)/b.w4p)/-exp(c.w4p))^(1/d.w4p) )
    #95% esfuerzo maximo
    y <- 0.95*a.w4p
    x.para.maximo.95_1<- as.numeric((log((a.w4p-y)/b.w4p)/-exp(c.w4p))^(1/d.w4p) )
    #99% esfuerzo maximo
    y <- 0.99*a.w4p
    x.para.maximo.99_1<- as.numeric((log((a.w4p-y)/b.w4p)/-exp(c.w4p))^(1/d.w4p) )

    #print curve
    if(Print.curve == T){
      #plot(X,Y, xlim=c(0,max(x.para.maximo.99, X)), ylim=c(0,1.5*a.w4p))
      curve(a.w4p-b.w4p*exp(-exp(c.w4p)*x^d.w4p), col = "blue", lty=2, lwd=1, add = TRUE)
    }
    #vector resultante (curva weibull)
    color.white=rgb(0,0,0,alpha=0) #para aumentar la transparencia
    vec.curve<-curve(a.w4p-b.w4p*exp(-exp(c.w4p)*x^d.w4p), col = color.white, lty=0, lwd=1, add = TRUE,n=50000)

    #metodo numerico (sale regular): consiste en aproximar el valor
    #reads.90.otu<-a.w4p*0.9
    #reads.95.otu<-a.w4p*0.95
    #reads.99.otu<-a.w4p*0.99
    #mat.res<-curva.rarefaccion.predicha.weibull
    #for (i in 1:length(vec.curve$y)){
      #i<-1
      #y otu // x son reads
      #reads para cobertura segun ToniM
    #  if(vec.curve$y[i]<=reads.90.otu){ x.para.maximo.90=vec.curve$x[i]}
    #  if(vec.curve$y[i]<=reads.95.otu){ x.para.maximo.95=vec.curve$x[i]}
    #  if(vec.curve$y[i]<=reads.99.otu){ x.para.maximo.99=vec.curve$x[i]}
    #}
    color.white=rgb(0,0,0,alpha=0) #para aumentar la transparencia
    vec.curve<-curve(a.w4p-b.w4p*exp(-exp(c.w4p)*x^d.w4p), col = color.white, lty=0, lwd=1, add = TRUE)




  }
  #todo mal no sale nada de nada
  if(is.na(a.w4p)==T){
    vec.curve=NA
  }

  return(list(a.w4p, b.w4p, c.w4p, d.w4p, x.para.maximo.90_1, x.para.maximo.95_1, x.para.maximo.99_1, vec.curve, good.fit.model))

  }

#X, Y, a, b = a, c, d, Print.curve = T
#X<-c(1.0e+05, 2.0e+05, 3.0e+05, 4.0e+05, 5.0e+05, 6.0e+05, 7.0e+05,
#                    8.0e+05, 9.0e+05, 1.0e+06, 2.0e+06)
#Y<-c( 6953.333, 12418.333, 17158.000, 21572.667, 25482.000,
      #                29164.333, 32683.333, 36010.000, 39040.000, 41989.000,
      #                42071.000)
#plot(X,Y, xlim=c(0,15e6), ylim=c(0,1.5*max(Y)))
#aaa<-Weibull4p(X<-c(1.0e+05, 2.0e+05, 3.0e+05, 4.0e+05, 5.0e+05, 6.0e+05, 7.0e+05,
#               8.0e+05, 9.0e+05, 1.0e+06, 2.0e+06),
#          Y<-c( 6953.333, 12418.333, 17158.000, 21572.667, 25482.000,
#                29164.333, 32683.333, 36010.000, 39040.000, 41989.000,
#                42071.000), a = 42000, b = 42000, c=-10, d=0.9,Print.curve = T)











####################################################################
# Sample size in metatranscriptomics
####################################################################
#' Sample size in metatranscriptomics
#'
#' Function to caculate Rarefaction, Bayesian Richness and Sampling Effort index.
#' @param data.frame.1M data-set matrix with data containing the metagenomic frequencies (rows: OTUs, columns: samples)
#' @param saturation if TRUE the matrix is ordered
#' @param method additive regression or xgboost
#' @export

########################################################
# function Predict.number.genes.effort.trasncriptomics(data.frame.1M, saturation=T)
########################################################
Predict.number.genes.effort.trasncriptomics <- function(data.frame.1M, saturation=T, method="addregrs"){

  #method="addregrs"
  #method="xgboost"
  #example of prediction
  #data.frame.1M <- data.frame(X.1=6953.333, X.2=12418.33, X.3=17158, X.4=21572.67,
  #                    X.5=25482, X.6=29164.33, X.7=32683.33, X.8=36010, X.9=39040,
  #                    X.10=41989)

  #this function predicts the number of genes (in millions and the effort sampling)
  #funcion para el articulo con Jordi Frias 2015-2018

  #number of genes depending of the sampling depth
  X.1=data.frame.1M$X.1[1] #one million
  X.2=data.frame.1M$X.2[1] #two millions
  X.3=data.frame.1M$X.3[1]
  X.4=data.frame.1M$X.4[1]
  X.5=data.frame.1M$X.5[1]
  X.6=data.frame.1M$X.6[1]
  X.7=data.frame.1M$X.7[1]
  X.8=data.frame.1M$X.8[1]
  X.9=data.frame.1M$X.9[1]
  X.10=data.frame.1M$X.10[1]


  newdf <- data.frame(log_X.1=log(X.1[1]),
                      log_X.2=log(X.2[1]),
                      log_X.3=log(X.3[1]),
                      log_X.4=log(X.4[1]),
                      log_X.5=log(X.5[1]),
                      log_X.6=log(X.6[1]),
                      log_X.7=log(X.7[1]),
                      log_X.8=log(X.8[1]),
                      log_X.9=log(X.9[1]),
                      log_X.10=log(X.10[1]))

  #1.Estimate Asimptote (based on paper jordi frias 2016-18)

  #DEFINO UN DATA FRAME CON LOS DATOS PARA LOS lm

  #modelo  aaaa<-lm( log_Asym1 ~    log_X.1 + log_X.2 + log_X.3 + log_X.4 *
  #            log_X.5 + log_X.6 + log_X.7 * log_X.8 * log_X.9 + log_X.10 , data=datos.log)

  ## load the model by regression aditive (see Jordi Frias paper)
  #method<-"addregrs"
  if(method=="addregrs"){
    load("MODEL1_predict_Asym.rda")
    ## predict for the new `x`s in `newdf`
    exp(predict(aaaa, newdata = newdf, interval="confidence"))
    Asym<-exp(predict(aaaa, newdata = newdf, interval="confidence"))
    print("Asymptote is (maximum number of genes predicted and CI 95%): ")
    print(Asym)
  }
  #using the xgboost
  if(method=="xgboost"){
    load("MODEL_predict_xgboost.rda")
    ## predict for the new `x`s in `newdf`
    exp(predict(bst, newdata = as.matrix(newdf), interval="confidence"))
    Asym<-exp(predict(bst, newdata = as.matrix(newdf), interval="confidence"))
    print("Asymptote is (maximum number of genes predicted and CI 95%): ")
    print(Asym)

    #Prediction   intervals   for   individual   observations
    #“Where do I think a single new observation will fall?”
    #– Interval captures
    #single
    #new random observation rather than
    #average
    #.
    #– Must accommodate random variation about the fitted model.
    #– Holds about 95% of data surrounding the fitted regression line.
    #– Approximate
    #in sample
    #form:
    #  Fitted line ± 2 RMSE
    #see at: https://rpubs.com/aaronsc32/regression-confidence-prediction-intervals
    Asym1<-Asym
    sd.pred<-38604.78 #sd estimated during cross validations using XGBOOST
    Asym2<-Asym-(qt(0.975, 99)*sd.pred) #lwr
    Asym3<-Asym+(qt(0.975, 99)*sd.pred) #uwr
    Asym<- c(Asym1, Asym2, Asym3)
    print(Asym)
    #cambiar a este ci ###########################
    #if(Asym[2] <0){
    Asym.old <- Asym[1]
    load("MODEL1_predict_Asym.rda")
    ## predict for the new `x`s in `newdf`
    exp(predict(aaaa, newdata = newdf, interval="confidence"))
    Asym<-exp(predict(aaaa, newdata = newdf, interval="confidence"))
    margen<- abs(Asym[2]-Asym[1])
    Asym2<-Asym.old-margen #lwr
    Asym3<-Asym.old+margen #uwr
    Asym<- c(Asym.old, Asym2, Asym3)
    #}
    print(Asym)
    class(Asym)
  }


  ## load the model SVM
  #load("MODEL2_predict_Asym.rda")
  ## predict for the new `x`s in `newdf`
  #Asym.svm<-exp(predict(svm_model, newdf))
  #print("Asymptote is (maximum number of genes predicted SVM): ")
  #print(Asym.svm)

  #2.Estimation of curve (1M vs num genes)  and effort to reach maximum
  ##############FIT DE LA CURVA E INTERVALOS DE CONFIANZA SIMPLES SOLO CON EL IC95% ASINDOTA ###########################################

  ################## uso de otro intervalo de confianza con las estimaciones de los modelos con los IC95% del parametro asindota del 1M
  #parametros asindota que se estiman de la weibull para cada muestra:
  ########(fit/mean)#########################################
  #values of prediction
  Asym1.es1<-Asym[1] #fit 1a muestra
  Asym1.es.lwr<-Asym[2]#Asym1.predicted.ci95[orden.muestra,2] #lwr95% 1a muestra
  Asym1.es.upr<- Asym[3] #Asym1.predicted.ci95[orden.muestra,3] #upr95% 1a muestra
  Asym1.es1; Asym1.es.lwr; Asym1.es.upr

  #saturation<-T
  if (saturation==T) {  #estimar parametros con modelo Weibull de saturaci?n
    options(show.error.messages=F) # turn off
    #Ahora se pueden utilizar los dos algoritmos para hacer los calculos de las estimaciones del modelo Weibull
    #model.weibull.bayesian.fit <-nls(number.genes ~ Asym1.es1-Drop*exp(-exp(lrc)*samples.1^pwr) ,
    #                                 data = todas[1:30,], start = list(Drop=3000, lrc=2, pwr=.1 ) , algorithm = "port")
    number.genes<- c(X.1,X.2, X.3, X.4, X.5, X.6, X.7, X.8, X.9, X.10)
    samples.1 <- c(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1)
    #class(samples.1)
    library(minpack.lm)
    out2 <- try(model.weibull.bayesian.fit <-nlsLM(number.genes ~ Asym1.es1-Drop*exp(-exp(lrc)*samples.1^pwr),
                                                   start = list(Drop=Asym1.es1, lrc=2, pwr=2 )))
    #no error correct the weibull
    if (substr(out2[1],1,5)!="Error"){
      #out2 <- try(model.SSlogis <- nls(number.genes ~ SSlogis(samples.1, Asym1.es1, b, c)))

      Drop<-summary(model.weibull.bayesian.fit )$parameters[1]
      lrc<-summary(model.weibull.bayesian.fit )$parameters[2]
      pwr<-summary(model.weibull.bayesian.fit )$parameters[3]

      Drop; lrc; pwr
      #averiguar cual es el error estandart del parametro asindota
      #EE.Asym1.weibull  <- nls(number.genes ~ SSweibull(samples.1, Asym, Drop, lrc, pwr), data = todas[1:30,])
      #summary(EE.Asym1.weibull)
      #summary(EE.Asym1.weibull)$parameters[1,2] #error estandart de la estimaci?n
      #EE.A.1 <- summary(EE.Asym1.weibull)$parameters[1,2] #error estandart de la estimaci?n
      #plot

      plot(c(0,0),c(0,0),xlim=c(0,30), ylim=c(0,1.1*Asym1.es.upr), main = paste("Prediction function (genes, effort): ", method,sep=""),
           xlab="number of samples (millions)", ylab=paste("genes (Maximum=",round(Asym1.es1,0), ")", sep=""))
      #grafica en pantalla estimada a partir del primer millon 1M
      #x<-c(0, 0.3, 100, 1000)
      curve(Asym1.es1-Drop*exp(-exp(lrc)*x^pwr), col = "red", lty=1, lwd=2, add = TRUE)
    }
    #error not correct the weibull try weibull 2p
    if (substr(out2[1],1,5)=="Error"){
      out22 <- try(model.logis.fit <-nlsLM(number.genes ~ Asym1.es1*(1-exp(-exp(b)*samples.1)),
                                           start = list(b=2)))
      #parameters
      b<-summary(model.logis.fit )$parameters[1]
      #c<-summary(model.logis.fit )$parameters[2]
      b; #c
      #plot
      plot(c(0,0),c(0,0),xlim=c(0,30), ylim=c(0,1.1*Asym1.es.upr), main = paste("Prediction function (genes, effort): ", method,sep=""),
           xlab="number of samples (millions)", ylab=paste("genes (Maximum=",round(Asym1.es1,0), ")", sep="") )
      #grafica en pantalla estimada a partir del primer millon 1M
      #x<-c(0, 0.3, 100, 1000)
      curve(Asym1.es1*(1-exp(-exp(b)*x)), col = "red", lty=1, lwd=2, add = TRUE)

    }

    ########(lwr)#########################################

    out3 <- try(model.weibull.bayesian.lwr <-nlsLM(number.genes ~ Asym1.es.lwr-Drop*exp(-exp(lrc)*samples.1^pwr) ,
                                                   start = list(Drop=Asym1.es.lwr, lrc=2, pwr= 2)))
    if(substr(out3[1],1,5) != "Error") {
      #model.weibull.bayesian.lwr <-nlsLM(number.genes ~ (Asym1.es1-1.96*EE.A.1)-Drop*exp(-exp(lrc)*samples.1^pwr) ,
      #                                   data = todas[1:30,], start = list(Drop=4000, lrc=2, pwr= 1))

      Drop.lwr<-summary(model.weibull.bayesian.lwr)$parameters[1]
      lrc.lwr<-summary(model.weibull.bayesian.lwr)$parameters[2]
      pwr.lwr<-summary(model.weibull.bayesian.lwr)$parameters[3]
      #grafica en pantalla estimada a partir del primer millon 1M
      curve(Asym1.es.lwr-Drop.lwr*exp(-exp(lrc.lwr)*x^pwr.lwr), col = "red", lty=2, add = TRUE)
    }
    #error not correct the weibull try weibull 2p
    if(substr(out3[1],1,5) == "Error") {

      out4 <- try(model.logis.fit <-nlsLM(number.genes ~ Asym1.es.lwr*(1-exp(-exp(b1)*samples.1)),
                                          start = list(b1=2)))
      #parameters
      b1<-summary(model.logis.fit )$parameters[1]
      #c1<-summary(model.logis.fit )$parameters[2]
      b1; #c1
      #grafica en pantalla estimada a partir del primer millon 1M
      #x<-c(0, 0.3, 100, 1000)
      curve(Asym1.es.lwr*(1-exp(-exp(b1)*x)), col = "red", lty=2, add = TRUE)

    }

    ########(upr)#########################################

    out5 <- try(model.weibull.bayesian.uwr <-nlsLM(number.genes ~ (Asym1.es.upr)-Drop*exp(-exp(lrc)*samples.1^pwr)
                                                   , start = list(Drop=Asym1.es.upr, lrc=2, pwr=2)))
    if(substr(out5[1],1,5) != "Error") {
      Drop.upr<-summary(model.weibull.bayesian.uwr)$parameters[1]
      lrc.upr<-summary(model.weibull.bayesian.uwr)$parameters[2]
      pwr.upr<-summary(model.weibull.bayesian.uwr)$parameters[3]
      #grafica en pantalla estimada a partir del primer millon 1M
      curve( (Asym1.es.upr)-Drop.upr*exp(-exp(lrc.upr)*x^pwr.upr), col = "red", lty=2, add = TRUE)
    }
    #error not correct the weibull try weibull 2p
    if(substr(out5[1],1,5) == "Error") {

      out6 <- try(model.logis.fit <-nlsLM(number.genes ~ Asym1.es.upr*(1-exp(-exp(b2)*samples.1)),
                                          start = list(b2=2)))

      #parameters
      b2<-summary(model.logis.fit )$parameters[1]
      #c2<-summary(model.logis.fit )$parameters[2]
      b2; #c2
      #grafica en pantalla estimada a partir del primer millon 1M
      #x<-c(0, 0.3, 100, 1000)
      curve(Asym1.es.upr*(1-exp(-exp(b2)*x)), col = "red", lty=2, add = TRUE)

    }
    ################ CALCULO DEL ESFUERZO 90 Y 95% DEL MAXIMO DE LOS GENES ##########################
    #esfuerzo para el 90% del maximo de genes
    #La funcion inversa es: x <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)

    if (substr(out2[1],1,5)!="Error"){
      #Weibull 4p
      type1 <- "Weibull4p"
      #90% del esfuerzo maximo
      y <- 0.90*Asym1.es1
      x.para.maximo.90<- as.numeric((log((Asym1.es1-y)/Drop)/-exp(lrc))^(1/pwr) )

      #95% esfuerzo maximo
      y <- 0.95*Asym1.es1
      x.para.maximo.95<- (log((Asym1.es1-y)/Drop)/-exp(lrc))^(1/pwr)

      #99% esfuerzo maximo
      y <- 0.99*Asym1.es1
      x.para.maximo.99<- (log((Asym1.es1-y)/Drop)/-exp(lrc))^(1/pwr)
    }
    if (substr(out2[1],1,5)=="Error"){
      type1 <- "Weibull2p"
      #Weibull 2p
      #90% del esfuerzo maximo
      y <- 0.90*Asym1.es1
      x.para.maximo.90<- as.numeric(log(1-(y/Asym1.es1))/(-exp(b)) )
      #95% esfuerzo maximo
      y <- 0.95*Asym1.es1
      x.para.maximo.95<- as.numeric(log(1-(y/Asym1.es1))/(-exp(b)) )
      #99% esfuerzo maximo
      y <- 0.99*Asym1.es1
      x.para.maximo.99<- as.numeric(log(1-(y/Asym1.es1))/(-exp(b)) )
    }

    ################ CALCULO DEL INTERVALO DE CONFIANZA PARA EL ESFUERZO 90 Y 95% DEL MAXIMO DE LOS GENES ##########################
    #esfuerzo para el 90% del maximo de genes
    #La funcion inversa es: x <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
    if (substr(out3[1],1,5)!="Error"){
      type2 <- "Weibull4p"
      #Weibull 4p
      #90% del esfuerzo maximo - lower limit
      y <- 0.90*Asym1.es.lwr
      x.para.maximo.90.lwr<- as.numeric((log((Asym1.es.lwr-y)/Drop.lwr)/-exp(lrc.lwr))^(1/pwr.lwr) )
      #95% del esfuerzo maximo - lower limit
      y <- 0.95*Asym1.es.lwr
      x.para.maximo.95.lwr<- as.numeric((log((Asym1.es.lwr-y)/Drop.lwr)/-exp(lrc.lwr))^(1/pwr.lwr) )
      #99% del esfuerzo maximo - lower limit
      y <- 0.99*Asym1.es.lwr
      x.para.maximo.99.lwr<- as.numeric((log((Asym1.es.lwr-y)/Drop.lwr)/-exp(lrc.lwr))^(1/pwr.lwr) )
    }
    if (substr(out3[1],1,5)=="Error"){
      #Weibull 2p
      type2 <- "Weibull2p"
      #90% del esfuerzo maximo
      y <- 0.90*Asym1.es.lwr
      x.para.maximo.90.lwr<- as.numeric(log(1-(y/Asym1.es.lwr))/(-exp(b1)) )
      #95% esfuerzo maximo
      y <- 0.95*Asym1.es.lwr
      x.para.maximo.95.lwr<- as.numeric(log(1-(y/Asym1.es.lwr))/(-exp(b1)) )
      #99% esfuerzo maximo
      y <- 0.99*Asym1.es.lwr
      x.para.maximo.99.lwr<- as.numeric(log(1-(y/Asym1.es.lwr))/(-exp(b1)) )
    }

    #lower limit
    if (substr(out5[1],1,5)!="Error"){
      type3 <- "Weibull4p"
      #90% del esfuerzo maximo - upper limit
      y <- 0.90*Asym1.es.upr
      x.para.maximo.90.upr<- as.numeric((log((Asym1.es.upr-y)/Drop.upr)/-exp(lrc.upr))^(1/pwr.upr) )
      #95% del esfuerzo maximo - upper limit
      y <- 0.95*Asym1.es.upr
      x.para.maximo.95.upr<- as.numeric((log((Asym1.es.upr-y)/Drop.upr)/-exp(lrc.upr))^(1/pwr.upr) )
      #99% del esfuerzo maximo - upper limit
      y <- 0.99*Asym1.es.upr
      x.para.maximo.99.upr<- as.numeric((log((Asym1.es.upr-y)/Drop.upr)/-exp(lrc.upr))^(1/pwr.upr) )
    }
    if (substr(out5[1],1,5)=="Error"){
      type3 <- "Weibull2p"
      #Weibull 2p
      #90% del esfuerzo maximo
      y <- 0.90*Asym1.es.upr
      x.para.maximo.90.upr<- as.numeric(log(1-(y/Asym1.es.upr))/(-exp(b2)) )
      #95% esfuerzo maximo
      y <- 0.95*Asym1.es.upr
      x.para.maximo.95.upr<- as.numeric(log(1-(y/Asym1.es.upr))/(-exp(b2)) )
      #99% esfuerzo maximo
      y <- 0.99*Asym1.es.upr
      x.para.maximo.99.upr<- as.numeric(log(1-(y/Asym1.es.upr))/(-exp(b2)) )
    }


    ######## results ###########
    print("Effort to obtain maximum number of genes")
    print("Number of sequences to 90% to maximum number of genes")
    print(cat("Using a model (mean, CLI, CUI) :", type1, " ", type2, " ",  type3,sep = ""))
    print(  cat(x.para.maximo.90, " (", x.para.maximo.90.lwr, ", ", x.para.maximo.90.upr, ") " ) )

    print("number of sequences to 95% to maximum number of genes")
    print(  cat(x.para.maximo.95, " (", x.para.maximo.95.lwr, ", ", x.para.maximo.95.upr, ") ",sep = "",fill = F ) )

    print("number of sequences to 99% to maximum number of genes")
    print(  cat(x.para.maximo.99, " (", x.para.maximo.99.lwr, ", ", x.para.maximo.99.upr, ") " ) )

    #plot lines
    abline(v=x.para.maximo.90,lt=5,col="yellow",lwd=.25)
    abline(v=x.para.maximo.95,lt=5,col="green",lwd=0.25)
    abline(v=x.para.maximo.99,lt=5,col="orange",lwd=0.25)
    #legend
    text(20,5000, "95% effort:",col="black")
    text(23,5000, paste(round(x.para.maximo.95,1),"-", "M",sep = ""))

  }

  options(show.error.messages=T) # turn off
}



#falta el intervalo de confianza de prediccion para xgboost
#ver en: https://www.bigdatarepublic.nl/regression-prediction-intervals-with-xgboost/
#https://stackoverflow.com/questions/44416210/confidence-interval-for-xgboost-regression-in-r


##make an empty data frame with a column per bagging run
#predictions <- data.frame(matrix(0,500,100))

#4 categorical input variables and one numeric output

#y<-rnorm(100, 100, 5)
#x1<-rnorm(100,124,5)
#x2<-rnorm(100,18,5)
#x3<-rnorm(100,12,5)
#x4<-rnorm(100,222,5)
#train<- data.frame(y=y, x1=x1, x2=x2, x3=x3, x4=x4)

#train<-as.matrix(train)
#test=train[1:20,]

#library(xgboost)

##come up with 100 unique seed values that you can reproduce
#set.seed(123)
#seeds <- runif(100,1,100000)

#for (i in 1:ncol(predictions)){
#i<-1
#  set.seed(seeds[i])
#  xgb_model <- xgboost(data = train[,2:4],
#                       label = train[,1],
#                       objective = "reg:linear",
#                       eval_metric = "rmse",
#                       subsample = .8,
#                       colsample_bytree = .8,nrounds = 200)
#
#  predictions[,i] <- predict(xgb_model,newdata = test)

#}

