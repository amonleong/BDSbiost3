
#####################################################################
#ESPECTRAL CLUSTERING NETWORKS (using sparse correlations or Cosine similarity between columns (sparse matrices))
#################################################################################################
#' Spectral clustering Network analysis for frequencies (taxon, omic data, counts) - (using sparse correlations or Cosine similarity between columns (sparse matrices)): with geometrical analysis and identification of communities (consortiums)
#'
#' Function to create networkss and Gaussian Graphs
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param Sparse.correlation use a sparse.correlation with cosinus similarity (Yes/Not)
#' @param cutoff minimum correlation to stablish edge (0.9)
#' @param dimensions number of dimentions to multivariate analysis
#' @param ncluster minimum number of clusters (3)
#' @param ncluster1 maximum number of clusters (3)
#' @param geometric.analysis Geometrical analysis and and identification of communities (consortiums)
#' @return Network plots, geometrical analysis plots and identification of communities (consortiums) using Girvan-Newman method and Walk-trap algorithm
#' @export
#' #'
#' @examples
#' library(HMP) #16S rRNA Sequencing Data from the Human Microbiome Proje
#' data(saliva) #saliva metagenomic test (sample vs taxa)
#' saliva1<- data.frame(t(saliva))
#' #define the experimental groups
#' labels1<- c(rep("G1", 8),rep("G2", 8),rep("G3", 8))
#' colnames(saliva1)<-labels1
#'
#' #Network based on spectral analysis with geometrical analysis and and identification of communities (consortiums)
#' Espectral.CN(matriu=saliva1,nrows =dim(saliva1)[1],  Sparse.correlation = T,ncluster = 2,cutoff = 0.91,geometric.analysis = T)


#' @references
#' CI Rodríguez-Casado, A Monleon-Getino, M Cubedo, M Ríos- Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32


#matriu matriz de frecuencias (OTUxsamples)
Espectral.CN <- function(matriu, nrows=20, Sparse.correlation = T, cutoff = 0.9, ncluster = 3, dimensions=3, ncluster1=3, geometric.analysis=T)
{
  #convertirla en un data.frame
  matriu<- data.frame(matriu)
  ######### (paso 1 ##################################
  #vector.labels <- vector.labels2
  #Selecciono las nrows más abundantes por suma de las filas y
  #selecciono nrows
  Rsum <- rowSums(matriu,na.rm=TRUE)
  matriu.ordered<-matriu[order(-Rsum),]
  matriu.ordered.selected <- matriu.ordered[1:nrows, ]

  #row.names(matriu)
  #traspose the matrix to know the network between otu
  matriu<- t(matriu.ordered.selected)
  #matriu<- t(matriu)
  #cutoff = 0.5
  #Espectral analysis between columns using networks and Laplacians (Multivariant exploratory of the metagenomic matrix)


  #SEE AT <https://web.stanford.edu/class/bios221/labs/networks/lab_7_networks.html>
  #  There are may different network analytics that people are interested in. We will focus on clustering.#
  #We will do "spectral clustering" by doing k-means clustering on the first several eigenvectors of the symmetric normalized graph Laplacian. We'll do this on the correlation matrix of the E. Coli gene expression data from above. This tends to do well for associative clustering (since we're looking at eigenvectors).
  #First, we construct a graph adjacency matrix from the correlation matrix by thresholding the values: everything about 0.85 is counted as an edge, and everything below that is counted as a non-edge. This value of 0.85 was chosen so that there would be a about 200 vertices in the plot and does not have any specific biological significance. If you do this on your own data, you should probably have a better reason for picking a cutoff value. We treat the thresholded data as an adjacency matrix and look at the connected components of the corresponding graph.
  #Example using a simulated correlation without copulas, see at:
  #  <https://www.r-bloggers.com/easily-generate-correlated-variables-from-any-distribution-without-copulas/>


  #calcular las correlaciones ################################################################################
  #see library for sparsity matrix: https://cran.r-project.org/web/packages/qlcMatrix/qlcMatrix.pdf
  library(qlcMatrix)
  if (Sparse.correlation == T){
    #correlacion de Pearson (producto momento) con funcion corSparse
    M <- corSparse(matriu) # might take half a minute, depending on hardware
    #un breve resumen de la matriz de correlaciones de Pearson
    #M[1:10,1:10]

    #coeficiente de asociacion metodo de poison
    #system.time(M <- assocSparse(matriu2013, method = poi))

    #coeficiente de asociacion metodo de poison
    #system.time(M <- assocSparse(matriu2013,method = pmi))
  }
  if (Sparse.correlation == F){
    #Cosine similarity between columns (sparse matrices)
    system.time(M <- cosSparse(matriu)) # might take half a minute, depending on hardware
    #M1[1:10,1:10]
    #dim(M1)
    #print(M)

    #rpresent the network
    #https://rdrr.io/bioc/netbiov/man/mst.plot.mod.html
    ## try http:// if https:// URLs are not supported
    #source("https://bioconductor.org/biocLite.R")
    #biocLite("netbiov")
    #library(netbiov)
    library(igraph)
    g  <- graph.adjacency(as.matrix(M), weighted=TRUE)
    g_mst <- mst(g)
    #(plot(g_mst, vertex.color="green", vertex.size=3, edge.arrow.size=0.5))

  }

  #etiquetas de los otus
  colnames(M)<-colnames(matriu)

  #punto de corte es 0.9 ######################################################################
  # Make a similarity matrix by thresholding the correlation matrix
  library(Matrix)
  Sfull <- Matrix(1*(M > cutoff)) #matriz de 1 y 0

  #colnames(Sfull) #aqui tiene las etiquetas de las otus

  # connected component distribution (have to use matrix instead
  #of Matrix here)
  library(sna)
  Scd <- component.dist(as.matrix(Sfull))
  #table(Scd$csize) # numero de vertices de cada nodo
  #represent the network
  #https://rdrr.io/bioc/netbiov/man/mst.plot.mod.html
  ## try http:// if https:// URLs are not supported
  #source("https://bioconductor.org/biocLite.R")
  #biocLite("netbiov")
  #library(netbiov)
  #library(igraph)
  #g  <- graph.adjacency(as.matrix(S), weighted=TRUE)
  #g_mst <- mst(g)
  #(plot(g_mst, vertex.color=NA, vertex.size=3, edge.arrow.size=0.5))


  #The function component.dist will give us information on the connected components in the graph of this full adjacency matrix. We're only going to be concerned with the largest connected component in this lab (although in practice, you should look at all the connected components which seem larger than you might expect from a Poisson distribution - in this case, the components of size 29, 57, 84, and 219). We'll select all of the vertices in the largest connected component (LCC).

  # which vertices are in the largest connected component
  lcc.ind <- which(Scd$membership == which.max(Scd$csize))
  print("--------------------------")
  print("--------------------------")
  print("Code of taxon used for the network which vertices are in the largest connected component (cut-off)")
  print(lcc.ind)
  print("Number of connections:")
  print(length(lcc.ind))
  print("--------------------------")
  print("--------------------------")

  # We'll call the LCC "S" and just work with this component
  S <- Sfull[lcc.ind,lcc.ind] #creo que es la matriz de adyacencia (1=conectado, . =no conectado)
  n <- dim(S)[1]
  n

  #Now we'll look at the eigendecomposition of the symmetric normalized graph Laplacian. For those of you familiar with topology, this is the discrete equivalent of a Laplacian. When we construct this, we make an identity matrix minus a scaled adjacency matrix - since we're subtracting the interesting part of the matrix, we're concerned with the smallest eigenvectors (except the very smallest which will has eigenvalue 0).

  # degree distribution
  d <- as.vector(S %*% rep(1,n)) #symmetric, so we can pre or post multiply

  # Laplacians (symmetric normalized)
  Lsym <- Diagonal(n) - (Diagonal(x=d^(-1/2)) %*% S %*% Diagonal(x=d^(-1/2)))

  # eigen decomposition (takes a few seconds -- R doesn't have a sparse eigen)
  eLsym <- eigen(Lsym)

  # decide how many eigenvectors to use: look at the smallest ones (except the last)
  plot(eLsym$values, xlab="i", ylab="(n-i)th eigenvalue",
     main="smallest eigenvalues")
  #abline(v=seq(0,25,by=5),col=rgb(0,0,0,0.2))



  #want to find the jump in the eigenvalues. To me, it looks like there are jumps between the (n-1) and (n-2) eigenvalues, (n-3) and (n-4) eigenvalues, (n-8) and (n-9) eigenvalues. This means we want to consider either 1, 3, or 8 eigenvectors. Remember that we do not include the very smallest since it will have eigenvalue 0 by construction and the eigenvector will just be noise from floating point accuracy.

  # Use x dimensions for the eigenvectors of the symmetric normalized Laplacian.
  eLV <- eLsym$vectors[,n-1:dimensions]


  #We want to do some sort of clustering so vertices that are similar to each other get clustered together. For this lab, we'll use k-means clustering. We'll keep track of the total within sum of squares (TWSS) for each number of clusters. We want this to be very small without including lots of clusters. The heuristic that we'll use is to look for the elbow in the TWSS plotted versus total number of clusters.
  #Note that k-means is a randomized algorithm, and for any fixed k, we're only interested in the result which has the smallest TWSS. Here, we'll start with 100 randomized starts for each number of clusters. We'll look at anywhere from 1 to 10 clusters.


 # kmeans uses random numbers, so let's make this repeatable
 #set.seed(2)

 # calculate total within sums of squares for k means clustering
 kmWCSS <- sum(sweep(eLV,2,apply(eLV,2,mean))^2) # total within sum of squares
 nclusts <- ncluster # largest number of clusters we'll consider
 nstart <- 3 # how many random starts we use
 kmWCSS[2:ncluster] <- unlist(lapply(2:ncluster, function(i){
 sum(kmeans(eLV, i, nstart=nstart)$withinss)}))

  # plot these TWSS versus number of clusters
  #plot(1:nclusts,kmWCSS)
  #abline(v=seq(0,nclusts,by=5),col=rgb(0,0,0,0.2))


  # There's an "elbow" at 4 clusters, so let's use 4 clusters.
  my.nclusts <- ncluster
  my.km <- kmeans(eLV, my.nclusts, nstart=nstart)

  # draw this graph
  Snet <- network(as.matrix(S), dir=F)
  set.seed(1)
  par(mar=rep(0,4)+0.1) # makes the margins smaller

  # Save the coordinates, and for now just plot the edges.
  coords <- plot(Snet, vertex.col=0, vertex.border=0, edge.col=rgb(0,0,0,0.7))

  # to plot this quickly again, you can put in the coords from before
  #plot(Snet, coord=coords, vertex.col=0, vertex.border=0, edge.col=rgb(0,0,0,0.7))

  # add vertices with cluster colors and different shapes
  my.cols <- rainbow(my.nclusts, alpha=0.8)
  points(coords, col=my.cols[my.km$cluster], pch=my.km$cluster, lwd=2)
  #aqui poner los lcc.ind
  #text(coords,lcc.ind)
  text(coords[,1], coords[,2], labels=lcc.ind, cex= 0.6,
     pos=4, col= my.cols[my.km$cluster]) #samples



  #What happens when we want to do hierarchical clustering instead of k-means clustering?
  my.dend <- hclust(dist(eLV), method="ward.D")
  plot(my.dend,main ="ward.D",labels = lcc.ind )

  #an also try changing method="ward.D" to something else. Hierarchical clustering has the very nice property that it is agglomerative (unlike k-means), so it preserves some interpretability of subsets, whereas k-means has the nice property that it minimizes the TWSS.
  #A great feature of doing hierarchical clustering is that now we have a dendrogram so we can make a heatmap of the adjacency matrix to correspond to the plot of the graph.
  cut.height <- ncluster1 # try numbers from 4 to 7
  my.hclusts <- cutree(my.dend, cut.height)
  my.cols <- rainbow(cut.height, alpha=0.8)
  #
  vcols <- my.cols[my.hclusts]
  par(mar=rep(0,4)) # make plot margins 0
  # cols = 0:1 is white for 0 and black for 1
  heatmap(as.matrix(S), Rowv = as.dendrogram(my.dend), symm=TRUE,
        ColSideColors=vcols, RowSideColors=vcols,  col=0:1, frame=T,labCol = lcc.ind,labRow = lcc.ind)


  #grafo - network
  #want to include as many clusters as we feel are actually well separated.
  #This corresponds to drawing a horizontal line across here to cut the tree into clusters. It looks like we should not use more than 7 clusters and we should definitely use at least 4 clusters. Try changing the number of clusters from 4 to 7 to decide which number of clusters you like most.
  #ncluster1=ncluster

  plot(Snet, coord=coords, vertex.col=0, vertex.border=0, edge.col=rgb(0,0,0,0.7))
  points(coords, col=my.cols[my.hclusts], pch=my.hclusts, lwd=2)
  text(coords[,1], coords[,2], labels=lcc.ind, cex= 0.6,
     pos=4, col= "black") #samples
  title("Network")

  #is easier to see that there are some structures within the red cluster.

  #link at <https://web.stanford.edu/class/bios221/cgi-bin/index.cgi/>


  #  see more at <https://datascienceplus.com/network-analysis-of-game-of-thrones/>

  ## COMPLEX NETWORKS IN BIOLOGY
  #  SEE <https://bioconductor.org/help/publications/book-chapters/MiMB/>


 ############################
 #algoritmo de Girvan-Newman:   numero de subcomunidades y su analisis en el grafo
  if (geometric.analysis == T){
    #si se desea saber el numero de comunidades mediante Girvan-Newman y saber cuntos grupos se forman, etc
    #se parte de la matriz e adyacencia que creo que es S
    #S
    adj3<-S
    #complexity index monleon 2018-julio
    #print("Matriz de adya") adj3 es la matriz de adyacencia 1 y 0
    #pero en este caso es de dependencia la red o grafo
    #save(adj3,file = "adj3.txt")
    print("dimension matriz de adyacencia")
    print(dim(adj3))
    #calculo complejidad, indice de Monleon (no se puede calcular aqui, odo juntos)
    #res.monle<-monle.complexity.adjacency1(mm = as.matrix(adj3))
    #print("calculo complejidad, indice de Monleon")
    #print(res.monle)

    #barplot(table(res.monle[1]),
    #        main = "MONLE-COMPLEXITY GG N CONECTIONS", col ="red",
    #        xlab = "connexion nodes by OTU", ylab = "frequency")
    #print("Complejidad Monle (edges-groups)")
    #print(res.monle[1]) #los grupos que se han formado
    #print("Indice de complejidad Monle (Mean edges)")
    #print(res.monle[2]) #los grupos que se han formado
    #print("Indice de complejidad Monle (Mean edges>1)")
    #print(res.monle[3])#los grupos que se han formado


    #complexity index?
    #print("Complexity index-----------")
    #print("Mean nodes connexion by OTU: ")
    #rowSums.adj3 <- colSums(adj3,na.rm = T) #COMPUTE THE SUM OF THE ROWS OF THE TRANSFORMED ADJACENCY MATRIX
    #rowSums.adj4<-rowSums.adj3 #se anade 1 para formar los grupos (1 conexion, 2 conexiones, ...)

    #colSums(adj3)
    #print(mean(rowSums.adj3))
    #print("Table with nodes by row: ")
    #print(table(rowSums.adj4))

    #barplot for complexity
    #barplot(table(res.monle[1]),
    #        main = "SAMPLE COMPLEXITY GG-MONLE-INDEX", col =blues9,
    #        xlab = "connexion nodes by OTU", ylab = "frequency")
    #text("HOLA")

    #trasnformar matriz para su analisis de grafos
    #ver centralidad, comunidades, etc (Python)
    adj4<-adj3
    rownames(adj4)<-lcc.ind #rep(1:nrow(adj4)) #labels
    #View(adj4)
    #write.table(adj4, file = "networkmatrix.csv",
    #            sep = ",", col.names = NA,
    #            qmethod = "double")

    ##################################################
    #analisis geometrico de la matriz de adyacencia
    ##################################################
    library(igraph)
    g <-  graph_from_adjacency_matrix(adj4)
    g<-simplify(g, remove.multiple = TRUE, remove.loops = TRUE,
             edge.attr.comb = igraph_opt("edge.attr.comb"))

    is_simple(g)

    #plot(g)
    #hist(degree(g))
    #The diameter of the network is the
    #largest geodesic. This gives a good idea of the effective size of the network
    print("network diameter: effective size of the network")
    print(diameter(g))

    #cluster_walktrap
    print("community detection using cluster walktrap")
    mswt<-membership(cluster_walktrap(g))
    #print(cluster_walktrap(g))
    #str(cluster_walktrap(g))
    print("Membership groups detected by walktrap algorithm")
    mat.member.wt<-as.matrix(sort(mswt))
    colnames(mat.member.wt)<-"Group"
    print(mat.member.wt)
    #grafo segun algoritmo walktrap:
    #GNC <- cluster_edge_betweenness(g, weights = NULL)
    V(g)$color <-mswt              #Plot setting specifying the coloring of vertices by community
    g$palette <- diverging_pal(length(mswt))   #Plot setting specifying the color pallette I am using (iGraph supports 3)
    V(g)$label.cex <- seq(0.5,5,length.out=0.5)         ## text size
    V(g)$size      <- seq(10,60,length.out=0.5)         ## circle size proportional to text size
    layout1 <- layout.kamada.kawai(g)
    windows(25,25)
    plot(g, edge.arrow.size=.5, edge.arrow.width=.5)
    title(main="communities by WALK-TRAP ALGORITHM ")



    #print("Finding communities in graphs based on statistical meachanics")
    #g1 <- induced_subgraph(g, subcomponent(g, 1))
    #cluster_spinglass(g1, spins=2)
    #cluster_spinglass(g1, vertex=1)

    #print("Normalized Shannon Entropy Score")
    #graph.diversity(g, weights = rep(3,gsize(g)), vids = V(g))

    #Jaccard Similarity
    similarity(g, method = "jaccard")
    # set seed to make the layout reproducible
    #set.seed(3952)
    E(g)$color <- "grey"
    V(g)$color <- "grey"
    #V(g)[degree(g, mode="in")>10]$color <- "yellow"  #Destinguishing High Degree Nodes as yellow
    V(g)$label.cex <- seq(0.5,5,length.out=0.5)         ## text size
    V(g)$size      <- seq(10,60,length.out=0.5)         ## circle size proportional to text size
    layout1 <- layout.kamada.kawai(g)
    tkplot(g, layout=layout1)   #tkplot allows us to manually manipulte the visualization if we want

    #Finding Strongly Connected Components
    scc <- clusters(g, "strong")     #Type scc in the console to have the strongly connected components reported
    #Membership: Top number indicates the node ID, the bottom the component to which it belongs (e.g., node 1 belongs to the 2 component)
    #csize: Component Size, the number of nodes in the component.
    #no: no indicates the number of components in the graph. We have 7 components, 1 central component and 6 nodes that recieve but do not send ties.

    v_idx=which (scc$csize>1) #Type v_idx in the console to get this report
    #In graphs with multiple components, it can be helpful to distinguish connected components from isolates.
    #Community Detection Algorithms in iGraph: Approaches Supported by iGraph
    #Detecting communitities by iteratively calculating edge betweeness (e.g., Girvan & Newman 2001)
    #Detecting communities by using eigenvector matrices (e.g., Newman 2006)
    #Detecting communities by iteratively optimizing for modularity (e.g., Blondel, Guillaume, Lambiotte, & Lefebvre 2008)
    #Detecting communities using random walk methods (e.g, Pons & Latapy 2005; Reichardt & Bornholdt 2006)
    #Detecting communities using label propogation techniques (e.g., Ragavan, Albert, & Kumara 2007)

    #Edge-Betweeness: Girvan-Newman (2001)
    #title(main="Girvan-Newman detection of communities")
    #Many networks consist of modules which are densely connected themselves but sparsely connected to other modules.
    #M Newman and M Girvan: Finding and evaluating community structure in networks, Physical Review E 69, 026113 (2004)
    GNC <- cluster_edge_betweenness(g, weights = NULL)
    V(g)$color <-membership(GNC)              #Plot setting specifying the coloring of vertices by community
    g$palette <- diverging_pal(length(GNC))   #Plot setting specifying the color pallette I am using (iGraph supports 3)
    V(g)$label.cex <- seq(0.5,5,length.out=0.5)         ## text size
    V(g)$size      <- seq(10,60,length.out=0.5)         ## circle size proportional to text size
    layout1 <- layout.kamada.kawai(g)
    windows(25,25)
    plot(g, edge.arrow.size=.5, edge.arrow.width=.5)
    title(main="communities by Girvan-Newman ")
    #si hay numero suficiente de grupos hacer un grafo con comunidades
    options(show.error.messages=T) # turn off
    msgerror <- try(msg.error <- plot_dendrogram(GNC))
    if (length(msgerror) == 0 ){ #sin error
      plot_dendrogram(GNC)
      title(main="cluster Girvan-Newman:communities")
    }

    #substr(msgerror,1,5) != "Error" |


    options(show.error.messages=T) # turn off


    #otro plot mas bonito
    coords = layout_with_fr(g)
    plot(GNC, g, layout=coords, main="cluster Girvan-Newman:communities")
    #print("modularidad")
    #print(modularity(GNC))
    print("Number of groups detected by Girvan-Newman algorithm:")
    max(membership(GNC))
    print("Membership groups detected by GN algorithm")
    mat.member.GN<-as.matrix(sort(membership(GNC)))
    colnames(mat.member.GN)<-"Group"
    print(mat.member.GN)
    GN.object<- print(mat.member.GN)
    #asignar si tiene las etiquetas de las variables
    row.names(mat.member.GN)
    #matriu colnames(matriu )


    #hist(as.vector(membership(GNC)),breaks = max(membership(GNC)),main="Size groups", xlab="Group (community) number",
    #     col="blue")
    #head(GNC, n=21)   #Looking at what nodes got assigned to the communities (23 communities in all)

    return(list(mat.member.wt, GN.object ))
     }






}


clique.community <- function(graph, k) {
  clq <- cliques(graph, min=k, max=k)
  edges <- c()
  for (i in seq_along(clq)) {
    for (j in seq_along(clq)) {
      if ( length(unique(c(clq[[i]], clq[[j]]))) == k+1 ) {
        edges <- c(edges, c(i,j)-1)
      }
    }
  }
  clq.graph <- simplify(graph(edges))
  V(clq.graph)$name <- seq_len(vcount(clq.graph))
  comps <- decompose.graph(clq.graph)

  lapply(comps, function(x) {
    unique(unlist(clq[ V(x)$name ]))
  })
}






#funcion que hace el calculo del intervalo de variacion del indice de complejidad
#utilizando remuestreo de filas y de columnas
Miriam.NetworkIC <- function(matriu, nrows=50, qgraph1=T, vector.labels, cor.type=2, gaussiangraphs=T, bayesian.graph=F, cut = 0.8, nsimul=100, print.graph=F){
  library(dplyr)
  my.array.validation.model <- array(NA, dim=c(nsimul,3))

  for (i in 1: nsimul){
    #i<-1
    #x1<-sample_n(matriu,replace = T,size = dim(matriu)[1]+2) #sample de filas
    x2<-sample(matriu, replace = T,size = dim(matriu)[2]) #sample de columnas
    #x2
    indice.complejidad<-Miriam.Network(matriu=x2, nrows=nrows, qgraph1=qgraph1, vector.labels=vector.labels, cor.type=2, gaussiangraphs=T, bayesian.graph=F, cut = 0.8, nsimul=nsimul,print.graph=print.graph)
    my.array.validation.model[i,1]<-as.numeric(indice.complejidad[1])
    my.array.validation.model[i,2]<-as.numeric(indice.complejidad[2])
    my.array.validation.model[i,3]<-as.numeric(indice.complejidad[3])
  }
    #resultados de todas las iteraciones del indice de compeljidad
    library(gplots)
    #par(mfrow=c(3,2))
    #complexity index1
    bandplot(x=rep(1:nsimul,1), my.array.validation.model[,1], xlab="Iterations", ylab="complexity index1 n=xxx sets")
    title(main = "COMPLEXITY INDEX 1")
    text1<-paste( "MEAN : [Mean=", round(mean(my.array.validation.model[,1],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,1],na.rm=TRUE),2), "]" ,sep = "")
    mtext(text1, side = 3)

    #complexity index2
    bandplot(x=rep(1:nsimul,1), my.array.validation.model[,2], xlab="Iterations", ylab="complexity index1 n=xxx sets")
    title(main = "COMPLEXITY INDEX 2")
    text2<-paste( "MEAN : [Mean=", round(mean(my.array.validation.model[,2],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,2],na.rm=TRUE),2), "]" ,sep = "")
    mtext(text2, side = 3)

    #NUMBER OF GROUPS
    bandplot(x=rep(1:nsimul,1), my.array.validation.model[,3], xlab="Iterations", ylab="GROUPS n=xxx sets")
    title(main = "NUMBER OF GROUPS 1")
    text3<-paste( "MEAN : [Mean=", round(mean(my.array.validation.model[,3],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,3],na.rm=TRUE),2), "]" ,sep = "")
    mtext(text3, side = 3)

  #print
    print("Results of complexity index (Monleon 2018")
    print("COMPLEXITY INDEX 1...................")
    print(text1)
    a<-quantile(my.array.validation.model[,1],na.rm=TRUE,probs = c(0.025,0.975))
    print(a) #intervalo de confianza quantil
    print("COMPLEXITY INDEX 2...................")
    print(text2)
    a1<-quantile(my.array.validation.model[,2],na.rm=TRUE,probs = c(0.025,0.975))
    print(a1) #intervalo de confianza quantil
    print("NUMBER OF GROUPS DETECTED............")
    print(text3)
    a2<-quantile(my.array.validation.model[,3],na.rm=TRUE,probs = c(0.025,0.975))
    print(a2) #intervalo de confianza quantil

}
