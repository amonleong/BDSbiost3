
#toni monleon (8-11-2017)

##################################################################################################
# Function to the differential analysis of proportions OTUs between groups samples
#################################################################################################
#' Metagenomic analysis of biodiversity
#'
#' Function to caculate differential poportions OTUs between samples groups
#' @param matriu data-set matrix with data containing abundances (ej: OTU frequencies)
#' @param vector.labels Levels or groups
#' @param alfa prob of error type I (alfa=0.05))
#' @param lim.padj parameter volcano plot, limit to filter padj= 0.001
#' @param lim.log2FoldChange parameter volcano plot, limit to filter log2FoldChange= 12
#' @export
#' @return List of differential proportions between groups
#' @examples
#' library(HMP) #16S rRNA Sequencing Data from the Human Microbiome Proje
#' data(saliva) #saliva metagenomic test (sample vs taxa)
#'
#' matriusaliva1<- t(data.frame(saliva))
#' #define the experimental groups
#' labels1<- c(rep("G1", 8),rep("G2", 8),rep("G3", 8))
#' colnames(matriusaliva1)<-labels1
#' dif.propOTU.between.groups(matriu = matriusaliva1, vector.labels=labels1, alfa=0.05, lim.padj = 0.001, lim.log2FoldChange = 12)

#' @references
#' Monleon-Getino T. et al. 2018. A new biodiversity index based on entropy. Pending of publication.


#####################################################################################
#####   dif.proportionsOTU.between.groups
#####################################################################################

#matriu matriz de frecuencias (OTUxsamples)
dif.propOTU.between.groups <- function(matriu, vector.labels, alfa=0.05, lim.padj = 0.001, lim.log2FoldChange = 12) {
#calculo de la proporcion diferencial de OTUs para diferentes grupos de muestras del vector vector.labels

  ###############################################################
  #
  #  GO basado en proporciones diferenciales entre grupos
  #
  ###############################################################

  #######################diferencias entre proporciones de grupos ########################################################
  #Definir array:
  comb<-choose(length(levels(factor(vector.labels))),2)
  dif.groups.proportion <- matrix(NA, nrow=nrow(matriu),ncol=comb)#MATRIZ DE CONTINE LOS VALORES DE DIVERSIDAD
  pval.groups.proportion <- matrix(NA, nrow=nrow(matriu),ncol=comb)#MATRIZ DE CONTINE LOS VALORES DE DIVERSIDAD

  #dif.groups.proportion<- as.matrix(dif.groups.proportion)
  vector.noms.grups<- array("", dim=c(comb) )

  #pairs of groups
  vector.groups <- c(levels(factor(vector.labels))) #grupos de analisis
  num.groups <- length(levels(factor(vector.labels))) #numero de grupos de analisis


  for (l in 1: nrow(matriu)){ #para cada OTU
    k<-1 #orden del grupo
    for (i in 1:(num.groups-1)) { #SELECCIONAR GRUPO1
      for (j in (i+1):num.groups) { #SELECCIONAR EL SEGUNDO GRUPO
        #k<-1
        #i<-2
        #j<-i+1
        #l<-1
        group.of.analysis.selected.1<-matriu[,grep(vector.groups[i], colnames(matriu))]
        n1<-ncol(group.of.analysis.selected.1)
        group.of.analysis.selected.2<-matriu[,grep(vector.groups[j], colnames(matriu))]
        n2<-ncol(group.of.analysis.selected.2)
        #View(group.of.analysis.selected.1)
        #View(group.of.analysis.selected.2)

        #l<-1 indicador de la OTU
        #CALCULO DEL TEST DE PROPORCIONES
        grup1<-sum(group.of.analysis.selected.1[l,1:n1], na.rm = FALSE)
        grup2<-sum(group.of.analysis.selected.2[l,1:n2], na.rm = FALSE)
        total1<-sum(group.of.analysis.selected.1[,1:n1], na.rm = FALSE)
        total2<-sum(group.of.analysis.selected.2[,1:n2], na.rm = FALSE)
        res.test.proport<- prop.test( c(grup1, grup2) , c(total1, total2))

        pair.group.name <- (paste("Gp-", vector.groups[i], "-", vector.groups[j],sep = ""))
        vector.noms.grups[k] <- pair.group.name
        dif.proportions <- res.test.proport$estimate[1] -   res.test.proport$estimate[2]
        dif.groups.proportion[l,k]<-dif.proportions
        pval.groups.proportion[l,k]<-res.test.proport$p.value
        k <- k+1 #contador de grupos
      }
    }
  }


  #MATRIZ CON DIFERENCIA DE PROPORCIONES
  vector.noms.grups #GRUPOS diferenciales
  dif.groups.proportion
  #MATRIZ CON P-VALOR
  pval.groups.proportion



  ############# transformarlo a un data frame ############################
  dif.groups.proportion1<- data.frame(dif.groups.proportion)
  #View(dif.groups.proportion1)
  pval.groups.proportion1<- data.frame(pval.groups.proportion)
  #View(pval.groups.proportion1)
  #data frame de diferencias de proporciones
  colnames(dif.groups.proportion1)<-vector.noms.grups
  #colnames(dif.groups.proportion1)[i]
  rownames(dif.groups.proportion1)<-rownames(matriu)

  #total.res.volcano<-NA
  for (i in 1: ncol(dif.groups.proportion1)){
    #Grupos separados y ordenados de menor a mayor por proporcion diferencial
    #grup1
    #i=1
    dataframe1<-cbind(dif.groups.proportion1[i], pval.groups.proportion1[i], padj=p.adjust(as.matrix(pval.groups.proportion1[i]), "fdr"))
    dataframe1<-subset(dataframe1,padj<alfa)
    colnames(dataframe1)[2]<-"pval"
    dataframe1<-dataframe1[order(-dataframe1[1]),]
    #View(dataframe1)
    #salvar en un fichero de tipo csv
    write.csv(dataframe1, file = paste(as.character(vector.noms.grups[i]),".csv",sep = "") )


    #hacer un grafico para el dataframe diferencia de proporciones
    #plot(rownames(dataframe1), dataframe1[1], type = "l", main = as.character(vector.noms.grups[i]))
    if(nrow(dataframe1)>0){
      #barplot(as.numeric(unlist(dataframe1[1])),
      #        main = as.character(vector.noms.grups[i]),
      #        xlab = "OTUs",
      #        ylab = "dif proporion",
      #        names.arg = rownames(dataframe1),
      #        col = "blue",
      #        horiz = F)
      library(plotrix)
      a<-dim(dataframe1)[1]
      p1<-as.numeric(abs(unlist(dataframe1[1])))[1:10]#proporciones ms expresadas +
      p2<-as.numeric((unlist(dataframe1[1])))[(a-9):a]#proporciones mas expresadas -
      label1 <-rownames(dataframe1)[1:10]
      label2<-rownames(dataframe1)[(a-9):a]
      label1.2<-paste0(label1, ":", label2)

      #pyramid.plot(p1, abs(p2), labels =  label1.2, main = paste("Dif. proportion (n=10) ", as.character(vector.noms.grups[i])), unit= "\n",
      #             space = 0.3, top.labels=c("+","OTU","-"))

      #do a volcano plot---------------------------------------------------------

      #lim.padj<-0.00001
      #lim.log2FoldChange<-11
      res.volcano<-volcano.proportion.plot(matriu=cbind(X=row.names(dataframe1), dataframe1), lim.padj = lim.padj, lim.log2FoldChange = lim.log2FoldChange)
      #total.res.volcano <- merge(total.res.volcano,res.volcano)

      #class(res.volcano)
      #res.volcano.total <- rbind(res.volcano.total, res.volcano)
      #res.volcano <- cbind(group=colnames(dif.groups.proportion1)[i], res.volcano) #compone el resultado del volcano plot con grupo nombre
      #res.volcano.total<-rbind(res.volcano.total, res.volcano) #añade a todos los grupos
      #return(res.volcano.total)
      #juntar todos los resultados en un data-frame con los grupos

      #analizar todos estos resultados juntos indicando cuales son los mas frecuentes
      #-------------------------------------------------------------------------------


      #library(ggplot2)
      #theme_set(theme_bw())

      #ggplot(dataframe1, aes(x=rownames(dataframe1), y=as.numeric(unlist(dataframe1[1])), label=rownames(dataframe1))) +
      #  geom_point(stat='identity', fill="black", size=6)  +
      #  geom_segment(aes(y = 0,
      #                   x = rownames(dataframe1),
      #                   yend = as.numeric(unlist(dataframe1[1])),
      #                   xend = rownames(dataframe1)),
      #               color = "blue") +
      #  geom_text(color="white", size=2) +
      #  labs(title="Differential proportion analysis - Lollipop chart",
      #       subtitle=as.character(vector.noms.grups[i])) +
      #  ylim(-1, 1) +
      #  coord_flip()

    }


  }

  #return(total.res.volcano)
}

#este plot tambien estaria bien hacerlo
#Gráfico de pirámide
#pyramid.plot(p1, p2, labels =  years, top.labels=c(state, "years", state2),
#             main = paste("Evolution of",  var , "\n"), unit= "\n",
#             lxcol = heat.colors(n = 25, alpha = 0.5),
#             rxcol = heat.colors(n = 25, alpha = 0.5), space = 0.3, gap = 0.08*max(p1), show.values = TRUE,
#             ndig = 0, ppmar= c(2, 6, 2, 6))



################################################
#do a volcano plot
################################################

#https://www.gettinggeneticsdone.com/2014/05/r-volcano-plots-to-visualize-rnaseq-microarray.html

# Download the data from github (click the "raw" button, save as a text file called "results.txt").
# https://gist.github.com/stephenturner/806e31fce55a8b7175af

#example
#diferencias entre grupo verano e invierno
#GpEH <- read.csv("Gp-E-H.csv")
#volcano.proportion.plot(matriu=data.frame(GpEH), lim.padj = 1.0e-250, lim.log2FoldChange = 12)


#Volcano plot function generic
volcano.proportion.plot <- function(matriu, lim.padj = 1.0e-200, lim.log2FoldChange = 6){
  options(show.error.messages=T) # turn off
  #volcano plot dor diference proportions
  #names(res)
  #fold change calculate using dif of proportions
  #res$log2FoldChange<-res[2]
  #head(matriu$log2FoldChange)
  for(i in 1:dim(matriu)[1]){
    #i<-16
    if(matriu[i,2] > 0){ matriu$log2FoldChange[i] <- -log2(matriu[i,2])}
    if(matriu[i,2] <= 0){ matriu$log2FoldChange[i] <- log2(abs(matriu[i,2]))}
  }
  #class(matriu$`Gp-1-2`)
  #res$log2FoldChange[res$log2FoldChange > 0] <- log2(res$log2FoldChange)
  #res$log2FoldChange[res$log2FoldChange <= 0] <- -log2(abs(res$log2FoldChange))

  #names(matriu)
  #res$log2FoldChange<- -log2(res$`Gp-1-2`)
  matriu$padj1<-matriu$padj
  matriu$padj1[matriu$padj1 == 0] <- 1.0e-320
  matriu$log10_padj<- -log10(matriu$padj1)
  #View(matriu)
  # Make a basic volcano plot
  lab.v<-paste("Volcano plot proportions:", names(matriu[2]), sep="")
  with(matriu, plot(matriu$log2FoldChange, -log10(matriu$padj1), pch=20, main=lab.v, ylim=c(0,350),xlab="Log2Foldchange", ylab="-log10(padj)"))
  #plot(matriu$log2FoldChange~ matriu$log10_padj)
  # Add colored points: red if padj<0.05, orange of log2FC>1, green if both)
  with(subset(matriu, padj1<lim.padj), points(log2FoldChange, -log10(padj1), pch=20, col="red"))
  with(subset(matriu, abs(log2FoldChange)<lim.log2FoldChange), points(log2FoldChange, -log10(padj1), pch=20, col="orange"))
  with(subset(matriu, padj1<lim.padj & abs(log2FoldChange)<lim.log2FoldChange), points(log2FoldChange, -log10(padj1), pch=20, col="green"))

  # Label points with the textxy function from the calibrate plot
  #library(calibrate)
  #with(subset(matriu, padj1<lim.padj & abs(log2FoldChange)<lim.log2FoldChange), textxy(log2FoldChange, -log10(padj1), labs=rownames(matriu), cex=.7,offset = 1))
  a<-matriu[matriu$padj1<lim.padj & abs(matriu$log2FoldChange)<lim.log2FoldChange,]
  #son los metagenomeec del grupo 1 respecto al grupo 2
  cat("Classes of group: ", colnames(matriu[2]), " with > foldchange= ", lim.padj,   " & > -log10(padj)=", lim.log2FoldChange, "\n")
  print("----------------------------------------")
  for(i in 1:dim(a)[1]){
    #i<-1
    cat("ID= ", as.character(a[i,1]), ", dif= ", as.character(a[i,2]), ", pval.adj= ", as.character(a[i,3]),"\n")
  }

  print("Number of cases detected: ")
  print(dim(a)[1])
  return(a) #is a matrix

}




