
#toni monleon (5-4-2019) (8-11-2017)

#MIRIAM NETWORK: NETWORK AND GAUSSIAN GRAPHS, ESPECTRAL ANALYSIS USING NETWORK

##################################################################################################
# MIRIAM NETWORK: NETWORK AND GAUSSIAN GRAPHS, ESPECTRAL ANALYSIS USING NETWORK
#################################################################################################
#' Network analysis for frequencies (taxon, omic data, counts) - correlation nwtworking, bayesian networks and Gaussian Graphs with complexity index
#'
#' Function to create networkss and Gaussian Graphs
#' @param mat data-set matrix with data containing the metegenomic frequencies
#' @param minimum minimum number of otus to check complexity
#' @param resample.otu do resampling to increase sensibility (defect = F)
#' @param size.resample number of resamplings (n=100)
#' @export
#' #'
#' @examples
#' #Generate Multinomial Random Variables With Varying Probabilities
#' my_prob <- c(0.2,0.3,0.1,0.3, 0.01, 0.02, 0.01,0.01, 0.01, 0.01, 0.01, 0.01, 0.005, 0.005 )
#' number_of_experiments <- 80 #otu
#' number_of_samples <- 14 #samples
#' #generate a matrix
#' experiments <- rmultinom(n=number_of_experiments, size=number_of_samples, prob=my_prob)
#' experiments
#' MOIX (Monleon complexity index with > edges between otus)
#' Miriam.Network.complexity(mat=t(experiments), minimum=3, resample.otu=F, size.resample=100)

#' @references
#' CI Rodríguez-Casado, A Monleon-Getino, M Cubedo, M Ríos- Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32





#####################################################################################
###                  Miriam Network but with any OTU
#####################################################################################

#funcion para escanear todas las otus con miriam(): numero de conexiones entre otus
Miriam.Network.complexity<-function(mat, minimum=20, maximum=dim(mat)[2], resample.otu=F, size.resample=100){

  options(show.error.messages=F) # turn off

  #si lo hago con remplazamiento
  if(resample.otu==T){
    df <- mat
    mat<-df[sample(nrow(df), size.resample,replace = T), ]
  }

  #Set the maximum
  #num<-unlist(dim(mat[1]))[1]
  num<- maximum

  if(is.null(num)==T){num<-dim(mat)[1]}

  my.array <- array(NA, dim=c(num,4))
  k<-1
  #i<-150
  for(i in minimum:num){
    #i<-1
    #comprobaciones iniciales
    if (minimum > num){
      print("Minimum must be > maximum")
      break
    }
    #comprobaciones iniciales
    if (minimum <3){
      print("Minimum must be >=3")
      break
    }

    #analisis de la complejidad
    out222 <- try(a<-Miriam.Network(matriu=mat, nrows=i, qgraph1=F,  cor.type=1, gaussiangraphs=T, nsimul=3000, print.graph=F))
    #no hay errores de ningun tipo
    if (substr(out222[1],1,5) != "Error"){
      my.array[k,1]<-i
      my.array[k,2]<-unlist(a[1])
      my.array[k,3]<-unlist(a[2])
      my.array[k,4]<-unlist(a[3])
      #my.array[k,5]<-unlist(a[4])
      k<-k+1

    }
  }
  #print("OK-1")
  d <- my.array[1:k-1,]
  #plot de lo que sale
  #print("OK-2")
  library(gplots)
  bandplot(x=as.numeric(d[,1]), d[,3], xlab="OTU", ylab="MOIX(>1)")
  title(main = "COMPLEXITY MOIX(>1)")
  text1<-paste( "MEAN : [Mean=", round(mean(d[,3],na.rm=TRUE),2), ",sd=", round(sd(d[,3],na.rm=TRUE),2), "]" ,sep = "")
  mtext(text1, side = 3)

  return(d)


  options(show.error.messages=T) # turn off

}
