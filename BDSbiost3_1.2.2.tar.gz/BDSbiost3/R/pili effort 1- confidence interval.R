#############################################################################3
# SAMPLE SIZE IN METAGENOMICS: DETERMINATION OF RICHNESS AND EFFORT OF SAMPLING
##############################################################################

# Toni Monleon. Biost3. 8-2017


#############################################################
# Functions to sample size and rarefaction in metagenomics: SAMPLES
#############################################################


#' Sample size (genes, taxon) for omic data: Function to calculate probability of rarefaction and sampling effort index based on resampling
#'
#' Function to caculate RESAMPLING of function PILI.MetagenSample.size()
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param num.remuestras number of resamples (num.remuestras=10)
#' @param niter.b number of iterations for the algorithm (niter.b=200)
#' @return List of estimations: Richness, 95% sampling Effort (sample size), Rarefaction, probaility of saturation using resampling
#' @export
#' #'
#' @examples
#' #Generate Multinomial Random Variables With Varying Probabilities
#' my_prob <- c(0.2,0.3,0.1,0.3, 0.01, 0.02, 0.01,0.01, 0.01, 0.01, 0.01, 0.01, 0.005, 0.005 )
#' number_of_experiments <- 10
#' number_of_samples <- 20
#' #generate a matrix
#' experiments <- rmultinom(n=number_of_experiments, size=number_of_samples, prob=my_prob)
#' experiments
#' # saturation
#' PILI2.MetagenSample.size(matriu=experiments, num.remuestras=3,niter.b=100)
#'
#' @references
#' Monleon-Getino T. 2018. Quantitative metagenomics. Lulu Press inc.

################################################################################
#1-funcion para el calculo de  remuestreo del tamano muestral utilizando algoritmo PILI: PILI.MetagenSample.size
################################################################################
#me dice la probabilidad de saturacion, la de oversampling, IC95% X95
PILI2.MetagenSample.size<-function(matriu, num.remuestras=10,niter.b=200){
  #niter.b=10
  #num.remuestras=2
  library(rcompanion)
  library(gplots)
  library(Publish)
  #matriu<-genus_count.g1.sin0
  options(show.error.messages = F)

  #remuestreo de la matriz original
  M <- matriu
  #num.remuestras<-2
  #variables:
  number.cols<-dim(M)[2]
  if(number.cols <4){
    print("THE SAMPLE SIZE MUST BE > 3. PLEASE USE MORE SAMPLES TO THIS PROCEDURE")
    stop("Ending function")
  }

  Traspose.M<-t(M)

  #Se recoge en B toda la información
  B = matrix(NA, nrow=num.remuestras*number.cols, ncol=10)
  B<- data.frame(B)
  k<-0 #es un contador

  #2 fors para recorrer las columnas (num samples) y hacer una remuestra (orden diferente, es decir mismo numero de columnas pero diferentes)
  for (i in 1:(number.cols-3)){ #para ir mirando diferentes tamaños muestrales desde 3 muestras a todas
    for (j in 1:num.remuestras){
      #num.remuestras<-2
      #number.cols<-5
      #i<-1
      #j<-1
      #k<-1
      k<-k+1
      #print( paste("Trial number=",k,sep=""))

      M.1<-t(Traspose.M[sample(nrow(Traspose.M),size=number.cols,replace=F),])
      #dim(M.1)
      #head(M.1)
      #deberia hacer 50 bootstrap de las muestras que hay
      out2 <- try(AA<-PILI.MetagenSample.size.b(matriu=as.matrix(M.1[,1:(3+i)]), zero=T,niter = niter.b,est.esp ="jack1",l99 = F, l90 = F, bandplot = F,plot.rep = F)) #ejemplo de no saturacion
      if (substr(out2[1],1,5)!="Error"){
        #dev.off() #quitar el grafico anterior
        #options(show.error.messages = T)
        #recoger estimadores de x.95, SATURACION/NO, NUMERO DE MUESTRAS ACTUAL
        B[k,1:8]<-as.matrix(unlist(AA))
      }
    }

  }
  #analisis de la matriz B de resultados de remuestreo
  B1<-B[rowSums(is.na(B[,1:8])) == 0,1:8 ] #quitar los na

  # Plot the mean of teeth length by dose groups (lo quito 11-10-2018)
  #par(mfrow=c(2,1))
  #plotmeans(B1[,5] ~ B1[,1], frame = FALSE,  xlab="samples", ylab="x.95(saturated)", col="red")
  #title(main="X95 to saturation - resampling")
  #plotmeans(B1[,7] ~ B1[,1], frame = FALSE, xlab="samples", ylab="prob(sat / over-sampling)", ylim=c(0,1.5), col="blue")
  #title(main="probability of saturation - resampling")
  #abline(h=1,lty=2,col="green",lwd=0.75)
  #abline(h=0.5,lty=2,col="yellow",lwd=0.75)

  #conficence intervals 95%, 99% y 90%
  B2<-as.data.frame(B1)
  names(B2)<- c("V1","V2","V3","V4","V5","V6","V7","V8")
  B2$V2<- as.numeric(B2$V2)
  B2$V3<- as.numeric(B2$V3)
  B2$V4<- as.numeric(B2$V4)
  B2$V5<- as.numeric(B2$V5)
  B2$V6<- as.numeric(B2$V6)
  B2$V8<- as.numeric(B2$V8)

  #show(B2)
  #print("Num OTUs in saturation per sample")
  numOTUs.logist<-ci.mean(V3 ~ V1, data=B2 )
  #print(numOTUs.logist)
  #print("CI95% for x95 saturation per sample")
  #x95.logist<-ci.mean(B2$V5, data=B2,alpha = 0.05)
  #x90.logist<-ci.mean(B2$V5, data=B2,alpha = 0.1)
  #x99.logist<-ci.mean(B2$V5, data=B2,alpha = 0.01)
  #print("CI95% para x95 non saturation")
  x90.log<-ci.mean(V5 ~ V1, data=B2,alpha = 0.1)
  x95.log<-ci.mean(V5 ~ V1, data=B2,alpha = 0.05)
  x99.log<-ci.mean(V5 ~ V1, data=B2,alpha = 0.01)
  x90.mimen<-ci.mean(V6 ~ V1, data=B2,alpha = 0.1)
  x95.mimen<-ci.mean(V6 ~ V1, data=B2,alpha = 0.05)
  x99.mimen<-ci.mean(V6 ~ V1, data=B2,alpha = 0.01)
  #CALCULO DE MEDIA DE X PARA REACH 95 OTUS ENTRE LOGISTICO Y MICHAELIS Y MENTEN
  media.lo.mime.X95_1 <- ci.mean((B2$V6+B2$V5)/2, data=B2,alpha = 0.1)
  media.lo.mime.X95 <- ci.mean((B2$V6+B2$V5)/2 , data=B2,alpha = 0.05)
  media.lo.mime.X99_2 <- ci.mean((B2$V6+B2$V5)/2 , data=B2,alpha = 0.01)

  #CALCULO DE MEDIA DE OTUS ENTRE MODELO LOGISTICO Y MODELO MCHALIS MENTE
  media.lo.mime.OTU <- ci.mean((B2$V2+B2$V4)/2 , data=B2,alpha = 0.05)

  #print("CI95% para prob saturation")
  #prob.saturacion<-ci.mean(V7 ~ V1, data=B2,alpha = 0.05)
  #print(prob.saturacion)
  #print("CI95% para prob over-sampling")
  prob.saturacion<-ci.mean(V8 ~ V1, data=B2,alpha = 0.05)
  #diferencia media entre los dos modelos
  #media.lo.mime.X95<-ci.mean((x95.mimen + x95.log)/2)
  #media.lo.mime.X90<-ci.mean((x90.mimen$mean + x90.log$mean)/2)
  #media.lo.mime.X99<-ci.mean((x99.mimen$mean + x99.log$mean)/2)

  #plot final de resumen
  par(mfrow=c(1,1))
  plot.final<-as.data.frame(numOTUs.logist) #num otus and ci
  plot.final<-cbind(plot.final, prob.saturacion$mean)
  plot.final$ID<- as.numeric(levels(plot.final$V1))[plot.final$V1] #para ordenar
  #sort plot.final by ID
  plot.final.ordered <- plot.final[order(plot.final$ID),]
  plot.final.ordered<- plot.final.ordered[,-9]
  #recode
  for(i in 1:nrow(plot.final.ordered)){
    #i<-1
      if(plot.final.ordered[i,8]>= 0.8 ){
        plot.final.ordered[i,9] ="green"
        plot.final.ordered[i,10] ="P>0.8"
      }
      if(plot.final.ordered[i,8]< 0.8 & plot.final.ordered[i,8]> 0.6 ){
        plot.final.ordered[i,9] ="yellow"
        plot.final.ordered[i,10] ="0.6<P<0.0"
      }
      if(plot.final.ordered[i,8]<=0.6 ){
        #plot.final.ordered$color.prob ="red"
        #plot.final.ordered$label ="P<=0.6"
        plot.final.ordered[i,9] ="red"
        plot.final.ordered[i,10] ="P<=0.6"
      }
}
  maxx <- max(as.numeric(row.names(plot.final.ordered)), as.numeric(media.lo.mime.X95),na.rm = T)+1
  maxy <- max(as.numeric(plot.final.ordered$upper),na.rm = T)
  par(mfrow=c(1,1))
  #comprobaciones
  if(maxy==-Inf){maxy <- max(as.numeric(plot.final.ordered$mean),na.rm = T)}
  plot(0,0,type = 'l',xlab="SAMPLES" ,ylab="prediction OTUs",
       main="OTU PROBABILITY SATURATION", sub="Model mean (Logistic + Michaelis M)",
       ylim=c(0, 1.2*maxy), xlim=c(0, maxx))
  #mean OTU
  #mtext("sub title")
  t1<- paste("OTU=", round(media.lo.mime.OTU$mean,1), " (", round(media.lo.mime.OTU$lower,1), "-", round(as.numeric(media.lo.mime.OTU$upper,1)),") " ,
             "X95=", round(media.lo.mime.X95$mean,1), " (", round(media.lo.mime.X95$lower,1), "-", round(as.numeric(media.lo.mime.X95$upper,1)),") " ,
              sep ="")
  mtext(t1,side = 3)
  y<-c(0,plot.final.ordered$mean)
  x<-c(0,as.numeric(row.names(plot.final.ordered)))
  points(x,y,col=c("red", plot.final.ordered$V9),lwd=9)
  lines(x,y)
  #lines(c(0,plot.final.ordered$mean)~c(0,as.numeric(row.names(plot.final.ordered))), data=plot.final.ordered )
  #upper
  #polygon( as.numeric(row.names(plot.final.ordered)),plot.final.ordered$upper , border = "red")
  lines(c(plot.final.ordered$upper)~c(as.numeric(row.names(plot.final.ordered))), data=plot.final.ordered,lty=2, col="red" )
  lines(c(0,plot.final.ordered$upper[1])~c(0,as.numeric(row.names(plot.final.ordered))[1]), data=plot.final.ordered,lty=2, col="red" )

  #lower
  lines(c(plot.final.ordered$lower)~c(as.numeric(row.names(plot.final.ordered))), data=plot.final.ordered,lty=2, col="red" )
  lines(c(0,plot.final.ordered$lower[1])~c(0,as.numeric(row.names(plot.final.ordered))[1]), data=plot.final.ordered,lty=2, col="red" )



  #legend("bottomright", legend=levels(as.factor(plot.final.ordered$V10)),
  #       pch=10, col=levels(as.factor(plot.final.ordered$V9)),
  #       title="Prob. of saturation")
  legend("bottomright", legend= c("P>0.8", "0.6<P<0.8", "P<=0.6" ),
         pch=10, col=c("green","yellow", "red"),
         title="Prob. of saturation")
  #x95 con su ic95%
  abline(v=as.numeric(media.lo.mime.X95$mean), col="orange")
  abline(v=as.numeric(media.lo.mime.X95$lower),lty=2, col="orange")
  abline(v=as.numeric(media.lo.mime.X95$upper),lty=2, col="orange")
  #text(as.numeric(media.lo.mime.X95$mean,0,round(as.numeric(media.lo.mime.X95$mean),1)))


  #saturacion
  #plot.sat<-as.data.frame(prob.saturacion) #num otus
  #lines(c(0,mean)~c(0,as.numeric(row.names(plot.sat))), data=plot.final.ordered,col="green" )
  #plot.final.ordered1<-cbind(plot.final.ordered, prob.saturacion$mean)

  #return
  return(list(media.lo.mime.X95,media.lo.mime.OTU,prob.saturacion))

  #estadistica descriptiva
  print("Num OTUs in saturation per sample")
  #(numOTUs.logist<-ci.mean(V3 ~ V1, data=B2 ))
  print(numOTUs.logist)
  #print("CI95% for x95 saturation per sample")
  #(x95.logist<-ci.mean(B2$V5, data=B2))
  #print("CI95% para x95 non saturation")
  #(x95.mimen<-ci.mean(V6 ~ V1, data=B2))
  print("CI95% para prob saturation")
  #(prob.saturacion<-ci.mean(V7 ~ V1, data=B2))
  print(prob.saturacion)
  #print("CI95% para prob over-sampling")
  #(prob.oversampling<-ci.mean(V8 ~ V1, data=B2))



   OTU.PROBABILITY.SATURATION <- data.frame(plot.final.ordered,
                                round(media.lo.mime.OTU$mean,1),
                                round(media.lo.mime.OTU$lower,1),
                                round(as.numeric(media.lo.mime.OTU$upper,1)),
                                round(media.lo.mime.X95$mean,1),
                                round(media.lo.mime.X95$lower,1),
                                round(as.numeric(media.lo.mime.X95$upper,1))
                                )
  write.csv(OTU.PROBABILITY.SATURATION, file = "OTU.PROBABILITY.SATURATION.csv")

}

