
#toni monleon (3-2-2017)

#funcion para analisis a priori de clusters en metagenomica
#automaticamente se?ala el numero de clusters "a priori" utilizando MDS y la distancia de Battacharya

####################################################################
# a mixed bayesian entropy index: diversity and phylogenetics - USING THE MIXTURE OF MULTINOMIALS
####################################################################

#####################################################################################
#####   dbhatta.PAM.Metagen

#####################################################################################

#matriu<-yy4_matR[,2:5]

#matriu matriz de frecuencias (OTUxsamples)
#matriu matriz de frecuencias (OTUxsamples)
dbhatta.PAM.Metagen.bayesian <- function(matriu, perc=0.00001, KL=F, Qnet=2, q1=0, exp.grups=1) {


  #indice de complejidad bayesiano
  #dbhatta.PAM.Metagen.bayesian(matriu,perc=0.0001, KL=F, Qnet=2, q1=1)

  #parametros de la funci?n: matriu=matriz OTUS X SAMPLES DE FRECUENCIAS 16S, 18S,
  # perc. PARA EL HEATMAP PORCENTAJE DE FREC RELATIVA EN SAMPLES MEDIO QUE SE QUIERE VISUALIZAR

  #varios graficos a la vez
  par(mfrow=c(2,2))

  ################################################################################
  #funcion que transforma filas a tanto por uno
  Get.matrix.CODA <- function(matriu) {
    m<-ncol(matriu) #cols
    n<-nrow(matriu) #filas
    matriu.CODA<-matrix(0,nrow = n,ncol = m)
    #sum(matriz_mdsHP.1[,2])
    for (i in 1:m){ #col
      for (j in 1:n){ #row
        #print(samp)
        matriu.CODA[j,i]<-(matriu[j,i]/sum(matriu[,i]))
      }
    }
    #entregable:
    matriu.CODA <<- matriu.CODA
  }



  matriu.ORDERED<-Get.matrix.CODA(matriu)
  matriu.ORDERED[,1]

  #library(MASS)
  #write.table(matriu.ORDERED, file = "mat_jf.csv", sep = ",", col.names = NA,
  #            qmethod = "double")

  #################################################################################
  if (KL==F) {
    #CALCULO DE LA DISTANCIA DE BATTACHARIA MATRICIALMENTE
    # Coeficient de Bhattacharyya (cal escalar les dades entre 0 i 1)
    #class(matriu.ORDERED) #ha de ser una matriz
    Q <- sqrt(matriu.ORDERED)
    BC <- Q%*%t(Q)
    # Dist?ncia de Bhattacharyya (al quadrat)
    BC <- ifelse(BC>1., 1., BC)
    D2B <- acos(BC)
    D2B
    #class(D2B)
    lletra <- "Metric MDS using Battacharyya distance"
  }
  #calculate the dissimilarity of Bray-Curtis & MDS
  #D2B<-vegdist((matriu),method="bray")

  #si se pide divergencia de Kullback-Leiwer
  #See at: https://www.stat.cmu.edu/~cshalizi/754/2006/notes/lecture-28.pdf
  #In probability theory and information theory, the Kullback-Leibler divergence,[1][2] also called information divergence, information gain, relative entropy, KLIC, or KL divergence, is a measure (but not a metric) of the non-symmetric difference between two probability distributions P and Q. The Kullback-Leibler divergence was originally introduced by Solomon Kullback and Richard Leibler in 1951 as the directed divergence between two distributions; Kullback himself preferred the name discrimination information.[3] It is discussed in Kullback's historic text, Information Theory and Statistics.[2]
  #Expressed in the language of Bayesian inference, the Kullback-Leibler divergence from Q to P, denoted DKL(P???Q), is a measure of the information gained when one revises one's beliefs from the prior probability distribution Q to the posterior probability distribution P. In other words, it is the amount of information lost when Q is used to approximate P.[4] In applications, P typically represents the "true" distribution of data, observations, or a precisely calculated theoretical distribution, while Q typically represents a theory, model, description, or approximation of P.
  if (KL==TRUE) {

    lletra<- "Metric MDS using Kullback-Leiwer divergence"
    #pairwise comparations #############################3
    #calcular la matriz de DIVERGENCIAS de Kullback-Leiwer
    library("entropy")
    f<-t(matriu)
    c<-ncol(t(matriu))
    KL.matrix <- matrix(0, c, c)
    n<-1
    for (i in 1:ncol(f)){
      for (j in n:ncol(f)){
        #i<-1
        #j<-2
        KL.matrix[i,j]<-KL.Dirichlet(f[,i], f[,j], a1=1/10, a2=1/10)
      }
      n= n+1
    }

    #matriz simetrica de distancias
    for (i in 1:ncol(KL.matrix)){
      for (j in 1:ncol(KL.matrix)){
        KL.matrix[j,i]<-KL.matrix[i,j]
      }
    }
    D2B<-KL.matrix
  }


  ###############################################################################
    #MDS
  fit.mds <- cmdscale(D2B, eig = TRUE, k = 2)
  x <- fit.mds$points[, 1]
  y <- fit.mds$points[, 2]
  summary(fit.mds)
  fit.mds$eig
  eigen <- data.frame(fit.mds$eig, x, y)
  #eigen[266,2:3]

  #CRITERIO DE mardia
  sum(fit.mds$eig^2)
  (fit.mds$eig[1]^2)/sum(fit.mds$eig^2)
  (fit.mds$eig[2]^2)/sum(fit.mds$eig^2)
  (fit.mds$eig[1]^2 + fit.mds$eig[2]^2)/sum(fit.mds$eig^2)

  #CRITERIO DE inercia
  sum(abs(fit.mds$eig))
  (fit.mds$eig[1])/sum(abs(fit.mds$eig))
  (fit.mds$eig[2])/sum(abs(fit.mds$eig))
  (fit.mds$eig[1] + fit.mds$eig[2])/sum(abs(fit.mds$eig))

  fit.mds$GOF
  plot(x, y,  xlab="Coordinate 1", ylab="Coordinate 2",
       main=lletra, col="blue", cex = 1, lty = "solid")
  abline(h=0, v=0)
  text(x, y, labels=rownames(matriu), cex= 0.75, pos=4, col= "black") #samples

  plot(0,0)
  text(0,.8, "INERTIA 2 COMPONENTS")
  a1<-(abs(fit.mds$eig[1])/sum(abs(fit.mds$eig)))
  a2<-(abs(fit.mds$eig[2])/sum(abs(fit.mds$eig)))
  a1.2<- a1 +  a2
  text(-0.7,0,"2 COORD:" )
  text(0,0,a1.2 )
  text(-0.7,0.3,"1ST COOORD:" )
  text(0,0.3,a1 )
  text(-0.7,0.6,"2ND COOORD:" )
  text(0,0.6,a2 )

  ######################################################################################
  # PAM Clustering with K clusters PARA VER LAS grupos
  library(cluster)
  library(factoextra)
  aa<-fviz_nbclust(fit.mds$points, pam, method = "silhouette")
  str(aa)
  aa$data
  maxim<-max(aa$data[2])
  which(aa$data[2]==maxim)
  #numero optimo de clusters (grupos)
  num.cluster.optim <- as.numeric(which(aa$data[2]==maxim))
  options(show.error.messages = T)

  #hacer PAM
  tmp_pam <- pam(-1*fit.mds$points , k=num.cluster.optim)

  tmp_pam$clusinfo # get cluster info
  tmp_pam$silinfo # get silhouette information
  clusplot(tmp_pam,col.clus=c("blue", "red","black","orange"))

  #title(main = "PAM clustering")
  text(fit.mds$points, labels=rownames(matriu), cex= 0.5, pos=4, col= "black") #samples
  abline(v=0, h=0)



  plot(0,0)
  #fviz_nbclust(fit.mds$points, pam, method = "silhouette")
  text(0,.8, "----------CORRECT CLASSIFICATION -------")
  text(0.1,0, toString(tmp_pam$silinfo$clus.avg.widths)) #samples
  text(0.1,0.5, toString(tmp_pam$silinfo$avg.width)) #samples
  text(0,-0.3, "Num clusters: ")
  text(0.5,-0.3, num.cluster.optim)

  ##################### ser beta-diversity############################
  ##seleccionar los clusters para calcular el CV_BETADIV
  num.cluster.optim
  tmp_pam$clustering #cluster
  matriu[,1]
  rownames(matriu)
  matriu.clust <- data.frame(matriu,clust.num=tmp_pam$clustering)
  #seleccion grupos
  ind <- which(with(matriu.clust, matriu.clust$clust.num==1 ))
  ind
  matriu.sel <- matriu[ ind, ]
  matriu.sel
  matriu[3,]

  library(vegetarian)
  #calculates alpha diversity of entire data-set with standard error
  options(show.error.messages = T) #hay problemas con el bootstrap
  zzz1<-try(H<-H(t(matriu),lev="alpha", q=q1, boot=T, boot.arg=list(num.iter=100)))

  CV_BETADIV<- 0
  #num.cluster.optim<-0
  R.complexity<-0
  num.gr.sig<-0

  #num.cluster.optim<-4
  #se prueba calcular el bootstrap
  if (class(zzz1) =="list"){
    #H<-H(matriu,lev="alpha", q=q1, boot=T, boot.arg=list(num.iter=100))#species richness for entire data set
    #calculates de H' diversity para cada cluster
    if (num.cluster.optim>1) {
      matriu.difs.H <- array( 0,    dim=c(num.cluster.optim,num.cluster.optim) )
      Hprima <- array( 0,    dim=c(num.cluster.optim) )
      #Hprima2 <- array( 0,    dim=c(num.cluster.optim) )
      num.gr.sig <- 0
      for (i in 1:num.cluster.optim){
        for (j in 1:num.cluster.optim){
          #seleccion grupos
          #i<-1
          #grupo a:
          ind.a <- which(with(matriu.clust, matriu.clust$clust.num==i ))
          ind.a
          matriu.sel.a <- matriu[ ind.a, ]
          matriu.sel.a #selecciona la sub-poblacion
          #grupo b:
          ind.b <- which(with(matriu.clust, matriu.clust$clust.num==j ))
          ind.b
          matriu.sel.b <- matriu[ ind.b, ]
          matriu.sel.b #selecciona la sub-poblacion

          #calculates alpha diversity of group a
          res<-Bayesian.Entropy.autom(as.vector(matriu.sel.a))
          Hprima[i] <- res$BayesianH #bayesian Shannon entropy
          #aa<-H(t(matriu.sel),lev="alpha", q=q1, boot=T, boot.arg=list(num.iter=100))#species richness for entire data set
          #Hprima[i]<-aa$H.Value #valor de H' de Shannon para cada cluster
          Hprima[i]
          res$BayesianH95LI
          res$BayesianH95UI

          #calculates alpha diversity of group b
          res.b<-Bayesian.Entropy.autom(as.vector(matriu.sel.b))
          res.b$BayesianH #bayesian Shannon entropy
          res.b$BayesianH95LI
          res.b$BayesianH95UI

          #significative different between groups using the bayesian credible interval
          #calculates if Hprima[i]  is different from Hprima.media

          if (Hprima[i] < res.b$BayesianH95LI) {
            matriu.difs.H[i,j]<-1
          }
          if (Hprima[i] > res.b$BayesianH95UI) {
            matriu.difs.H[i,j]<-1
          }

        }

        #numero de parejas de grupos con entropias diferentes
        num.gr.sig<-sum(matriu.difs.H[lower.tri(matriu.difs.H,diag=F)])
        #pasado a porcentaje del total de comparaciones
        tota.compar.2<-factorial(num.cluster.optim)/(factorial(num.cluster.optim-2)*2)
        porcn.num.grups_difs <- 100*num.gr.sig / tota.compar.2

        #H' de Shannon media para todos los clusters
        Hprima.media <- mean(Hprima)
        CV_BETADIV<- 100*sd(Hprima)/Hprima.media #BETA DIVERSIDAD ratio

      }
    }
  }



  #calcular CV_BETADIV
  ##################

  #affinity propogation optimal number of clusters
  mds <- data.frame(x,y)
  library(apcluster)
  #diferentes tipos de apcluster
  #d.apclus <- apcluster(negDistMat(r=2),mds)#normal
  d.apclus <- apcluster(linKernel(mds, normalize=F))#linnear kernel
  #d.apclus <- apcluster(expSimMat(mds, r=1))#laplace kernel


  #Defining a custom similarity measure that creates a sparse similarity matrix
  #sparseSim <- function(x){
  #  as.SparseSimilarityMatrix(negDistMat(x,r=2),lower=-0.2)
  #}
  #d.apclus <- apcluster(sparseSim,  mds)


  cat("affinity propogation optimal number of clusters:", length(d.apclus@clusters), "\n")
  # 4
  #heatmap(d.apclus)
  plot(d.apclus, mds)
  if (length(d.apclus) < 10) {
  legend("bottomleft", legend=paste("Cluster",1:length(d.apclus)),
         col=rainbow(length(d.apclus)), pch=19)
  }


  #beta-diversity as Var(Y)
  print("calculo del LCBD")
  resbeta<- MetagenSample.size.H(as.matrix(matriu), quart.cut=0.4,type=T,model.probability=1)
  LCBD.a2<- round(mean(resbeta$LCBD1),1) #media de la contribucion de la muestras a la beta-diversidad
  #a3<-H(matriu,lev="gamma", q=q1, boot=F, boot.arg=list(num.iter=100))#species richness for entire data set
  bayesian.richness <- resbeta$Richness2


  #calcula el ratio de complejidad (RC): se compone de la riqueza, el nº de grupos detectados en otu y el nº grupos por gene ontology/filogenia: exp.grups
  min.gr <- min(c(num.cluster.optim, length(d.apclus@clusters)))
  R.complexity<-round( 0.2*bayesian.richness + 0.3*min.gr + 0.5*exp.grups, 2)


  print("-1")
  plot(0,0)
  text(0,.8, "-------CORRECT CLASSIFICATION apcluster----")
  text(0,-0.3, "Num clusters: ")
  text(0.5,-0.3, length(d.apclus@clusters))
  text(0,-0.5, "Ratio.Complexity: ")
  text(0.5,-0.5, R.complexity )

  print("1")
  library(vegetarian)

  #https://cran.r-project.org/web/packages/vegetarian/vegetarian.pdf

  #calculates alpha diversity of entire data-set with standard error
  #a1<-H(matriu,lev="alpha", q=q1, boot=F, boot.arg=list(num.iter=100))#species richness for entire data set
  #a2<-H(matriu,lev="beta", q=q1, boot=F, boot.arg=list(num.iter=100))#species richness for entire data set

  #bayesian alpha-diversity
  #Calculo de la entropia bayesiana con MCMC y Beta-Diversity
  res<-Bayesian.Entropy.autom(as.vector(matriu))
  a1 <- res$BayesianH #bayesian Shannon entropy
  print("1-hasta div alpha")



  #H(matriu,lev="alpha", q=1, boot=F, boot.arg=list(num.iter=100))#species richness for entire data set
  print("2")
  print(a1)
  print(LCBD.a2)
  print(res$ShannonBayes)
  #print(resbeta)
  text(-.5,-0.75, "alpha, beta diversity: ")
  text(0.25,-0.75, round(a1, 1) )
  text(0.5,-0.75, round(LCBD.a2, 1) )
  #text(.8,-0.75, round(a3, 1) )


  #############################################################################
  # realizar un HEATMAP DE INTERPRETACION
  #heatmaps
  library(gplots)  # for heatmap.2
  # to install packages from Bioconductor:
  #source("http://bioconductor.org/biocLite.R")
  #biocLite("Heatplus")  # annHeatmap or annHeatmap2
  library(Heatplus)
  # load the vegan package for hierachical clustering if you want to use distance functions not specified in dist.
  library(vegan)
  # load the RColorBrewer package for better colour options
  library(RColorBrewer)

  #heatmap
  # remove the genera with less than 1% as their maximum relative abundance
  yy4_matR1.1<- data.frame(matriu.ORDERED)
  rownames(yy4_matR1.1)<- rownames(matriu)
  yy4_matR1.1.PERCENT.DF.means<-rowMeans(yy4_matR1.1)
  #componer data frame con las medias
  yy4_matR1.1$means <- yy4_matR1.1.PERCENT.DF.means
  yy4_matR1.1$means

  #perc<-0.0001
  ind <- which(with(yy4_matR1.1, yy4_matR1.1$means < perc ))
  ind
  yy4_matR1.2 <- yy4_matR1.1[ -ind, ]
  table(yy4_matR1.2[,4])
  #ordenar segun la media
  yy4_matR1.3 <- yy4_matR1.2[order(yy4_matR1.2$means),]
  yy4_matR1.3
  # colorRampPalette is in the RColorBrewer package.  This creates a colour palette that shades from light yellow to red in RGB space with 100 unique colours
  scaleyellowred <- colorRampPalette(c("lightyellow", "red"), space = "rgb")(100)
  heatmap(as.matrix(yy4_matR1.3), Rowv = NA, Colv = NA, col = scaleyellowred)
  print("cuatro")


  #RADAR PLOT PARA COMPLEXITY
  library(fmsb)
  data.frame.complexity <- data.frame(round(a1, 1), round(sqrt(LCBD.a2), 1), round(CV_BETADIV, 1) , porcn.num.grups_difs, R.complexity, Qnet )
  colnames(data.frame.complexity)=c("alpha-divers (0-inf)" ,  "LCBD-media(1-INF)", "CV_BETADIV(%)" , "%n clust PAM-dif H(1-inf)" , "R.complex(1-inf)", "Qnets(1-10)" )
  data.frame.complexity=rbind( c(0, 0, 0, 0, 0, 0) , data.frame.complexity) #MAXIMO Y MINIMO DE CADA VARIABLE
  max1<-max(data.frame.complexity)
  data.frame.complexity=rbind(c(max1, max1, max1, max1, max1, max1)  , data.frame.complexity) #MAXIMO Y MINIMO DE CADA VARIABLE

  par(mfrow=c(1,1))

  #indice CMR de complejidad

    #60 grados x 6 = 360
    rad.60 <- 60/90 * 3.141592/2
    #cos(rad.60)

    x1<-round(a1, 1)*sin(0)
    y1<- round(a1, 1)*cos(0)

    x2<-round(LCBD.a2, 1)*sin(rad.60)
    y2<- round(LCBD.a2, 1)*cos(rad.60)

    x3<-round(CV_BETADIV, 1)*sin(rad.60)
    y3<- round(CV_BETADIV, 1)*cos(rad.60)

    x4<-round(porcn.num.grups_difs, 1)*sin(3*rad.60)
    y4<- round(porcn.num.grups_difs, 1)*cos(3*rad.60)

    x5<-round(R.complexity, 1)*sin(4*rad.60)
    y5<- round(R.complexity, 1)*cos(4*rad.60)

    x6<-round(Qnet, 1)*sin(5*rad.60)
    y6<- round(Qnet, 1)*cos(5*rad.60)

    #area del poligo de los puntos
    #indice de complejidad de Monleon-Rodriguez
    CMR <- 0.5*(abs(x1*y2 + x2*y3 + x3*y4 + x4*y5 + x5*y6 + x6*y1 - x2*y1  - x4*y2 - x5*y4 - x6*y5 - x1*y6))

    # The default radar chart proposed by the library:
    radarchart(data.frame.complexity, title = "Sample complexity (CMR) + Qnet", cglcol="red")

    #text(0,0, "Complexity CMR")
    text(0,0, round(CMR,2))



  #print la composicion del indice de complejidad
    print("---------------------------")
    print("INDICE DE COMPLEJIDAD")
    print("alpha-diversity (H')")
    print(round(a1, 1))
    print("LCBD: MEDIA DE CONTRIBUCION A BETA-DIVERSIDAD(0-INF)")
    print(round(LCBD.a2, 1))
    print("CV_BETADIV: COEFCIENTE VARIACION BETA-DIVERSIDAD(%)")
    print(round(CV_BETADIV, 1))
    print("Contribucion a  la beta-diversidad (samples)")
    print(round(LCBD.a2, 1))

    print("POCENTAJE DE PAREJAS DIFERENTES/RESPECTO TOTAL EN n clust PAM (%)")
    print(porcn.num.grups_difs)
    print("RATIO DE COMPLEXITY: INDICE ENTRE Nº DE GRUPOS DETECTADOS, RIQUEZA, GRUPOS FUNCIONALES")
    print(R.complexity)
    print("Qnets" )
    print(Qnet )

    #otra informaion por si puede ayudar
    print("n clust AP")
    print(length(d.apclus@clusters))
    print ("numero de otus en el heatmap")
    print(ind)

    #heatmap
    heatmap(as.matrix(yy4_matR1.3), Rowv = NA, Colv = NA, col = scaleyellowred)

    #### GGMselect - net ##############################
    library(GGMselect)
    library(ggm)
    #matrix
    X <- as.matrix(t(100*yy4_matR1.3))
    # estimate graph
    #GQE <- selectQE(X)
    GQE<-selectFast(X,family=c("C01","LA")) #no va
    adj3<-GQE$C01.LA$G
    #rownames(adj3)<-rownames(matriz_compuesta.graf.1)
    # plot the result (solo permite 180)
    ggm::plotGraph(adj3,tcltk=T)

}



Bayesian.Entropy.autom<-function(X){
  #function to calulate alpha-diversity-authomatically
  #bayesian alpha-diversity
  #Calculo de la entropia bayesiana con MCMC y Beta-Diversity
  X<-rowSums(matriu, na.rm = FALSE, dims = 1)
  nsites<- nrow(matriu)
  N<-sum(X)
  N1<-nsites/2
  N2 <- nsites - N1
  NN <- min(N1,N2)
  #Bayesian.Entropy(X,nsites,N,N1,N2)
  #igual que:
  res<-Bayesian.Entropy(as.vector(X),nsites,N,NN,NN)
  #a1 <- res$ShannonBayes[1,1] #bayesian Shannon entrop
  #print("1-hasta div alpha")

  #devuelve lista de valores
  my_list <- list("BayesianH" = res$ShannonBayes[1,1], "BayesianH95LI" = res$ShannonBayes[1,3],"BayesianH95UI" = res$ShannonBayes[1,7])
  return(my_list)
}
