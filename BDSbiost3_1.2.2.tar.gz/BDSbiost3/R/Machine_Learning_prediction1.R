#5-4-2019
##############################################################
# prediction using a machine leaning algorithms (XBOOST and SVM)
# for Classification
###################################################################
#' Classification/discriminant PREDICTION using machine learning algorithms (LM, XBOOST, SVM, KERNEL, ANN)
#'
#' @param X data-set matrix with data containing the frequencies (ex: rows: OTUs, columns: samples)
#' @param Y if TRUE the matrix is ordered
#' @param num.samples =0.8 number of samples of the trainning set (number of samples > 10-20, 2 groups minimum)
#' @param num.iter number of iterations for the CV (100)
#' @param nrounds.it number of iteration for the XBOOST method (25)
#' @param CV do cross-validation (5 samples group at minimum)
#' @param xboost.tunning  do tunning in xboost for meta-parameters
#' @param print.image print the accuracy plot with bandplots
#' @return Discriminant accuracy estimations: accuracy, kappa, sensibility, especificity
#' @export
#' #'
#' @examples
#'library(HMP) #16S rRNA Sequencing Data from the Human Microbiome Proje
#'data(saliva) #saliva metagenomic test (sample vs taxa)
#'
#'saliva1<- data.frame(saliva)
#'#define the experimental groups
#'saliva1$group<- c(rep("G1", 8),rep("G2", 8),rep("G3", 8))
#'#discriminant analysis (3 groups G1, G2 & G3)
#'ANNA.DISCRIMINANT.MaLearning.Predict(Y=saliva1$group,X=saliva1[1:21],num.samples=0.6,num.iter=30,nrounds.it=15, CV=T)

#'
#' @references
#' Monleon-Getino T et al. 2017. Big Data. Hacia la cuarta revolución industrial. Edicions Universitat Barcelona


#ploblema de CLASIFICACION--------------------------------------
#analisis discriminante machine learning
#con y sin cross validation
ANNA.DISCRIMINANT.MaLearning.Predict <- function(Y,X,num.samples=0.8,num.iter=15,nrounds.it=200,CV=T, xboost.tunning = F, print.image=T) {
  #CV=F

  #num.iter=150
  #CV = cross-validation
  #xboost.tunning = F #tunning dels parametres, triga molt
  #example iris
  #library(MASS)
  #Y<-iris$Species
  #X<-iris[,-5]

  #reconstruir el data-frame
  dataset <- cbind(Y,X)
  if (dim(dataset)[1]<10){
    print("Data sample too small to do DISCRIMINANT ANALYSIS and cross validation, minimum of 5 samples/each group. Change CV=F")
  }

  require(xgboost) #xgboost
  library(kernlab) #kernel regression
  library(caret)
  library(e1071)
  library(MASS)
  library("dplyr")    # for some data preperation
  library("Ckmeans.1d.dp") # for xgb.ggplot.importance
  library(nnet)
  library(ggplot2)
  #################################
  #model optimization para el SVM:
  if(dim(dataset)[1]>=10){
    svm_tune <-tune.svm(Y~., data = dataset,
                        nu =  0.00001:1,  gamma = 10^(-3:1),
                        type='nu-classification', kernel="radial")

    nu1 = svm_tune$best.parameters$nu
    gamma1 = svm_tune$best.parameters$gamma
  }
  #if(dim(dataset)[1]<10){
  #  nu1 = 0.1
  #  gamma1 = 10^-1
  #}
  ##########################################

  #si solo se quiere que te indique los errores de predicción y quizas la R2 de todos los datos es
  #decir del modelo Y~X
  #clasificacion, variable Y
  #CV<-F
  if(CV==F){
    #predicción basada en métodos discriminantes
    #modelo Y~X, Y=clase o factor



    #modelo discriminante SVM
    if(dim(dataset)[1]>=10){
      svm_model <- svm(Y~ ., data=dataset, method="nu-classification", kernel="radial",nu=nu1, gamma=gamma1)
      pred_test_SVM <-predict(svm_model,dataset[,-1])
    }
    if(dim(dataset)[1]<10){
      svm_model <- svm(Y~ ., data=dataset, method="nu-classification", kernel="radial")
      pred_test_SVM <-predict(svm_model,dataset[,-1])
    }

    #accuracy
    aa_svm<-(confusionMatrix(as.factor(dataset$Y), pred_test_SVM))
    svm.accuracy <- aa_svm$overall[1]
    print("svm")
    print(aa_svm)


    #kernel-discriminante-----------------------------------
    ####################################################################################
    #kernlab: Kernel-Based Machine Learning Lab
    #Kernel-based machine learning methods for classification, regression, clustering, novelty detection, quantile regression and dimensionality reduction. Among other methods 'kernlab' includes Support Vector Machines, Spectral Clustering, Kernel PCA, Gaussian Processes and a QP solver.
    #https://cran.r-project.org/web/packages/kernlab/index.html
    library(kernlab)
    pred_test_kernel_discr<- gausspr(Y ~ as.matrix(dataset[,-1]), data=dataset)
    pred_test_kernel <-predict(pred_test_kernel_discr,dataset[,-1])
    #accuracy
    aa_kernel<-(confusionMatrix(pred_test_kernel, dataset$Y ))
    kernel.accuracy <- aa_kernel$overall[1]
    print("kernel discriminant")
    print(aa_kernel)

    #lda-----------------------------------
    lda.model <- lda(Y ~ ., dataset)
    pred_lda <-predict(lda.model,dataset[,-1])
    #accuracy
    aa_lda<-(confusionMatrix(pred_lda$class, dataset$Y ))
    lda.accuracy <- aa_lda$overall[1]
    print("LDA discriminant")
    print(aa_lda)

    #XBOOST-----------------------------------
    library(xgboost)
    clase.train<- as.vector(as.numeric(factor(dataset$Y))-1)
    #clase.train<-as.factor(clase.train)
    #dtrain1 <- xgb.DMatrix(data = as.matrix(trainset[,12:20]), label = clase.train)
    num.X<-dim(dataset)[2] #numero de variables independientes
    dtrain1 <- xgb.DMatrix(data = as.matrix(dataset[,2:num.X]), label = clase.train)
    numberOfClasses <- length(unique(dataset$Y))
    #optimize

    #mas de mas dos clases prediccion con multi:softprob
    #if(numberOfClasses>2){
      xgb_params <- list(eta = 0.01,
                         max_depth = 50,
                         "objective" = "multi:softprob",
                         "eval_metric" = "merror",
                         "num_class" = numberOfClasses,
                         nthread = 4,
                         subsample = 0.8,
                         colsample_bytree = 0.8)

      # Fit cv.nfold * cv.nround XGB models and save OOF predictions
      cv_model_xboost <- xgb.cv(params = xgb_params,
                                data = dtrain1,
                                nfold = 10,
                                nrounds = nrounds.it,
                                verbose = T,
                                prediction = TRUE,
                                maximize = F, showsd = T)
    #}

  #mas de dos clases binaria
  #if(numberOfClasses==2){
      #  cv_model_xboost <- xgb.cv(data = dtrain1, nrounds = nrounds.it, nthread = 2,
      #                        nfold = 5, metrics = "rmse",
      #           max_depth = 3, eta = 1, objective = "binary:logistic",
      #           prediction = TRUE, verbose = T, showsd = T)
   #}

    #optimize see at:
    #https://www.hackerearth.com/practice/machine-learning/machine-learning-algorithms/beginners-tutorial-on-xgboost-parameter-tuning-r/tutorial/
    #xgb1 <- xgb.train (params = xgb_params, data = dtrain1, nrounds = 79, watchlist = list(val=dtest,train=dtrain), print.every.n = 10, early.stop.round = 10, maximize = F )
    #xgbcv.error <-  mean(as.vector(cv_model_xboost$evaluation_log[,2]))


    OOF_prediction <- data.frame(cv_model_xboost$pred) %>%
      mutate(max_prob = max.col(., ties.method = "last"),
             label = clase.train+1)
    head(OOF_prediction)
    aa_xboost<-confusionMatrix(factor(OOF_prediction$max_prob),
                               factor(OOF_prediction$label),
                               mode = "everything")

    xboost.accuracy <- aa_xboost$overall[1]
    print("XBOOST discriminant")
    print(aa_xboost)

    #neural nets: ANN -----------------
    #require(neuralnet)
    #require(nnet)
    #require(ggplot2)
    #https://www.r-bloggers.com/multilabel-classification-with-neuralnet-package/
    #library(nnet)
    ideal <- class.ind(Y)
    irisANN = nnet(X, ideal, size=2, softmax=TRUE)
    pred_ANN <-predict(irisANN, X, type="class")
    #accuracy
    aa_ANN<-(confusionMatrix(as.factor(pred_ANN), dataset$Y ))
    ANN.accuracy <- aa_ANN$overall[1]
    print("ANN discriminant")
    print(aa_ANN)


    #PRINT RESUMEN FINAL
    print("========================================")
    print("Accuracy of the discriminant methods")
    print("========================================")
    print("SVM:.........")
    print(svm.accuracy)
    print("Kernel-discriminant:......... ")
    print(kernel.accuracy)
    print("LDA:......... ")
    print(lda.accuracy)
    print("XBOOST:......... ")
    print(xboost.accuracy)
    print("ANN(Artificial Neural nets):.............")
    print(ANN.accuracy)
  }

  #con cross-validacion
  if(CV==T){
    #verificar tamano del conjunto de datos, minimo de 5 cada grupo

    #lo que debe entregarse con unos band plots con accuracy
    #sensibilidad y especificidad
    DISCRIM.DATA.FRAME<-dataset
    #num.samples<-0.7

    if (dim(DISCRIM.DATA.FRAME)[1]<10){
      print("Data sample too small to do cross validation, minimum of 5 samples/each group")
    }

    #select a random sample !!!!!!!!!!!
    #num_samples <-0.9
    DISCRIM.DATA.FRAME[,'train'] <- ifelse(runif(nrow(DISCRIM.DATA.FRAME))<num.samples,1,0)
    #separate training and test sets
    trainset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==1,]
    testset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==0,]
    #get column index of train flag
    trainColNum <- grep("train",names(trainset))
    #remove train flag column from train and test sets
    trainset <- trainset[,-trainColNum]
    testset <- testset[,-trainColNum]
    #get column index of predicted variable in dataset
    typeColNum <- grep("Y",names(DISCRIM.DATA.FRAME))
    #View(DISCRIM.DATA.FRAME)


    ######### tunning XBOOST ###############
    if (xboost.tunning==T){
      ######### tunning XBOOST ###############
      numberOfClasses <- length(unique(dataset$Y))
      dataset1<-dataset
      dataset1$Y<-as.factor(as.numeric(dataset$Y))
      #View(dataset1)
      #set.seed(6879)
      # define training control using k-fold Cross Validation
      #train_control <- trainControl(method="cv", number=10)
      bootControl <- trainControl(method="cv", number=10)
      #parametros a optimizar
      xgbGrid <- expand.grid(
        eta = c(0.01, 0.1, 0.3, 0.5, 0.8, 1),
        max_depth = 6,
        nrounds = nrounds.it,
        gamma = c(0, 3, 10),
        colsample_bytree = 0.6,
        min_child_weight = 1,
        subsample=0.7
      )

      modFitxgb_B <-  train(
        Y ~ .,
        data = dataset1,
        trControl = bootControl,
        tuneGrid = xgbGrid,
        metric = "Accuracy",
        method = "xgbTree",
        verbose = 1,
        num_class = numberOfClasses,
        eval_metric = "mlogloss",
        objective = "multi:softprob",
        kfold=1

      )
      print("optimizacion de parametros XGBOOST")
      print(modFitxgb_B$bestTune)
      #parametros
      max_depth.xb<-modFitxgb_B$bestTune[2]#max-depth
      eta.xb<-modFitxgb_B$bestTune[3]#eta
      gamma.xb<-modFitxgb_B$bestTune[4]#gamma
    }
    if (xboost.tunning==F){
      #por defecto
      #https://xgboost.readthedocs.io/en/latest/parameter.html
      max_depth.xb<-6#max-depth
      eta.xb<-0.3#eta
      gamma.xb<-0#gamma
    }

    #num.iter<-numsim
    #num.iter<-10
    my.array.validation.model <- array(NA, dim=c(num.iter,20))
    for (i in 1:num.iter){
      #num.iter <- 25
      #i=1
      #selection of training and test set
      #print("aqui 292, hola, hola------------------------------1111------------------")
      #num.samples<-0.6
      #corregir error que siempre selecciona conjunto de training (todo 1)
      repeat {
        random_set <- ifelse(runif(nrow(DISCRIM.DATA.FRAME))<num.samples,1,0)
        random_set #conjunto aleatorio de datos dividido en 1 = conjunto training y 0 conjunto de test

        if (sum(random_set)<dim(DISCRIM.DATA.FRAME)[1] ) {break}   # Negation is crucial here!
      }

        #seleccionar conjunto de training (1) y de test (0) buenos
        DISCRIM.DATA.FRAME[,'train'] <- random_set #ifelse(runif(nrow(DISCRIM.DATA.FRAME))<num.samples,1,0)
        #separate training and test sets
        trainset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==1,]
        testset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==0,]
        #get column index of train flag
        trainColNum <- grep("train",names(trainset))
        #remove train flag column from train and test sets
        trainset <- trainset[,-trainColNum]
        testset <- testset[,-trainColNum]
        #get column index of predicted variable in dataset
        typeColNum <- grep("Y",names(DISCRIM.DATA.FRAME))




      #model SVM-----------------------
      svm_model <- svm(as.factor(Y)~ ., data=trainset, method="nu-classification", kernel="radial",nu=nu1, gamma=gamma1)
      #test set predictions
      pred_test <-predict(svm_model,testset)
      mean(pred_test==testset$Y)
      aa<-(confusionMatrix(as.factor(testset$Y), pred_test))
      #accuracy-SENSIBILITY-SPECIFICITY
      my.array.validation.model[i,1] <- as.numeric(aa$overall[1])
      my.array.validation.model[i,2] <- as.numeric(aa$overall[2])
      if( is.na(as.numeric(aa$byClass[1]) )==F ){
        my.array.validation.model[i,3] <- as.numeric(aa$byClass[1]) #sens
      }
      if( is.na(as.numeric(aa$byClass[1]) )==T ){
        my.array.validation.model[i,3] <- 0 #sens es NA
      }
      my.array.validation.model[i,4] <- as.numeric(aa$byClass[2])#specificity


      #kernel-discriminante-----------------------------------
      library(kernlab)
      pred_test_kernel_discr<- gausspr(Y ~ as.matrix(trainset[,-1]), data=trainset)
      pred_test_kernel <-predict(pred_test_kernel_discr,testset[,-1])
      aa11<-(confusionMatrix(as.factor(testset$Y), pred_test))
      #accuracy-SENSIBILITY-SPECIFICITY
      my.array.validation.model[i,5] <- as.numeric(aa11$overall[1])
      my.array.validation.model[i,6] <- as.numeric(aa11$overall[2])
      my.array.validation.model[i,7] <- as.numeric(aa11$byClass[1]) #sens
      my.array.validation.model[i,8] <- as.numeric(aa11$byClass[2])#specificity


      #lda-----------------------------------
      lda.model <- lda(Y ~ ., trainset)
      pred_lda <-predict(lda.model,testset[,-1])
      #accuracy
      aa_lda<-(confusionMatrix(testset$Y, pred_lda$class))
      #accuracy-SENSIBILITY-SPECIFICITY
      my.array.validation.model[i,9] <- as.numeric(aa_lda$overall[1])
      my.array.validation.model[i,10] <- as.numeric(aa_lda$overall[2])
      my.array.validation.model[i,11] <- as.numeric(aa_lda$byClass[1]) #sens
      my.array.validation.model[i,12] <- as.numeric(aa_lda$byClass[2])#specificity



      #XGBOOST------------------------------------------------------------------------------------
      #print("aqui 350, hola, hola------------------------------1111------------------")
      #out.W <- try(model.SSweibull.W <- nlsLM(formula = Y.otu.gen ~ asindota.weibull.W-b.w4p*exp(-exp(c.w4p)*X.reads^d),
      #                                        control = nls.lm.control(ftol = 1e-5, ptol = 1e-5),
      #                                        data=vector.reads,
      #                                        start = list( d=d.w4p),
      #                                       lower = c(  d = 0),
      #                                        upper = c(  d = 100)))
      #if (substr(out.W[1],1,5) != "Error"){

      # Create numeric labels with one-hot encoding
      #(as.numeric(dataset$Y)-1)
      train_labs <- (as.numeric(trainset$Y)-1) #labels[0,numclases]
      val_labs <- (as.numeric(testset$Y)-1) #labels[0,numclases]
      # Prepare matrices
      xgb_train <- xgb.DMatrix(data = as.matrix(trainset[,-1]), label = train_labs)
      xgb_val <- xgb.DMatrix(data = as.matrix(testset[,-1]), label = val_labs)
      # Set parameters(default)
      numberOfClasses <- length(unique(trainset$Y))
      #print("aqui 368, hola, hola------------------------------1111------------------")
      #parameters
      params <- list(booster = "gbtree",
                     objective = "multi:softprob",
                     num_class = numberOfClasses,
                     eval_metric = "mlogloss",
                     eta=as.numeric(eta.xb),
                     gamma=as.numeric(gamma.xb),
                     max_depth=as.numeric(max_depth.xb))


      # Create the model
      #print("aqui 380, hola, hola------------------------------1111------------------")
      xgb_model <- xgb.train(params = params, data = xgb_train, nrounds = nrounds.it)
      #print("aqui 381, hola, hola------------------------------1111------------------")
      # Predict for validation set
      xgb_val_preds <- predict(xgb_model, newdata = xgb_val,na.action = na.pass)
      #predictionsTree <- predict(treeFit, testdata,na.action = na.pass)
      xgb_val_out <- matrix(xgb_val_preds, nrow = numberOfClasses, ncol = length(xgb_val_preds) / numberOfClasses) %>%
        t() %>%
        data.frame() %>%
        mutate(max = max.col(., ties.method = "last"), label = val_labs + 1)
      # Confustion Matrix
      xgb_val_conf <- table(true = val_labs + 1, pred = xgb_val_out$max)
      # Function to compute classification error
      classification_error <- function(conf_mat) {
        conf_mat = as.matrix(conf_mat)
        error = 1 - sum(diag(conf_mat)) / sum(conf_mat)
        return (error)
      }

      cat("XGB Validation Classification Error Rate:", classification_error(xgb_val_conf), "\n")

      #check if the number of levels are the same or not
      #print("aqui 402, hola, hola------------------------------1111------------------")
      if (identical(levels(factor(testset$label)), levels(factor(xgb_val_out$max)))==F){
        #solucion buena
        #https://www.reddit.com/r/Rlanguage/comments/733g6p/predicting_with_caret_confusionmatrix_giving_me/

        #join the two Y reals - Y predicted: \\\-\\\
        tot.factor <- c(as.character(xgb_val_out$label),as.character(xgb_val_out$max))
        tot.factor  <- as.factor(tot.factor )

        #tot.factor<-factor(cbind(xgb_val_out$label,xgb_val_out$max))

        #solucion cutre
        predict.y<- as.factor(xgb_val_out$max) #TODOS LOS NIVELES DEL Y ORIGINAL
        levels(predict.y)<-c(levels(factor(tot.factor)))

        xgb_val_conf2 <- confusionMatrix(factor(xgb_val_out$label),
                                         predict.y,
                                         mode = "everything")
      }
      #print("aqui 421, hola, hola------------------------------1111------------------")
      if (identical(levels(factor(xgb_val_out$label)), levels(factor(xgb_val_out$max)))==T){
        # Automated confusion matrix using "caret"
        xgb_val_conf2 <- confusionMatrix(factor(xgb_val_out$label),
                                         factor(xgb_val_out$max),
                                         mode = "everything")
      }

      #print(xgb_val_conf2)
      #accuracy-SENSIBILITY-SPECIFICITY
      #print("aqui 368, hola, hola------------------------------1111------------------")
      my.array.validation.model[i,13] <- as.numeric(xgb_val_conf2$overall[1])
      my.array.validation.model[i,14] <- as.numeric(xgb_val_conf2$overall[2])
      my.array.validation.model[i,15] <- as.numeric(xgb_val_conf2$byClass[1]) #sens
      my.array.validation.model[i,16] <- as.numeric(xgb_val_conf2$byClass[2])#specificity

      #print("Hola, hola, hola------------------------------------------------")
      #print(i)
      #print(my.array.validation.model[i,13])
      #print("Hola, hola, hola------------------------------------------------")
      #print("Hola, hola, hola------------------------------------------------")
      #print("Hola, hola, hola------------------------------------------------")
      #print("Hola, hola, hola------------------------------------------------")
      #print("Hola, hola, hola------------------------------------------------")
      #xgboost at:
      #https://www.r-bloggers.com/an-introduction-to-xgboost-r-package/
      #https://www.analyticsvidhya.com/blog/2016/01/xgboost-algorithm-easy-steps/
      #optimizacion de los parametros
      #https://analyticsdataexploration.com/xgboost-model-tuning-in-crossvalidation-using-caret-in-r/
      #XGBOOST----------------------------------------------------------------------


      #neural nets--------------------------------------------------------------------------------------
      #https://www.r-bloggers.com/multilabel-classification-with-neuralnet-package/
      ideal1 <- class.ind(trainset$Y)
      irisANN = nnet(trainset[,-1], ideal1, size=2, softmax=TRUE)
      pred_ANN1 <-predict(irisANN, testset[,-1], type="class")
      #accuracy
      #check if the number of cattegories are the same
      if (identical(levels(factor(pred_ANN1)), levels(factor(testset$Y)))==F){
        #solucion buena
        #https://www.reddit.com/r/Rlanguage/comments/733g6p/predicting_with_caret_confusionmatrix_giving_me/

        #join the two Y reals - Y predicted: \\\-\\\
        #tot.factor1<-as.factor(cbind(pred_ANN1,testset$Y))

        #solucion cutre
        predict.yy<- as.factor(pred_ANN1)
        levels(predict.yy)<-c(levels(factor(testset$Y )))
        #levels(testset$Y)<-c(levels(factor(tot.factor1)))
        aa_ANN<-(confusionMatrix(predict.yy, testset$Y ))
      }
      if (identical(levels(factor(pred_ANN1)), levels(factor(testset$Y)))==T){
        #NUMERO DE NIVELES IGUAles
        aa_ANN<-(confusionMatrix(as.factor(pred_ANN1), testset$Y ))
      }
      #ANN.accuracy <- aa_ANN$overall[1]
      #print("ANN discriminant")
      #print(aa_ANN)
      #accuracy-SENSIBILITY-SPECIFICITY
      my.array.validation.model[i,17] <- as.numeric(aa_ANN$overall[1])
      my.array.validation.model[i,18] <- as.numeric(aa_ANN$overall[2])
      my.array.validation.model[i,19] <- as.numeric(aa_ANN$byClass[1]) #sens
      my.array.validation.model[i,20] <- as.numeric(aa_ANN$byClass[2])#specificity

    }
    options(show.error.messages=T) # turn off

    #si se quiere visualizar los graficos o no
    if(print.image==T){
      library(gplots)
      #my.array.validation.model
      #my.array.validation.model
      #library(gplots)
      #SVM-----------------------
      par(mfrow=c(4,1))
      #accuracy
      if(all(is.na(my.array.validation.model[,1]))==T){my.array.validation.model[,1]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,1], xlab="Iterations SVM", ylab="Accuracy(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION SVM")
      text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,1],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,1],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text1, side = 3)
      #kappa----
      if(all(is.na(my.array.validation.model[,2]))==T){my.array.validation.model[,2]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,2], xlab="Iterations SVM", ylab="kappa(testset) n=50 sets")
      title(main = "kappa SVM")
      text2<-paste( "MEAN kappa: [Mean=", round(mean(my.array.validation.model[,2],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,2],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text2, side = 3)
      #sensibility -----
      if(all(is.na(my.array.validation.model[,3]))==T){my.array.validation.model[,3]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,3], xlab="Iterations SVM", ylab="SENSIBILITY(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION SVM")
      text3<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,3],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,3],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text3, side = 3)
      #specificity----
      if(all(is.na(my.array.validation.model[,4]))==T){my.array.validation.model[,4]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,4], xlab="Iterations SVM", ylab="SPECIFICITY(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION SVM")
      text4<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,4],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,4],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text4, side = 3)


      #KERNEL-----------------------
      par(mfrow=c(4,1))
      #accuracy
      if(all(is.na(my.array.validation.model[,5]))==T){my.array.validation.model[,5]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,5], xlab="Iterations KERNEL", ylab="Accuracy(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION KERNEL-DISCRIM")
      text5<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,5],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,5],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text5, side = 3)
      #kappa
      if(all(is.na(my.array.validation.model[,6]))==T){my.array.validation.model[,6]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,6], xlab="Iterations KERNEL", ylab="kappa(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION KERNEL-DISCRIM")
      text6<-paste( "MEAN kappa: [Mean=", round(mean(my.array.validation.model[,6],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,6],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text6, side = 3)
      #sensibility -----
      if(all(is.na(my.array.validation.model[,7]))==T){my.array.validation.model[,7]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,7], xlab="Iterations SVM", ylab="SENSIBILITY(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION KERNEL-DISCRIM")
      text7<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,7],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,7],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text7, side = 3)
      #specificity----
      if(all(is.na(my.array.validation.model[,8]))==T){my.array.validation.model[,8]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,8], xlab="Iterations SVM", ylab="SPECIFICITY(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION KERNEL-DISCRIM")
      text8<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,8],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,8],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text8, side = 3)

      #LDA-----------------------
      par(mfrow=c(4,1))
      #accuracy
      if(all(is.na(my.array.validation.model[,9]))==T){my.array.validation.model[,9]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,9], xlab="Iterations KERNEL", ylab="Accuracy(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION LDA")
      text9<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,9],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,9],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text9, side = 3)
      #kappa
      if(all(is.na(my.array.validation.model[,10]))==T){my.array.validation.model[,10]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,10], xlab="Iterations KERNEL", ylab="KAPPA(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION LDA")
      text10<-paste( "MEAN kappa: [Mean=", round(mean(my.array.validation.model[,10],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,10],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text10, side = 3)
      #sensibility -----
      if(all(is.na(my.array.validation.model[,11]))==T){my.array.validation.model[,11]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,11], xlab="Iterations SVM", ylab="SENSIBILITY(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION LDA")
      text11<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,11],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,11],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text11, side = 3)
      #specificity----
      if(all(is.na(my.array.validation.model[,12]))==T){my.array.validation.model[,12]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,12], xlab="Iterations SVM", ylab="SPECIFICITY(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION LDA")
      text12<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,12],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,12],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text12, side = 3)

      #xgboost---------------------------------
      par(mfrow=c(4,1))
      #accuracy
      if(all(is.na(my.array.validation.model[,13]))==T){my.array.validation.model[,13]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,13], xlab="Iterations KERNEL", ylab="Accuracy(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION XBOOST")
      text13<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,13],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,13],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text13, side = 3)
      #KAPPA
      if(all(is.na(my.array.validation.model[,14]))==T){my.array.validation.model[,14]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,14], xlab="Iterations KERNEL", ylab="KAPPA(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION XBOOST")
      text14<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,14],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,14],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text14, side = 3)
      #sensibility -----
      if(all(is.na(my.array.validation.model[,15]))==T){my.array.validation.model[,15]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,15], xlab="Iterations SVM", ylab="SENSIBILITY(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION XBOOST")
      text15<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,15],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,15],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text15, side = 3)
      #specificity----
      if(all(is.na(my.array.validation.model[,16]))==T){my.array.validation.model[,16]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,16], xlab="Iterations SVM", ylab="SPECIFICITY(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION XBOOST")
      text16<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,16],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,16],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text16, side = 3)

      #ANN---------------------------------
      par(mfrow=c(4,1))
      #accuracy
      if(all(is.na(my.array.validation.model[,17]))==T){my.array.validation.model[,17]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,17], xlab="Iterations ANN", ylab="Accuracy(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION ANN")
      text17<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,17],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,17],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text17, side = 3)
      #KAPPA
      if(all(is.na(my.array.validation.model[,18]))==T){my.array.validation.model[,18]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,18], xlab="Iterations ANN", ylab="KAPPA(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION ANN")
      text18<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,18],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,18],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text18, side = 3)
      #sensibility -----
      if(all(is.na(my.array.validation.model[,19]))==T){my.array.validation.model[,19]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,19], xlab="Iterations ANN", ylab="SENSIBILITY(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION ANN")
      text19<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,19],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,19],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text19, side = 3)
      #specificity----
      if(all(is.na(my.array.validation.model[,20]))==T){my.array.validation.model[,20]=0} #filtro para evitar errores con los NA
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,20], xlab="Iterations ANN", ylab="SPECIFICITY(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION ANN")
      text20<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,20],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,20],na.rm=TRUE),2), "]" ,sep = "")
      #text1
      mtext(text20, side = 3)
    }
    #SOLO CALCULAR LOS ESTADISTICOS E IMPRIMIR...
    if(print.image==F){
      text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,1],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,1],na.rm=TRUE),2), "]" ,sep = "")
      text2<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,2],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,2],na.rm=TRUE),2), "]" ,sep = "")
      text3<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,3],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,3],na.rm=TRUE),2), "]" ,sep = "")
      text4<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,4],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,4],na.rm=TRUE),2), "]" ,sep = "")

      text5<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,5],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,5],na.rm=TRUE),2), "]" ,sep = "")
      text6<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,6],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,6],na.rm=TRUE),2), "]" ,sep = "")
      text7<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,7],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,7],na.rm=TRUE),2), "]" ,sep = "")
      text8<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,8],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,8],na.rm=TRUE),2), "]" ,sep = "")

      text9<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,9],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,9],na.rm=TRUE),2), "]" ,sep = "")
      text10<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,10],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,10],na.rm=TRUE),2), "]" ,sep = "")
      text11<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,11],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,11],na.rm=TRUE),2), "]" ,sep = "")
      text12<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,12],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,12],na.rm=TRUE),2), "]" ,sep = "")

      text13<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,13],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,13],na.rm=TRUE),2), "]" ,sep = "")
      text14<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,14],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,14],na.rm=TRUE),2), "]" ,sep = "")
      text15<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,15],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,15],na.rm=TRUE),2), "]" ,sep = "")
      text16<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,16],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,16],na.rm=TRUE),2), "]" ,sep = "")

      text17<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,17],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,17],na.rm=TRUE),2), "]" ,sep = "")
      text18<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,18],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,18],na.rm=TRUE),2), "]" ,sep = "")
      text19<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,19],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,19],na.rm=TRUE),2), "]" ,sep = "")
      text20<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,20],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,20],na.rm=TRUE),2), "]" ,sep = "")


      print("RESULTS CLASSIFICATION --------")
      print("SVM-----------------------")
      print(text1)
      print(text2)
      print(text3)
      print(text4)

      print("KERNEL-----------------------")
      print(text5)
      print(text6)
      print(text7)
      print(text8)

      print("LDA-----------------------")
      print(text9)
      print(text10)
      print(text11)
      print(text12)

      print("xgboost---------------------------------")
      print(text13)
      print(text14)
      print(text15)
      print(text16)

      print("ANN---------------------------------")
      print(text17)
      print(text18)
      print(text19)
      print(text20)
    }
    options(show.error.messages=T) # turn off

  }
}

