
#toni monleon (5-4-2019) (8-11-2017)


##################################################################################################
# MIRIAM NETWORK: CONFIDENCE INTERVAL OF MIRIAM NETWORK BASED ON GAUSSIAN GRAPHS AND COMPLEXITY ANALYSIS
#################################################################################################
#' Confidence interval of function Miriam network (Complexity index based on composition of edges at Gaussian Graphs)
#'
#' Function to create networkss and Gaussian Graphs
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param vector.labels vector labels for columns
#' @param nrows number of rows selected
#' @param print.graph print complexity index plots (Yes/Not)
#' @return Confidence interval for Complexity index based on Gaussian graphs networks
#' @export
#' #'
#' @examples
 #' library(HMP) #16S rRNA Sequencing Data from the Human Microbiome Proje
#' data(saliva) #saliva metagenomic test (sample vs taxa)
#' saliva1<- data.frame(t(saliva))
#' #define the experimental groups
#' labels1<- c(rep("G1", 8),rep("G2", 8),rep("G3", 8))
#' colnames(saliva1)<-labels1
#'
#' #TAXA NETWORKING USING GAUSSIAN GRAPHS AND COMPLEXITY ANALYSIS
#' Miriam.Network(matriu=saliva1, nrows=12, qgraph1=F,  cor.type=1, gaussiangraphs=T, nsimul=3000, print.graph=T)
#'
#' #CONFIDENCE INTERVAL FOR COMPLEXITY INDEX
#' Miriam.NetworkIC(matriu=saliva1, nrows=12, print.graph=F)

#' @references
#' CI Rodríguez-Casado, A Monleon-Getino, M Cubedo, M Ríos- Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32




#funcion que hace el calculo del intervalo de variacion del indice de complejidad
#utilizando remuestreo de filas y de columnas
Miriam.NetworkIC <- function(matriu, nrows=50, vector.labels, cor.type=2, print.graph=F){
  qgraph1<-F
  gaussiangraphs=T
  bayesian.graph=F
  library(dplyr)
  my.array.validation.model <- array(NA, dim=c(nsimul,3))

  for (i in 1: nsimul){
    #i<-1
    #x1<-sample_n(matriu,replace = T,size = dim(matriu)[1]+2) #sample de filas
    x2<-sample(matriu, replace = T,size = dim(matriu)[2]) #sample de columnas
    #x2
    indice.complejidad<-Miriam.Network(matriu=x2, nrows=nrows, qgraph1=qgraph1, vector.labels=vector.labels, cor.type=2, gaussiangraphs=T, bayesian.graph=F, cut = 0.8, nsimul=nsimul,print.graph=print.graph)
    my.array.validation.model[i,1]<-as.numeric(indice.complejidad[1])
    my.array.validation.model[i,2]<-as.numeric(indice.complejidad[2])
    my.array.validation.model[i,3]<-as.numeric(indice.complejidad[3])
  }
    #resultados de todas las iteraciones del indice de compeljidad
    library(gplots)
    #par(mfrow=c(3,2))
    #complexity index1
    bandplot(x=rep(1:nsimul,1), my.array.validation.model[,1], xlab="Iterations", ylab="complexity index1 n=xxx sets")
    title(main = "COMPLEXITY INDEX 1")
    text1<-paste( "MEAN : [Mean=", round(mean(my.array.validation.model[,1],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,1],na.rm=TRUE),2), "]" ,sep = "")
    mtext(text1, side = 3)

    #complexity index2
    bandplot(x=rep(1:nsimul,1), my.array.validation.model[,2], xlab="Iterations", ylab="complexity index1 n=xxx sets")
    title(main = "COMPLEXITY INDEX 2")
    text2<-paste( "MEAN : [Mean=", round(mean(my.array.validation.model[,2],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,2],na.rm=TRUE),2), "]" ,sep = "")
    mtext(text2, side = 3)

    #NUMBER OF GROUPS
    bandplot(x=rep(1:nsimul,1), my.array.validation.model[,3], xlab="Iterations", ylab="GROUPS n=xxx sets")
    title(main = "NUMBER OF GROUPS 1")
    text3<-paste( "MEAN : [Mean=", round(mean(my.array.validation.model[,3],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,3],na.rm=TRUE),2), "]" ,sep = "")
    mtext(text3, side = 3)

  #print
    print("Results of complexity index (Monleon 2018")
    print("COMPLEXITY INDEX 1...................")
    print(text1)
    a<-quantile(my.array.validation.model[,1],na.rm=TRUE,probs = c(0.025,0.975))
    print(a) #intervalo de confianza quantil
    print("COMPLEXITY INDEX 2...................")
    print(text2)
    a1<-quantile(my.array.validation.model[,2],na.rm=TRUE,probs = c(0.025,0.975))
    print(a1) #intervalo de confianza quantil
    print("NUMBER OF GROUPS DETECTED............")
    print(text3)
    a2<-quantile(my.array.validation.model[,3],na.rm=TRUE,probs = c(0.025,0.975))
    print(a2) #intervalo de confianza quantil

}
