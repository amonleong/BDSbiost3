#5-4-2019
################################################################################
# funciones auxiliares
################################################################################

#monle.complexity.adjacency1(mm = as.matrix(adj3))

#example of adjacency matrix 10x10
#mm<- c(
#0, 0, 0, 0, 0, 0, 0, 0, 0,  0,
#0, 0, 0, 0, 0, 0, 0, 0, 0,  0,
#0, 0, 0, 0, 0, 0, 0, 0, 1,  0,
#0, 0, 0, 0, 0, 0, 0, 0, 0,  1,
#0, 0, 0, 0, 0, 0, 0, 0, 0,  0,
#0, 0, 0, 0, 0, 0, 0, 0, 0,  0,
#0, 0, 0, 0, 0, 0, 0, 0, 0,  0,
#0, 0, 0, 0, 0, 0, 0, 0, 0,  0,
#0, 0, 1, 0, 0, 0, 0, 0, 0,  0,
#0, 0, 0, 1, 0, 0, 0, 0, 0,  0)

#mm<- matrix(mm,nrow = 10,ncol = 10,byrow = T)
#mm
#funcion que calcula la compleidad de matriz de adyacencia
monle.complexity.adjacency1<- function(mm){
  #mm es la matriz de adyacencia
  #toni monleon 2018
  #funcion que determina el numero de grupos que hay en una matriz
  #de adyacencia y cuales son ycalcula un indice de compljidad basado en ellos

  #m is the adjacency matrix
  #compute cols with all=0, and cols with elements = 1
  #dimension of the matrix
  d<-dim(mm)[1]
  #non elected elements array
  non.selected.elements <- c() #dinamic array
  #selected elements array
  selected.elements <- c() #dinamic array
  j<-1
  k<-1
  for(i in 1:d){
    #i<-1
    #compare the vectors and fill the non selected elements
    if(all(mm[,i]==rep(0,d))) {
      non.selected.elements[j]<-i
      j<-j+1
    }

    #selected elements
    if(all(mm[,i]==rep(0,d))==F) {
      selected.elements[k]<-i
      k<-k+1}
    }

  selected.elements
  non.selected.elements #cols with all elements = 0 (no edges)


  #cmpute the communities
  d1<-length(selected.elements)
  commun <- matrix(NA,nrow = d1,ncol = d) #groups of elements
  f<-1
  for(i in 1:d1){
    #i<-1
    k<-1
    n.col.m<-selected.elements[i]
    #elementos del grupo:
    commun[i,k]<-n.col.m
    #recorrer filas
    for(j in 1:d){
      #j<-1
      if(mm[j,n.col.m]==1){
        k<-k+1
        commun[i,k]<-j
        #max number of columns in commun
        if (k>f){f<-k}
      }
    }

  }

  commun
  commun1<- commun[, colSums(is.na(commun)) != nrow(commun)]
  commun1


  #aumentar la dimension de la matriz commun1
  dfa<- dim(commun1)[1]
  matrixx <- matrix(NA, nrow = dfa, ncol = d)
  commun2 <- cbind(commun1, matrixx)


  #componer los grupos
  i<-1
  j <- 1
  senyal <- F
  repeat{
    commun2
    j
    i
    #eliminar las filas que son NA
    ind <- apply(commun2, 1, function(x) all(is.na(x)))
    commun2 <- commun2[ !ind, ]
    commun2

    #check de la dimension y condicion de parada
    d <- dim(commun2)[1]#num filas
    if(j==d & i<d){
      #print("uno uno")
      i<-i+1
      j <- i+1
      senyal <- T

    }
    i
    j
    if((i+1) >d){ break
      #print("un dos")
      } #para si ya no hay mas filas para analizar
    #if((j+1) >d){break}#si hay mas filas para analizar
    if((j+1) ==d & senyal == F){j<- j + 1
    #print("un tres")
    }#si hay mas filas para analizar
    if((j+1) < d & senyal == F){
      #aumentar contador
      #print("uno cuatro")
      j<- j + 1} #para si ya no hay mas filas para analizar
    i
    j
    #vector origen
    a<- commun2[i,]
    #quitar los NA
    a1 <- c(na.omit(commun2[i,]))
    a1



    #vector final
    #j <- i +1
    b<- commun2[j,]
    #quitar los NA
    b1 <- c(na.omit(commun2[j,]))
    b1

    #comparar a1 y b1
    logic.vector <- c(b1 %in% a1)
    logic.vector

    #contar el numero de diferencias
    n.coincidencias<- sum(logic.vector)
    n.coincidencias

    senyal <- F
    #en funcion del numero de coincidencias > 0
    if(n.coincidencias>0){ #hay mas de 1 coincidencia y lo otro elementos diferentes
      #delete the file of commun2
      #segun el tamany del grupo
      if(length(a1)>length(b1)){
        #componer el vector de elementos diferentes
        D1<-length(elementos.diferentes(a=a1,b=b1))
        commun2[i,1:D1]<- elementos.diferentes(a=a1,b=b1)
        #s=c(b1,a1)
        #vector.de.no.coincidencias <- dif(s)

        commun2[j,]<- NA
        i<-1
        j<-1
        #print("Uno")
      }
      if(length(b1)>length(a1)){

        #componer el vector de elementos diferentes
        D1<-length(elementos.diferentes(a=a1,b=b1))
        commun2[i,1:D1]<- elementos.diferentes(a=a1,b=b1)
        #s=c(b1,a1)
        #vector.de.no.coincidencias <- dif(s)

        commun2[i,]<- NA
        i<-1
        j<-1
        #print("Dos")
      }
      if(length(a1)==length(b1)){

        #componer el vector de elementos diferentes
        D1<-length(elementos.diferentes(a=a1,b=b1))
        commun2[i,1:D1]<- elementos.diferentes(a=a1,b=b1)
        #s=c(b1,a1)
        #vector.de.no.coincidencias <- dif(s)

        commun2[j,]<- NA
        i<-1
        j<-1
        #print("Tres")
      }
    }

    #vuelve a avanzar
  }

  ###################
  commun2
  j
  i


  non.selected.elements1<-non.selected.elements
  non.selected.elements1<-rep(1,length(non.selected.elements1))
  n.colus<-dim(commun2)[2]
  #compute vector of frequencies of edges
  vect.freqs<-apply(commun2, MARGIN = 1, function(x) n.colus-sum(is.na(x)))
  vect.freqs1<-subset(vect.freqs,vect.freqs!=0)
  vect.freqs2<-c(vect.freqs1,non.selected.elements1)
  #mean of the vector of edges
  mean.number.nodes<-mean(vect.freqs2)
  monle<-mean.number.nodes
  monle1<-mean(subset(vect.freqs2, vect.freqs2>1))
  return(list(vect.freqs2,monle,monle1))



}

#componer un vector, a partir de 2 vectores y de
#elementos diferentes
elementos.diferentes<-function(a,b){

  #ejemplo
  #a1<-c(1,3,5,6,7)
  #b1<-c(8,9,6,7,12)
  #funcion que compone un vector de elementos diferentes
  v.elements<- c(a,b)
  v.elements
  v.elements1<-c()
  d<-length(v.elements)
  d
  k<-1
  for(i in 1:d){
    #i<-2
    if(i==1){
      v.elements1[k] <- v.elements[i]
      k <- k+1
    }
    if(i>1){
      #comparar a1 y b1
      logic.vector <- c(v.elements[i] %in% v.elements1)
      logic.vector

      #contar el numero de diferencias
      n.coincidencias<- sum(logic.vector)
      n.coincidencias

      if(n.coincidencias==0){
        v.elements1[k] <- v.elements[i]
        k <- k+1
      }
    }
  }

  return(v.elements1)
}

