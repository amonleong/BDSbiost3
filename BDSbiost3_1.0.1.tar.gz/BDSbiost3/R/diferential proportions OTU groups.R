
#toni monleon (8-11-2017)

##################################################################################################
# Function to the differential analysis of proportions OTUs between groups samples
#################################################################################################
#' Metagenomic analysis of biodiversity
#'
#' Function to caculate differential poportions OTUs between samples groups
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param vector.labels parameter
#' @param alfa prob of error type I
#' @export


#####################################################################################
#####   dif.proportionsOTU.between.groups
#####################################################################################

#matriu matriz de frecuencias (OTUxsamples)
dif.propOTU.between.groups <- function(matriu, vector.labels, alfa=0.05) {
#calculo de la proporcion diferencial de OTUs para diferentes grupos de muestras del vector vector.labels

  ###############################################################
  #
  #  GO basado en proporciones diferenciales entre grupos
  #
  ###############################################################

  #######################diferencias entre proporciones de grupos ########################################################
  #Definir array:
  comb<-choose(length(levels(factor(vector.labels))),2)
  dif.groups.proportion <- matrix(NA, nrow=nrow(matriu),ncol=comb)#MATRIZ DE CONTINE LOS VALORES DE DIVERSIDAD
  pval.groups.proportion <- matrix(NA, nrow=nrow(matriu),ncol=comb)#MATRIZ DE CONTINE LOS VALORES DE DIVERSIDAD

  #dif.groups.proportion<- as.matrix(dif.groups.proportion)
  vector.noms.grups<- array("", dim=c(comb) )

  #pairs of groups
  vector.groups <- c(levels(factor(vector.labels))) #grupos de analisis
  num.groups <- length(levels(factor(vector.labels))) #numero de grupos de analisis


  for (l in 1: nrow(matriu)){ #para cada OTU
    k<-1 #orden del grupo
    for (i in 1:(num.groups-1)) { #SELECCIONAR GRUPO1
      for (j in (i+1):num.groups) { #SELECCIONAR EL SEGUNDO GRUPO
        #k<-1
        #i<-2
        #j<-i+1
        #l<-1
        group.of.analysis.selected.1<-matriu[,grep(vector.groups[i], colnames(matriu))]
        n1<-ncol(group.of.analysis.selected.1)
        group.of.analysis.selected.2<-matriu[,grep(vector.groups[j], colnames(matriu))]
        n2<-ncol(group.of.analysis.selected.2)
        #View(group.of.analysis.selected.1)
        #View(group.of.analysis.selected.2)

        #l<-1 indicador de la OTU
        #CALCULO DEL TEST DE PROPORCIONES
        grup1<-sum(group.of.analysis.selected.1[l,1:n1], na.rm = FALSE)
        grup2<-sum(group.of.analysis.selected.2[l,1:n2], na.rm = FALSE)
        total1<-sum(group.of.analysis.selected.1[,1:n1], na.rm = FALSE)
        total2<-sum(group.of.analysis.selected.2[,1:n2], na.rm = FALSE)
        res.test.proport<- prop.test( c(grup1, grup2) , c(total1, total2))

        pair.group.name <- (paste("Gp-", vector.groups[i], "-", vector.groups[j],sep = ""))
        vector.noms.grups[k] <- pair.group.name
        dif.proportions <- res.test.proport$estimate[1] -   res.test.proport$estimate[2]
        dif.groups.proportion[l,k]<-dif.proportions
        pval.groups.proportion[l,k]<-res.test.proport$p.value
        k <- k+1 #contador de grupos
      }
    }
  }


  #MATRIZ CON DIFERENCIA DE PROPORCIONES
  vector.noms.grups #GRUPOS
  dif.groups.proportion
  #MATRIZ CON P-VALOR
  pval.groups.proportion



  ############# transformarlo a un data frame ############################
  dif.groups.proportion1<- data.frame(dif.groups.proportion)
  #View(dif.groups.proportion1)
  pval.groups.proportion1<- data.frame(pval.groups.proportion)
  #View(pval.groups.proportion1)
  #data frame de diferencias de proporciones
  colnames(dif.groups.proportion1)<-vector.noms.grups
  rownames(dif.groups.proportion1)<-rownames(matriu)
  for (i in 1: ncol(dif.groups.proportion1)){
    #Grupos separados y ordenados de menor a mayor por proporcion diferencial
    #grup1
    #i=1
    dataframe1<-cbind(dif.groups.proportion1[i], pval.groups.proportion1[i], padj=p.adjust(as.matrix(pval.groups.proportion1[i]), "fdr"))
    dataframe1<-subset(dataframe1,padj<alfa)
    colnames(dataframe1)[2]<-"pval"
    dataframe1<-dataframe1[order(-dataframe1[1]),]
    View(dataframe1)
    #salvar en un fichero
    write.csv(dataframe1, file = paste(as.character(vector.noms.grups[i]),".csv",sep = "") )


    #hacer un grafico para el dataframe diferencia de proporciones
    #plot(rownames(dataframe1), dataframe1[1], type = "l", main = as.character(vector.noms.grups[i]))
    if(nrow(dataframe1)>0){
      #barplot(as.numeric(unlist(dataframe1[1])),
      #        main = as.character(vector.noms.grups[i]),
      #        xlab = "OTUs",
      #        ylab = "dif proporion",
      #        names.arg = rownames(dataframe1),
      #        col = "blue",
      #        horiz = F)
      library(plotrix)
      a<-dim(dataframe1)[1]
      p1<-as.numeric(abs(unlist(dataframe1[1])))[1:10]#proporciones ms expresadas +
      p2<-as.numeric((unlist(dataframe1[1])))[(a-9):a]#proporciones mas expresadas -
      label1 <-rownames(dataframe1)[1:10]
      label2<-rownames(dataframe1)[(a-9):a]
      label1.2<-paste0(label1, ":", label2)

      pyramid.plot(p1, abs(p2), labels =  label1.2, main = paste("Dif. proportion (n=10) ", as.character(vector.noms.grups[i])), unit= "\n",
                   space = 0.3, top.labels=c("+","OTU","-"))
      #library(ggplot2)
      #theme_set(theme_bw())

      #ggplot(dataframe1, aes(x=rownames(dataframe1), y=as.numeric(unlist(dataframe1[1])), label=rownames(dataframe1))) +
      #  geom_point(stat='identity', fill="black", size=6)  +
      #  geom_segment(aes(y = 0,
      #                   x = rownames(dataframe1),
      #                   yend = as.numeric(unlist(dataframe1[1])),
      #                   xend = rownames(dataframe1)),
      #               color = "blue") +
      #  geom_text(color="white", size=2) +
      #  labs(title="Differential proportion analysis - Lollipop chart",
      #       subtitle=as.character(vector.noms.grups[i])) +
      #  ylim(-1, 1) +
      #  coord_flip()

    }


  }


}

#este plot tambien estaria bien hacerlo
#Gráfico de pirámide
#pyramid.plot(p1, p2, labels =  years, top.labels=c(state, "years", state2),
#             main = paste("Evolution of",  var , "\n"), unit= "\n",
#             lxcol = heat.colors(n = 25, alpha = 0.5),
#             rxcol = heat.colors(n = 25, alpha = 0.5), space = 0.3, gap = 0.08*max(p1), show.values = TRUE,
#             ndig = 0, ppmar= c(2, 6, 2, 6))
