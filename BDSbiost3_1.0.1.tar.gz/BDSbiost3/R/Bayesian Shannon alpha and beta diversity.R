
####################################################################
# a mixed bayesian entropy index: diversity and phylogenetics - USING THE MIXTURE OF MULTINOMIALS
####################################################################
#' Bayesian.Entropy
#'
#' Function to caculate Rarefaction, Bayesian Richness and Sampling Effort index.
#' @param X data-set matrix with data containing the metagenomic frequencies (rows: OTUs, columns: samples)
#' @param nsites if TRUE the matrix is ordered
#' @param N are the type of statistical method to estimate Richness (Weibull or loess-logistic)
#' @param N1 is the type of species for the 1st group
#' @param N2 is the number of species for the 1st group
#' @return List of estimations: bayesian H', bayesian H1' and H2', SCV, CV
#' @export

Bayesian.Entropy <-function(X,nsites,N,N1,N2){
  #########################################################
  #bayesian model and estimations
  #########################################################


        ###
        ### BAYESIAN ANALYSIS IN WINBUGS
        ###
        ###
        ###
        # Save BUGS description of the model to working directory
        #sink("model.txt")
        cat("
            model {


            # Bayesian Shannon entropy (HB() ) with the credibility interval of 95%
            for(j in 1:nsites){
              h[j] <- p[j]*log(p[j]+0.001)
            }
            H<- -sum(h[1:nsites]) #Shannon index H()

            #beta-diversity
            # Bayesian Shannon entropy (HB() ) with the credibility interval of 95%
            for(j in 1:N1){
              h1[j] <- p[j]*log(p[j]+0.001)
            }
            H1<- -sum(h1[1:N1]) #Shannon index H()
            #beta-diversity
            # Bayesian Shannon entropy (HB() ) with the credibility interval of 95%
            for(j in (N1+1):(N1+N2)){
              h2[j] <- p[j]*log(p[j]+0.001)
            }
            H2<- -sum(h2[(N1+1):(N1+N2)]) #Shannon index H()

            #SI HAY DIFERENCIAS ENTRE ENTROPIA DE SUB-POBLACIONES
            HRATIO <- H1/H2
            #SER: COEFICIENTE DE VARIACION ENTRE SUB-POBLACIONES
              S[1]<- H1
              S[2]<- H2
            SER <- 100*sd(S[])/mean(S[])


            #Nespec <- rank(p[1:nsites], 2)


            #MODELO MULTINOMIAL-DIRITCHLET PARA LA ABUNDANCIA
            p0~dunif(0,1)
            #modelo de abundancia de especies
            X[1:nsites]~dmulti(p[1:nsites],N)
            #priori:
            p[1:nsites]~ddirch(alpha[])
            for(i in 1:nsites){alpha[i]<-1}

        }",fill=TRUE,file="model.txt")


        tony.data <- list(X=X,nsites=nsites,N=N,N1=N1,N2=N2)

        inits <- function(){
          list (p0=runif(1), p=rep(1/nsites,nsites)) #AQUI PODRIA PASAR PRIORS DIFERENTES
        }

        parameters <- c("p","X","H","HRATIO", "SER", "H1", "H2")
        nthin<-1
        nc<-2
        nb<-1000
        ni<-10000

        #library(R2WinBUGS)
        #library(R2OpenBUGS)
        #out <- bugs(data=tony.data, inits, parameters, "model.txt", n.thin=nthin,
        #             #bugs.dir="C:/WinBUGS14",
        #            DIC = FALSE,
        #            n.chains=nc, n.burnin=nb,n.iter=ni,debug=TRUE)
        library(R2jags) #JAGS
        #out <- as.mcmc.list(out)

        outJ <- jags(data=tony.data, inits, parameters, "model.txt", n.chains=nc,n.iter=ni,
                     n.burn=nb, n.thin=nthin)
        #plot(outJ, ask=TRUE)
        outJ #RESULTADOS OBTENIDOS EN EL JAGS


        ########################################
        #ESTIMAR EL P y TODOS SUS PARAMETROS, CI95%
        outJ$BUGSoutput$summary
        outJ$BUGSoutput$summary[4:(4+nsites-1),1:8] #LOS OTUS Y ABUNDANCIAS
        #probabilidades
        outJ$BUGSoutput$summary[(5+nsites):(4+2*nsites),1:8] #LOS OTUS Y ABUNDANCIAS

        print("ENTROPY/DIVERSITY ESTIMATION:")
        print("--------------------------------------------------------------")
        #calculo de la entropia bayesiana (HB) - Shannon
        outJ$BUGSoutput$summary[1,1:8]
        print("Results: H Shannon bayesian-------------------------------------")
        print(outJ$BUGSoutput$summary[1,1:8])

        print("Results: all other diversity indices")
        print(outJ$BUGSoutput$summary[1:5,1:8])

        #estimation of alpha-diversity (Shannon coefficient: entropy of Shannon)
        library(vegetarian)
        q1 <- 1
        #matriu.sel <- X
        aa<-H(t(as.data.frame(matriu)),lev="alpha", q=q1, boot=T, boot.arg=list(num.iter=1000))#species richness for entire data set
        aa #shannon

        #calculo de otra forma (esta es base e)
        #library(vegan)
        #aa<-diversity(as.data.frame(t(matriu)), "shannon",base = 2.718281828459045235360)
        #aa
        print("Clasical Shannon, Vegan")
        print(aa)

        #devuelve lista de valores
        my_list <- list("ShannonClasical" = aa, "ShannonBayes" = outJ$BUGSoutput$summary[1:5,1:8], "OtherBayes"=outJ$BUGSoutput$summary[1:5,1:8])
        return(my_list)
}
