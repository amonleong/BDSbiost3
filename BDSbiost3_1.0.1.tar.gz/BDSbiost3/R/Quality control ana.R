
#############################################################################3
# QUALITY CONTROL IN METAGENOMICS: QUALITY CONTROL USING LCD
##############################################################################

# Toni Monleon. Biost3. 2-2018


#############################################################
# Functions to sample size and rarefaction in metagenomics
#############################################################

#' MetagenSample.size.H
#'
#' Function to caculate Rarefaction, Bayesian Richness and Sampling Effort index.
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @return Lis of estimations: Richness, 95% sampling Effort (sample size), Rarefaction
#' @export

################################################################################
#1-funcion para el calculo de  curva de rarefaccion (bayesiano MCMC) en metagenomics y sample size
################################################################################
QualityMatrixAnna <- function(matriu) {
      #probabilidad de corte para decidir OTU
      #cuttoff

      library(R2jags) #JAGS
      library(vegan)
      library(proto)
      library(nls2)
      library(ggtern)
      library(LearnBayes)
      library(qcc) #quality control




  nsimulac<- ncol(matriu)
  nsites <- nrow(matriu)

    #Estimacion de la beta-diversidad segun Legendre y Caceres (2013)
    #definir donde se acu,ulan los resultados
    s_ij <- array(0, dim=c(nsites, nsimulac))
    for(i in 1:nsites)
    {
      #i<-1
      for(j in 1:nsimulac)
      {
        #j<-1
        s_ij[i,j]<-(matriu[i,j]- mean(matriu[i,]))^2
      }
    }

    #BD_TOTAL (LEGENDRE Y CACERES, PAG 953, 2013)
    SS_TOTAL<- 0
    for(i in 1:nsites)
    {
      #i<-1
      for(j in 1:nsimulac)
      {
        #j<-1
        SS_TOTAL <-  s_ij[i,j] + SS_TOTAL
      }
    }
    BD_TOTAL <- SS_TOTAL/ (nsimulac-1)

    #LCBD: LOCAL CONTRIBUTION TO BETA-DIVERSITY (LEGENDRE AND CACERES, 2013)
    SS_i <- array(0, dim=c(nsimulac))
    for(i in 1:nsimulac)
    {
      #i<-1
      for(j in 1:nsites)
      {
        #j<-1
        SS_i[i] <-  s_ij[j,i] + SS_i[i]
      }
    }
    LCBD <- round(100*(SS_i/SS_TOTAL),2)
    #library(qcc)

    print("-----------------------------------")
    print("-----------------------------------")

    print("BD_TOTAL = VAR(Y) = BETA-DIVERSITY SAMPLES")
    print(round(BD_TOTAL,2))

    print("LOCAL CONTRIBUTION TO BETA-DIVERSITY")
    print(LCBD)

    print("-----------------------------------")
    print("-----------------------------------")

    #grafico de control de calidad de la LCBD
    #par(mfrow=c(1,1))
    #CONTROL DE CALIDAD DE LAS MUESTRAS (REPETICIONES) A FIND E VER BETA-DIVERSITY Y LAS CONTRIBUCIONES, VER SI ALGUNA MUESTRA MAL
    dev.new(width=5, height=10)
    x <- qcc(LCBD, type = "xbar.one", title = "QUALITY CONTROL: SAMPLE CONTRIBUTION TO BETA-DIVERSITY (LCBD and Var(Y))")

    text(2, 2, "BD_TOTAL / Var(Y)", cex = 1, col="blue")
    text(6, 2, round(BD_TOTAL,2), cex = 1, col="blue")
    #text(7, 1, LCBD, cex = 1, col="blue")

}
