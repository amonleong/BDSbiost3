#############################################################################3
# SAMPLE SIZE IN METAGENOMICS: DETERMINATION OF RICHNESS AND EFFORT OF SAMPLING
##############################################################################

# Toni Monleon. Biost3. 8-2017


#############################################################
# Functions to sample size and rarefaction in metagenomics
#############################################################

#' MetagenSample.size.H
#'
#' Function to caculate Rarefaction, Bayesian Richness and Sampling Effort index.
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param quart.cut if TRUE the matrix is ordered
#' @param type are the type of statistical method to estimate Richness (Weibull or loess-logistic)
#' @param model.probability is the type of species probabilities
#' @param zero delete all values without numbers
#' @return Lis of estimations: Richness, 95% sampling Effort (sample size), Rarefaction
#' @export

################################################################################
#1-funcion para el calculo de  curva de rarefaccion (bayesiano MCMC) en metagenomics y sample size
################################################################################
MetagenSample.size.H1 <- function(matriu, quart.cut=0.3, type=T,model.probability=1, zero=T) {
  #probabilidad de corte para decidir OTU
  #cuttoff

  library(R2jags) #JAGS
  library(vegan)
  library(proto)
  library(nls2)
  library(ggtern)
  library(LearnBayes)
  library(qcc) #quality control

  options(show.error.messages = F)
  options(warn = -1)

  nsimulac<- ncol(matriu)
  nsites <- nrow(matriu)


  #MODELO BASICO PARA LA PREDICCION DEL NUMERO DE OTUS-MAXIMO Y DEL ESFUERO DE MUESTREO (SAMPLING EFFORT)
  #remove 0 if all the columns are 0 or not
  if(zero==T ){ #solo funciona si no hay filas con 0 OTUs y con mas de 3 muestras
    matriu<-matriu[which(rowSums(matriu) > 0),]
    nsimulac<- ncol(matriu)
    nsites <- nrow(matriu)
  }


  #definir donde se acumulan los resultados
  is.OTU.total <- array(0, dim=c(nsites))
  sum.OTU.sample <- array(0, dim=c(nsimulac))
  is.OTU <- array(0, dim=c(nsites, nsimulac))

  #print("UNO")
  #para cada sample
  for(k in 1:nsimulac){

    print("dos")
   #k<-1
    X<- matriu[,k]
    N<- sum(matriu[,k])
      ###
      ### BAYESIAN ANALYSIS IN WINBUGS
      ###
      ###
      ###
      # Save BUGS description of the model to working directory
      #sink("model.txt")
      cat("
          model {


          # Bayesian Shannon entropy (HB() ) with the credibility interval of 95%
          #for(j in 1:nsites){
          #  h[j] <- p[j]*log(p[j]+0.1)
          #}
          #H<- -sum(h[1:nsites]) #Shannon index H()

          #beta-diversity
          # Bayesian Shannon entropy (HB() ) with the credibility interval of 95%
          #for(j in 1:N1){
          #  h1[j] <- p[j]*log(p[j]+0.1)
          #}
          #H1<- -sum(h1[1:N1]) #Shannon index H()
          #beta-diversity
          # Bayesian Shannon entropy (HB() ) with the credibility interval of 95%
          #for(j in (N1+1):(N1+N2)){
          #  h2[j] <- p[j]*log(p[j]+0.1)
          #}
          #H2<- -sum(h2[(N1+1):(N1+N2)]) #Shannon index H()

          #SI HAY DIFERENCIAS ENTRE ENTROPIA DE SUB-POBLACIONES
          #HRATIO <- H1/H2
          #SER: COEFICIENTE DE VARIACION ENTRE SUB-POBLACIONES
          #  S[1]<- H1
          #  S[2]<- H2
          #SER <- 100*sd(S[])/mean(S[])


          #Nespec <- rank(p[1:nsites], 2)


          #MODELO MULTINOMIAL-DIRITCHLET PARA LA ABUNDANCIA
          p0~dunif(0,1)
          #modelo de abundancia de especies
          X[1:nsites]~dmulti(p[1:nsites],N)
          #priori:
          p[1:nsites]~ddirch(alpha[])
          for(i in 1:nsites){alpha[i]<-1}

      }",fill=TRUE,file="model.txt")


      print("tres")

      #tony.data <- list(X=X,nsites=nsites,N=N,N1=N1,N2=N2)
      tony.data <- list(X=X,nsites=nsites,N=N)

      #vector de probabilidades: diferentes opciones
      pp <- array(0, dim=c(nsites))
      #todas las probabilidades equitativas
      if(model.probability==1){
        #for(i in 1:nsites){pp[i]<-1/nsites}
        inits <- function(){
          list(p0=runif(1), p=rep(1/nsites,nsites)) #AQUI PODRIA PASAR PRIORS DIFERENTES
        }
      }
      #probabilidades son estimadas como la frecuencia relativa
      if(model.probability==2){
        for(i in 1:nsites){pp[i]<-rowSums(matriu)[i]/sum(rowSums (matriu))}
        inits <- function(){
          list(p0=runif(1), p=as.numeric(pp)) #AQUI PODRIA PASAR PRIORS DIFERENTES
        }
      }
      print("CUATRO")
      #inits <- function(){
      #  list (p0=runif(1), p=rep(1/nsites,nsites)) #AQUI PODRIA PASAR PRIORS DIFERENTES
      #}



      #parameters <- c("p","X","H","HRATIO", "SER")
      parameters <- c("p","X")
      nthin<-1
      nc<-2
      nb<-1000
      ni<-10000

      print("CINCO")

      #library(R2WinBUGS)
      #library(R2OpenBUGS)
      #out <- bugs(data=tony.data, inits, parameters, "model.txt", n.thin=nthin,
      #             #bugs.dir="C:/WinBUGS14",
      #            DIC = FALSE,
      #            n.chains=nc, n.burnin=nb,n.iter=ni,debug=TRUE)

      #out <- as.mcmc.list(out)

      print("SEIS")

      outJ <- jags(data=tony.data, inits, parameters, "model.txt", n.chains=nc,n.iter=ni,
                   n.burn=nb, n.thin=nthin)
      print("SIETE")
      #plot(outJ, ask=TRUE)
      #outJ #RESULTADOS OBTENIDOS EN EL JAGS


      ########################################
      #ESTIMAR EL P y TODOS SUS PARAMETROS, CI95%
      #outJ$BUGSoutput$summary
      #outJ$BUGSoutput$summary[4:(4+nsites-1),1:8] #LOS OTUS Y ABUNDANCIAS
      #outJ$BUGSoutput$summary[(5+nsites):(4+2*nsites),1:8] #LOS OTUS Y ABUNDANCIAS



      #incorporar a la matriz: presencia-ausencia de especies
      for(i in 1:nsites)
        {
        #i<-2
        cuttoff<-quantile(outJ$BUGSoutput$summary[(nsites+2):((2*nsites)+1),3],quart.cut)
        if(outJ$BUGSoutput$summary[nsites+1+i,3] > cuttoff) {
          is.OTU[i,k]<-1
        }

      }


  }

  is.OTU #matriz de presencia ausencia de especies

  #matriz de resultados de otus  para estimar rarefaccion bayesiana
  #calcula la frecuencia acumulada de especies en el vector
  #sum.OTU.sample
  for(i in 1:nsimulac)
    {
      for(j in 1:nsites)
      {
        if(is.OTU[j,i] ==1) {
          is.OTU.total[j]<-1
        }
        sum.OTU.sample[i]<-sum(is.OTU.total)
      }
    }
  is.OTU #matrices de otus y simulaciones
  sum.OTU.sample #MATRIZ DE SIMULACIONES CON PRESENCIA DE OTUs
  final.otu.rarefaccion <- data.frame(rep(0:nsimulac),c(0,sum.OTU.sample) )
  #plot(final.otu.rarefaccion) #curva de rarefaccion



  ###################################################################################
  # CLASICAL AND BAYESIAN RAREFACCCION: ESTIMATION OF SAMPLE SIZE / NUMBER OF SAMPLES
  ###################################################################################

  ################################
  #analisis de rarefaccion clasica
  ################################
  #par(mfrow=c(2,2))


  h <- hist(rowSums(matriu), plot=F, breaks=50)
  h$counts=h$counts/sum(h$counts)

  plot(h, main="Histogram for abundance", xlab="Abundance", ylab = "rel. frequency",
       col="green")
  counts <- table(rowSums(matriu))[1]
  a<-paste("OTUS with Ab.=0:", round(100*(counts/nsites),1),"%")
  text(max(h$breaks)/2, max(h$counts)/2, a, cex = 1, col= "red")
  b<-paste("matrix files:", nsites)
  text(max(h$breaks)/2, 0.75*(max(h$counts)/2), b, cex = 1)


  #rarefaccion clasica - specaccum
  #library(vegan)
  #asd <- as.data.frame(matriu)
  sp2 <- specaccum(t(matriu), "rarefaction")#"collector", "random", "exact", "rarefaction", "coleman"
  print("Classical rarefaccion")
  print(sp2)
  #summary(sp2)
  plot(sp2, ci.type="poly", col="blue", lwd=2, ci.lty=0, ci.col="lightblue", main="Classical rarefaccion", sub="specaccum", xlab="samples", ylab="richness(OTUs)")
  #boxplot(sp2, col="yellow", add=TRUE, pch="+")
  b<-max(data.frame(sp2[4]))/2
  text(nsimulac/1.7, b, "Estimated Richness", cex = 1)
  text(nsimulac/2, 0.75*b, b*2, cex = 1, col="red")
  #text(nsimulac/2, 0.5*b, BD_TOTAL, cex = 1, col="blue")
  #text(nsimulac/1.7, 0.5*b, LCBD, cex = 1, col="blue")


  if (nsimulac > 3) { #solo si hay mas de 3 muestras
    ######### uso de otro metodo de calculo de rarefaccion de:
    #http://cc.oulu.fi/~jarioksa/softhelp/vegan/html/specpool.html

    print("----------- poolaccum ------------------------")
    library(vegan)
    tmatriu <- t(matriu)
    pool <- poolaccum(tmatriu, permutations = 999, minsize = 3)
    print(summary(pool))
    #dev.new(width=10, height=10)
    png(filename="richness.png")
      plot(pool, main="richness estimation using poolaccum of vegan")
    dev.off()
    print("----directorio aqui----")
    print(getwd())

    #estimaciones para las muestras
    print("Richness estimation Chao, bootstrap et al")
    print(estimateR(tmatriu))
 }



  ###################################################################
  #BAYESIAN SAMPLE SIZE: RICHNESS / EFFORT TO REACH 95% RICHNESS
  ###################################################################
  #c?lculo del n? de especies (OTU): rarefaccion (CI) y esfuerzo
  colnames(final.otu.rarefaccion)[1]<- "X1"
  colnames(final.otu.rarefaccion)[2]<- "X2"
  #matriu<-final.otu.rarefaccion

  if (type==F) {
      #funcion parametrica de saturaci?n Weibull
    #library(proto)
    #library(nls2)
    print("SAMPLE SIZE:")
    print("--------------------------------------------------------------")
    plot.Weibull.CI(final.otu.rarefaccion, noptima=F, 0, 0, 0, "Num OTU",esfuerzo.actual=nsimulac)
  }

  #otro tipo de prediccion LOESS
  #no satura el modelo y hay que hacer los c?lculos con splines
  if (type==T) {
    #if (class(model.SSweibull) != "nls") {
    options(show.error.messages = T)

    X1<-final.otu.rarefaccion$X1
    X2<-final.otu.rarefaccion$X2
    #X1=c(0,1,2,3,4,5,6,7,8,9)
    #X2=c(0,3,5,8,12,12,13,13,13,13)
    #X1.fin<-nsimulac
    #plot the bayesian rarefaction
    plx<-suppressWarnings(loess(X2 ~ X1, control = loess.control(surface =  "direct"), se=T))
    aaa<- suppressWarnings(predict(plx, data.frame(X1 = c(X1)), se = TRUE))
    #aaa<- predict(plx, data.frame(X1 = c(X1, X1.fin)), se = TRUE)

    #text(nsimulac/2,nsites/3, a, cex = .9, col= "red")
    a2<-round(max(aaa$fit) + 1.96* aaa$residual.scale,1)
    a1<-round(max(aaa$fit) - 1.96* aaa$residual.scale,1)
    aaa1<-paste("BR95%:", round(max(aaa$fit),1),"(",a1,",",a2,")")
    plot( X1, X2,main="Bayesian rarefaction", sub = aaa1, ylim=c(0,1.1*nsites),
          xlab = "Samples", ylab="OTUs")
    x.1.1 <- c(X1)
    lines(x.1.1, aaa$fit, col = "red")
    lines(x.1.1,aaa$fit - qt(0.975,aaa$df)*aaa$se, lty=2, col = "red")
    lines(x.1.1,aaa$fit + qt(0.975,aaa$df)*aaa$se, lty=2, col = "red")


############################################################################################################
    #funcion Michaelis y Menten para predecir esfuerzo
    #DEFINO UN RANGO FUTURO DE PREDICCION
    range<-c(X1[2:nsimulac+1], max(X1[2:nsimulac+1]), nsimulac+5, nsimulac+10)

    #COMPROBAR SI SATURA O NO:
    #metodo para predecir futuro numero de especies polinomico:   POLINOMIO3
    ddd <- data.frame(X1, X2)
    #myFit1 <- lm(X2 ~ poly(X1,2),data=ddd)
    #summary(myFit1)
    #nsimulac<-9
    #pred1 <- data.frame('X1'=range)
    #newdata <- predict(myFit1, pred1)
    #max.predict.poly3<-max(newdata)
    #METODO FUNCION Michaelis-Menten equation
    #FROM: https://datascienceplus.com/first-steps-with-non-linear-regression-in-r/
    #X1=c(0,1,2,3,4,5,6,7,8,9,10)
    #X2=c(0,3,5,8,12,12,13,13,13,13,13)


    #myFit1<-suppressWarnings(nls(X2~a*X1/(b+X1),data=ddd,start=c(a=max(aaa$fit),b=10)))

    options(show.error.messages = T)
    out3 <- try(myFit1<-suppressWarnings(nls(X2~a*X1/(b+X1),data=ddd,start=c(a=max(aaa$fit),b=10)))) #test de LSD
    if (substr(out3[1],1,5)!="Error"){ #ERROR CON LA ESTIMACION DE mm
        #el valor a es la asindota

          #funcion logistica y = a*X/(b+X)
          #coef(myFit1) #coeficientes a y b de la funcion
          #inversa de la logistica X= yb/(a-y)  str(myFit1 )
          #get some estimation of goodness of fit
          #cor(X2,predict(myFit1))
          #plot
          #plot(X1,X2)
          #lines(X1,predict(myFit1),lty=2,col="red",lwd=3)
          pred1 <- data.frame('X1'=range)
          newdata <- predict(myFit1, pred1)
          #max.predict.poly3<-max(newdata)#maximo con funcion logistica
          max.predict.poly3<-as.numeric(coef(myFit1)[1]) #es l as?ndota

          #calculo de los esfuerzos con la funcion logistica -----------------
          #esfuerzo 90%
          #calculo el 90% maximo
          y.i <- 0.90*max.predict.poly3
          x.para.maximo.90.NS<- y.i*coef(myFit1)[2]/(coef(myFit1)[1]-y.i)

          #calculo el 95% maximo
          y.i <- 0.95*max.predict.poly3
          x.para.maximo.95.NS<- y.i*coef(myFit1)[2]/(coef(myFit1)[1]-y.i)


          #calculo el 95% maximo
          y.i <- 0.99*max.predict.poly3
          x.para.maximo.99.NS<- y.i*coef(myFit1)[2]/(coef(myFit1)[1]-y.i)



          #METODO loess:
          #saturation.curve(model.loess=plx,range=c(0,1,2,3,4,5,6,7,8,9,20))
          #newdata.1<-suppressWarnings(saturation.curve(model.loess=plx,range))
          #max.predict.LOESS <- max(newdata.1)
          #maximo entre loess y
          MAX.LOESS.POLY3<- max(max.predict.poly3, max(aaa$fit))


          #RESULTADOS DE NUMERO DE ESPECIES ESTIMADO
          #maxim <- max(aaa$fit)
          #print("-----------------------------------")
          #print("OTUS estimated(saturation SATURA !!!!)")
          #print(maxim)
          #print("Maximo numero de especies: CUI")
          #print(maxim + 1.96* aaa$residual.scale)
          #print("Maximo numero de especies: CLI")
          #print(maxim - 1.96* aaa$residual.scale)
          #print("-----------------------------------")

#aqui
            plot(c(X1,range),c(X2,newdata), ylim=c(0,1.2*nsites),xlab="samples" ,ylab="Future OTUs(red)",
                 main="OTU ACCUMULATION CURVE", sub="Red=real samples, Blue=future samples")
            lines(X1,X2, col="red")
            lines(range,newdata, col="blue")
            #numero de muestras actual
            abline(v=nsimulac, col="green", lwd=2, lty=3)

            #REPRESENTA LOS VALORES DE LA CURVA DE RAREFACCION DE ESPECIES DE CHAO
            if(zero==T){
              #matriu<-matriu[which(rowSums(matriu) > 0),]
              #representar el chao
              #res1<-poolaccum(t(matriu))
              #lines(c(0,res1$N),c(0,res1$boot[,1]),col="green", lwd=3, lty=2)
            }
            #TEXT CON SI DETERMINA QUE EL MODELO SATURA O NO
            #un1<-saturation.curve(matriu=matriu )
            #text(12,0, un1[1], col="red")

            #andreu paytuvi-Sequence biotec 2017-nov
            #save data frame: OTU.ACCUMULATION.CURVE <- data.frame(samples=c(X1,range),predicted.OTU=c(X2,newdata))
            #SI EL MODELO NO SATURA QUE LO INDIQUE
            #esfuerzo para predicciones futuras con funcion logistica
          if (MAX.LOESS.POLY3> nsites){
            print("LOGISTIC NON SATURATIVE MODEL: NECESARIO MAS SAMPLES")
            print("MAXIMO NUMERO ESPECIES PREDICHO (POLY3,LOESS) FUTURO:")
            print(MAX.LOESS.POLY3)
          }

          #num.row <- length(X1) #num of rows data-frame
          #toni-aquiii 30-11-2016
          #i<-1
          #while(aaa$fit[i]<maxim ){
          #  punt_t <- X1[i]
          #  i <- i + 1
          #}

        #CALCULO DE LOS ESFUERZOS DE MUESTREO EN SATURACION Y CON FUTUROS ESFUERZOS
        #calculo el 95% maximo
        maxim <- max(aaa$fit)

        #calculo el 90% maximo
        y.i <- 0.90*maxim
        x.para.maximo.90<- y.i*coef(myFit1)[2]/(coef(myFit1)[1]-y.i)

        #calculo el 95% maximo
        y.i <- 0.95*maxim
        x.para.maximo.95<- y.i*coef(myFit1)[2]/(coef(myFit1)[1]-y.i)
        text(x.para.maximo.95,10,round(x.para.maximo.95,1))
        abline(v = x.para.maximo.95, col= "red",lty=2)
        text(x.para.maximo.95.NS,10,round(x.para.maximo.95.NS,1))
        abline(v = x.para.maximo.95.NS, col= "blue",lty=2)
        text(nsimulac,nsites/2,"95% effort(sample size)")
        abline(h=max.predict.poly3,col="blue",lty=2)
        abline(h=max(aaa$fit),col="red",lty=2)
        text(nsimulac,max.predict.poly3,round(max.predict.poly3,1),col="blue")
        text(nsimulac/4,max(aaa$fit),round(max(aaa$fit),1),col="red")
        #calculo el 95% maximo
        y.i <- 0.99*maxim
        x.para.maximo.99<- y.i*coef(myFit1)[2]/(coef(myFit1)[1]-y.i)

        print("-----------------------------------")
        print("-----------------------------------")
        print("OTUs estimated (maximum)->> RICHNESS")
        print(maxim)
        print("Maximo numero de especies: UI")
        print(maxim + 1.96* aaa$residual.scale)
        print("Maximo numero de especies: LI")
        print(maxim - 1.96* aaa$residual.scale)
        print("-----------------------------------")
        print("-----------------------------------")
        print("Saturation: EFFORT TO REACH MAXIMUM OTUs (LOESS,LOGISTIC MODEL) CASE")
        print("-----------------------------------")
        print("effort to reach a time of the 90% of the maximum of the cumulative.survival curve")
        print(as.numeric(x.para.maximo.90))
        print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve")
        print(as.numeric(x.para.maximo.95))
        print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
        print(as.numeric(x.para.maximo.99))
        print("-----------------------------------")
        print("-----------------------------------")
        print("max number of OTUs expected in non saturation:")
        print(MAX.LOESS.POLY3)
        print("NON Saturation: EFFORT TO REACH MAXIMUM OTUs (LOESS,LOGISTIC MODEL) CASE")
        print(as.numeric(x.para.maximo.90.NS))
        print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve")
        print(as.numeric(x.para.maximo.95.NS))
        print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
        print(as.numeric(x.para.maximo.99.NS))

        diferencia.predicts <-100*abs(x.para.maximo.95.NS - x.para.maximo.95)/x.para.maximo.95
        print("Diferencia % entre predicciones de sample size to reach 95%")
        print(diferencia.predicts)

        print("###############datos curva#####################")
        #print(c(X1,range),c(X2,newdata))
        #salvar data-frame con datos curva esfuerzo y santuracion
        print("Se salvan en data.frame OTU.ACCUMULATION.CURVE")
        OTU.ACCUMULATION.CURVE <- data.frame(samples=c(X1,range),predicted.OTU=c(X2,newdata),
        x.para.maximo.90=as.numeric(x.para.maximo.90),
        x.para.maximo.95=as.numeric(x.para.maximo.95),
        x.para.maximo.99=as.numeric(x.para.maximo.99),
        x.para.maximo.90.NS=as.numeric(x.para.maximo.90.NS),
        x.para.maximo.95.NS=as.numeric(x.para.maximo.95.NS),
        x.para.maximo.99.NS=as.numeric(x.para.maximo.99.NS),
        max.saturative.model =max(aaa$fit), #red line horizontal
        max.nonsaturative.model =max.predict.poly3, #blue line horizontal
        diferencia.predicts=diferencia.predicts,
        samples=nsimulac)
        write.csv(OTU.ACCUMULATION.CURVE, file = "OTU.ACCUMULATION.CURVE.csv")

        print(OTU.ACCUMULATION.CURVE)
        print("###################################################")



    }

    #}
  }




  #print("ENTROPY/DIVERSITY ESTIMATION:")
  #print("--------------------------------------------------------------")
  #calculo de la entropia bayesiana (HB) - Shannon
  #outJ$BUGSoutput$summary[1,1:8]
  #print("Results: H Shannon bayesian-------------------------------------")
  #print(outJ$BUGSoutput$summary[1,1:8])

  # calculo de la alfa-diversitat de Shannon (cl?sica):

  #library(vegetarian)
  #q1 <- 1
  #matriu.sel <- X
  #aa<-H(t(as.data.frame(matriu)),lev="alpha", q=q1, boot=T, boot.arg=list(num.iter=1000))#species richness for entire data set
  #aa #shannon

  #calculo de otra forma (esta es base e)
  #library(vegan)
  #aa<-diversity(as.data.frame(t(matriu)), "shannon",base = 2.718281828459045235360)
  #print("-----------------------------------")
  #print("Results: H Shannon -----------------------------------")
  #print(aa)





  #devuelve lista de valores
  #if (substr(out3[1],1,5)!="Error"){
  #  my_list <- list("Richness1" = maxim, "Richness2" = MAX.LOESS.POLY3, effort95_1=as.numeric(x.para.maximo.95), effort95_2=as.numeric(x.para.maximo.95.NS), BD_TOTAL1=round(BD_TOTAL,2), LCBD1=LCBD)
  #    }
  #if (substr(out3[1],1,5)!="Error"){
  #  my_list <- list("Richness1" = maxim, "Richness2" = NA, effort95_1=NA, effort95_2=NA, BD_TOTAL1=round(BD_TOTAL,2), LCBD1=LCBD)
  #}
  return(OTU.ACCUMULATION.CURVE) #DEVUELVE DATA FRAME DE TODO
  options(show.error.messages = T)
}





####################################################################################################################
# 2-Funcion inverse.function() -LOESS: calculate loess the inverse function of a spline
####################################################################################################################
inverse.function <- function(data.x.y, y.i, punt_t){

  #options( warn = -1 )

  #calculate the inverse function of a spline

  #punt_t es el punto en el cual se encuentra el maximo de la funci?n fitted
  # y.i es el maximo

  #y.i <- 6.5
  #data.x.y <- data.frame(x=c(1,2,3,4,5, 6, 7), y=c(2,4,6,8,10, 12, 14))
  #attach(data.x.y)
  data.x.y <- subset(data.x.y, x < punt_t)
  #attach(data.x.y)

  plx<-loess(x ~ y, control = loess.control(surface =  "direct",degree = 3), data=data.x.y)
  aaa<- predict(plx, data.frame(y = y.i), se = TRUE)
  aaa$fit
  LCI<-aaa$fit - qt(0.975,aaa$df)*aaa$se
  UCI<-aaa$fit + qt(0.975,aaa$df)*aaa$se


  return(c(aaa$fit, LCI,  UCI))
  #detach(data.x.y)
}




####################################################################################################################
# 3-funcion saturation.curve() - ANALISIS GRaFICO DE LA SATURACION DE UNA CURVA DE RAREFACCION: CURVA SATURA/ NO SATURA
####################################################################################################################
#model.loess=plx,range=c(0,1,2,3,4,5,6,7,8,9,20)
#aasd<-saturation.curve(matriu)
saturation.curve <- function(matriu, a1, a2){

  options(show.error.messages = T)


  #model.loess=plx,range
  #ejemplo de prueba
  #X1=c(0,1,2,3)
  #X2=c(0, 70, 92, 96)
  #plot(X1,X2)

  #options(warn=0)
  #(PASO 1.2) Local Polynomial Regression Fitting (LPR):  CALCULAR LA ASINDOTA Y ver si la curva satura o no satura entre 1 a 15M
  #se hace una regresi?n para ver los valores
  #x.1<- range  #c(5, 10, 15)

  #regression loess del chao
  #res1<-poolaccum(t(matriu))
  #plot(c(0,res1$N),c(0,res1$chao[,1]))
  #data.x.y <- data.frame(x=res1$N, y=res1$boot[,1])
  #ksmooth.pred<-ksmooth(data.x.y$x, data.x.y$y, "normal", bandwidth = 4)
  #smoothingSpline1 = smooth.spline(ksmooth.log$x, ksmooth.log$y)
  #aaa.me<-predict(smoothingSpline1, data.frame(xx = seq(0, max(xx)+5, by = 0.5)) )
  #res <- lm(as.matrix(aaa.me$y)~as.matrix(aaa.me$x))
  #    summary(res)
  #    res$coefficients #si la pendiente es negativa -> SATURACION / si la pendiente es >1-> NO SATURACION
  #    Asym1.sp.pendiente <- res$coefficients[2] #R2 para pendiente de la asindota segun la funcion polinomica splines
  if(a2<=a1){
  #    if (res$coefficients[2]<=1){ #no saturan SI PENDIENTE DE CURVA > 1
        #(PASO 1.3) Local Polynomial Regression Fitting (LPR):  CALCULO EL MAXIMO DE GENES PARA LOS QUE NO SATURAN
        #si no tiene asindota antes de los 15 millones
        #x.1<-c(1, 5, 10, 15, 17, 19, 20, 21, 22, 23, 24, 25, 30, 33, 35, 40, 42, 45, 50, 55, 75, 100, 125,200)
        #ass1 <- predict(model.loess, data.frame(x.1), se = TRUE) #ASINDOTA PARA LAS CURVAS QUE NO SATURAN
        #y.11<-ass1$fit
        #res1 <- lm(y.11~x.1)
        #summary(res1)
        #ass1$fit
        #res1$coefficients[2]
        #Asym1.sp <- max(ass1$fit)

        #print("La curva no satura: HAY QUE HACER MAS SAMPLES")
        #print("maximo numero de OTU a 2 veces el numero de samples:")
        #print(max(ass$fit))
        Asym1.sp.pendiente.label <-"SATURATIVE-MODEL"
      } else {
        #si que se saturan
        #Asym1.sp <- max(ass$fit) #asindota segun la funcion polinomica splines
        #print("La curva satura: NO HAY QUE HACER MAS SAMPLES")
        Asym1.sp.pendiente.label <-"NON-SATURATIVE-MODEL"
      }
  #}



  #print(Asym1.sp)

  return(list(Asym1.sp.pendiente.label,Asym1.sp.pendiente ))

      options (show.error.messages = F)
}







##########################################################################
# 4-funcion plot.Weibull.CI() - ANALISIS GRaFICO DEL TAMANO MUESTRAL EN METAGENOMICA CON FUNCION DE CRECIMIENTO SATURATIVA WEIBULL
###########################################################################

#matriu<-data.frame(matyy[2])
#representar grafica weibull para la situacion concreta
#funci?n search.OTU.N()
plot.Weibull.CI <- function(matriu, noptima=F, esfuerzo90=0, esfuerzo95=0, esfuerzo99=0, etiq="% discrim", esfuerzo.actual=0) {

  #options(warn=0)

  #par?metros: matriz de los datos del remuestreo, esfuerzos del 90 al 99% de los otus

  #defino funciones previas
  ##################################################################################
  # funcion as.lm.nls() para intervalo de prediccion 95% Weibull o de cualquier nls
  # funcion interna para los IC9%% Weibull
  ##################################################################################
  as.lm <- function(object, ...) UseMethod("as.lm")

  as.lm.nls <- function(object, ...) {
    if (!inherits(object, "nls")) {
      w <- paste("expected object of class nls but got object of class:",
                 paste(class(object), collapse = " "))
      warning(w)
    }

    gradient <- object$m$gradient()
    if (is.null(colnames(gradient))) {
      colnames(gradient) <- names(object$m$getPars())
    }

    response.name <- if (length(formula(object)) == 2) "0" else
      as.character(formula(object)[[2]])

    lhs <- object$m$lhs()
    L <- data.frame(lhs, gradient)
    names(L)[1] <- response.name

    fo <- sprintf("%s ~ %s - 1", response.name,
                  paste(colnames(gradient), collapse = "+"))
    fo <- as.formula(fo, env = as.proto.list(L))

    do.call("lm", list(fo, offset = substitute(fitted(object))))

  }



  #mODELO WEIBULL DE 4 PARAMETROS
  mat.res.weib <- matriu #data.frame de los resultados
  #GRAFICA DE TODOS LOS REMUESTREOS:
  if (noptima==F){ #representacion experimento
    plot(mat.res.weib$X1, mat.res.weib$X2, col="blue", xlab="% OTU", ylab=etiq, xlim=c(0,100))
  }
  if (noptima==T){ #calculo tama?o muestral

    #crear el data frame de los untos de n encontrados:

    #mat.res.weib

    as1<- data.frame(mat.res.weib$X2, mat.res.weib$X5)
    colnames(as1)=c("X1", "X2")
    as2<- data.frame(mat.res.weib$X2, mat.res.weib$X6)
    colnames(as2)=c("X1", "X2")
    as3<- data.frame(mat.res.weib$X2, mat.res.weib$X7)
    colnames(as3)=c("X1", "X2")
    mat.res.weib1<- rbind(as1, as2, as3)
    mat.res.weib1 <- mat.res.weib1[order(mat.res.weib1[,1]),]
    plot(mat.res.weib1$X1, mat.res.weib1$X2, col="blue", xlab="N (sample size/group)", ylab=etiq, ylim=c(0,max(mat.res.weib1$X2)))
  }

  #calculo de la muestra
  if (noptima==T){ #an?lisis del calculo tama?o muestral con splines

    #plot( x.1, y.1)
    plx<-loess(X2 ~ X1, control = loess.control(surface =  "direct"), se=T, data=mat.res.weib1)
    aaa<- predict(plx, data.frame(X1 = mat.res.weib1$X1), se = TRUE)
    x.1.1 <- mat.res.weib1$X1
    lines(x.1.1, aaa$fit)
    lines(x.1.1,aaa$fit - qt(0.975,aaa$df)*aaa$se, lty=2, col = "red")
    lines(x.1.1,aaa$fit + qt(0.975,aaa$df)*aaa$se, lty=2, col = "red")


    #analisis del m?ximo local
    i.max <- as.numeric(localMaxima(aaa$fit)[1])#maximo local con el primer par?metro que se indique
    x.max <- mat.res.weib1[i.max,1]
    abline(v=x.max, col="red")
    abline(v=esfuerzo90, col="green")
    abline(v=esfuerzo95, col="green")
    abline(v=esfuerzo99, col="green")

    "Optimum Sample size (OSS)"
    plot(0,0)
    mtext( "Sample size (local maximum):",  line = -10)
    mtext( round(x.max,0), col="red",  line = -11)
    mtext(" Sample size(bootstrap): 90%,95%,99% for max.",  line = -5)
    mtext( round(esfuerzo90,0), col="green",  line = -6)
    mtext( round(esfuerzo95,0), col="green",  line = -7)
    mtext( round(esfuerzo99,0), col="green",  line = -8)



  }

  #funciones weibull para representar y analizar la grafica
  if (noptima==F){ #representacion experimento con remuestreos
    #modelo Weibull de 4 par?metros:
    model.SSweibull <- try(nls2(X2 ~ SSweibull(X1, Asym, Drop, lrc, pwr), data = mat.res.weib ))
    if (class(model.SSweibull) =="nls"){
      print("entra en weibull 4 parametros")
      #MODELO WEIBULL DE 4 PARAMeTRos
      summary(model.SSweibull)   #ver los par?metros estimados
      Asym1<-summary(model.SSweibull)$parameters[1]
      Asym1#se guarda en este array
      EE.Asym1 <- summary(model.SSweibull)$parameters[1,2] #error estandart de la estimaci?n
      EE.Asym1
      #intervalos de confianza de las predicciones
      Asym1.l95 <-  Asym1 - 1.96* EE.Asym1
      Asym1.l95
      Asym1.u95 <-  Asym1+ 1.96* EE.Asym1
      Asym1.u95
      #parametro del punto de inflexion en X (n? OTU)
      pwr <- summary(model.SSweibull)$parameters[4]
      pwr.l95 <- summary(model.SSweibull)$parameters[4] - 1.96*summary(model.SSweibull)$parameters[4,1] #parametro pwr asindota CI95% inferior
      pwr.u95 <- summary(model.SSweibull)$parameters[4] + 1.96*summary(model.SSweibull)$parameters[4,1] #parametro pwr asindota CI95% inferior

      #representar modelo Weibull estimado de 4 par?metros
      curve(summary(model.SSweibull)$parameters[1]-summary(model.SSweibull)$parameters[2]*
              exp(-exp(summary(model.SSweibull)$parameters[3])*x^summary(model.SSweibull)$parameters[4]), col = "RED", lwd = 2, add = TRUE)


      #prediccion del 95%. IC95%
      predCI <- predict(as.lm.nls(model.SSweibull), interval = "confidence", level = 0.95)
      class(predCI)

      #lineas de los intervalos de confianza
      xx<- mat.res.weib$X1
      lines(xx,predCI[,2],col="blue",lty=2)
      lines(xx,predCI[,3],col="blue",lty=2)

      #escribir en el plot:
      text(70, 0.08, "nls Weibull growth model 4 parameters", cex = .8)
      pwr.l95ll <- as.numeric(pwr.l95)
      if(pwr.l95ll < 0){pwr.l95ll<- 0.1}
      abline(v=pwr.u95, lty=3, col= "green")
      abline(v=pwr.l95ll, lty=3, col= "green")

      #dibujar los esfuerzos:
      #abline(v=esfuerzo90, col="green", lty=3)
      #abline(v=esfuerzo95, col="green", lty=3)
      #abline(v=esfuerzo99, col="green", lty=3)
      #summary(model.SSweibull)
      Asym<-summary(model.SSweibull)$parameters[1]
      Drop<-summary(model.SSweibull)$parameters[2]
      lrc<-summary(model.SSweibull)$parameters[3]
      pwr<-summary(model.SSweibull)$parameters[4]

      print("Asimptote:")
      print(Asym)
      print("Asimptote CI95% LL:")
      print(Asym1.l95)
      print("Asimptote CI95% LL:")
      print(Asym1.u95)

      print("-------------------------------------------")
      print("ESFUERZO ACTUAL (% respect maximum)")
      #esfuerzo para el 90% del maximo de genes
      #el modelo es: Asym*(1 - exp(-exp(lrc)*input))
      #la funcion inversa es: log((y/Asym)-1)/(-exp(lrc))
      alt<- Asym-Drop*exp(-exp(lrc)*esfuerzo.actual^pwr)
      esf.a<- 100*(alt/Asym)
      print(esf.a)
      print("-------------------------------------------")

      print("Drop:")
      print(Drop)
      print("lrc:")
      print(lrc)
      print("pwr:")
      print(pwr)
      #1.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
      y <- 0.90*Asym
      x.para.maximo.90<- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr) #inversa
      x.para.maximo.90
      print("effort to reach a time of the 90% of the maximum of the cumulative.survival curve")
      print(x.para.maximo.90)
      print("-------------------------------------------")

      #2.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
      y <- 0.95*Asym
      x.para.maximo.95<- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
      x.para.maximo.95
      print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve")
      print(x.para.maximo.95)
      print("-------------------------------------------")

      #3.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
      y <- 0.99*Asym
      x.para.maximo.99<- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
      x.para.maximo.99
      print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
      print(x.para.maximo.99)
      print("FINAL DE LA FUNCION")

    }

    if (class(model.SSweibull) != "nls") {
      #weibull 2 parametros
      #Self-Starting Nls Asymptotic Regression Model through the Origin: modelo weibull sencillo 2 par?metros
      #https://stat.ethz.ch/R-manual/R-devel/library/stats/html/SSasympOrig.html
      #MODELO WEIBULL DE 2 PARAMATRos
      #print("entra antes de en weibull 2 parametros")
      model.SSweibull1 <- nls(X2 ~ SSasympOrig(X1, Asym, lrc), data = mat.res.weib)
      if (class(model.SSweibull1) =="nls"){

        #si todo va bien:
        #ver los par?metros estimados
        summary(model.SSweibull1)
        Asym1<-summary(model.SSweibull1)$parameters[1]
        Asym1#se guarda en este array
        Asym1
        EE.Asym1 <- summary(model.SSweibull1)$parameters[1,2] #error estandart de la estimaci?n
        EE.Asym1

        #intervalos de confianza de las predicciones
        Asym1.l95 <-  Asym1 - 1.96* EE.Asym1
        Asym1.l95
        Asym1.u95 <-  Asym1+ 1.96* EE.Asym1
        Asym1.u95

        #parametro del n? de otus optimo
        pwr <- NA
        pwr.l95 <- NA
        pwr.u95 <- NA

        #representar modelo Weibull estimado de 4 par?metros
        curve(summary(model.SSweibull1)$parameters[1]*(1-exp(-exp(summary(model.SSweibull1)$parameters[2])*x)), col = "RED", lwd = 2, add = TRUE)

        #modelo:       Asym*(1 - exp(-exp(lrc)*input)).


        #prediccion del 95%. IC95%
        predCI <- predict(as.lm.nls(model.SSweibull1), interval = "confidence", level = 0.95)
        class(predCI)

        #lineas de los intervalos de confianza
        x<- mat.res.weib$X1
        #lines(x,predCI[,1],col="red",lty=2)
        #lines(x,predCI[,2],col="blue",lty=2)
        #lines(x,predCI[,3],col="blue",lty=2)


        #escribir en el plot:
        text(70, 0.08, "nls Weibull growth model 2 parameters", cex = .8)
        #pwr.l95ll <- as.numeric(pwr.l95)
        #if(pwr.l95ll < 0){pwr.l95ll<- 0.1}
        #abline(v=pwr.u95, lty=3, col= "green")
        #abline(v=pwr.l95ll, lty=3, col= "green")

        #dibujar los esfuerzos:
        #abline(v=esfuerzo90, col="grey", lty=3)
        #abline(v=esfuerzo95, col="grey", lty=3)
        #abline(v=esfuerzo99, col="grey", lty=3)


        #weibull 2 parametros:
        print("-------------------------------------------")
        print("Estimated parameters")
        print("Asimptote:")
        print(Asym1)
        Asym1<-summary(model.SSweibull1)$parameters[1]
        Asym1#se guarda en este array
        Asym1
        EE.Asym1 <- summary(model.SSweibull1)$parameters[1,2] #error estandart de la estimaci?n
        EE.Asym1

        #intervalos de confianza de las predicciones
        Asym1.l95 <-  Asym1 - 1.96* EE.Asym1
        Asym1.l95
        Asym1.u95 <-  Asym1+ 1.96* EE.Asym1
        Asym1.u95
        print("Asymptote CI LL:")
        print(Asym1.l95)
        print("Asymptote CI UL:")
        print(Asym1.u95)




        Asym<-summary(model.SSweibull1)$parameters[1]
        lrc<-summary(model.SSweibull1)$parameters[2]

        print("-------------------------------------------")
        print("ESFUERZO ACTUAL (% respect maximum)")
        #esfuerzo para el 90% del maximo de genes
        #el modelo es: Asym*(1 - exp(-exp(lrc)*input))
        #la funcion inversa es: log((y/Asym)-1)/(-exp(lrc))


        alt<- Asym*(1 - exp(-exp(lrc)*esfuerzo.actual))
        esf.a<- 100*(alt/Asym)
        print(esf.a)
        print("-------------------------------------------")

        #90% del esfuerzo maximo
        y <- 0.90*Asym
        x.para.maximo.90<- as.numeric(log(1-(y/Asym))/(-exp(lrc)) )
        print("effort to reach a time of the 90% of the maximum of the cumulative.survival curve 2 par")
        print(x.para.maximo.90)
        print("-------------------------------------------")

        #95% esfuerzo maximo
        y <- 0.95*Asym
        x.para.maximo.95<- as.numeric(log(1-(y/Asym))/(-exp(lrc)) )
        print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve 2p")
        print(x.para.maximo.95)
        print("-------------------------------------------")

        #99% esfuerzo maximo
        y <- 0.99*Asym
        x.para.maximo.99<- as.numeric(log(1-(y/Asym))/(-exp(lrc)) )

        print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
        print(x.para.maximo.99)
        print("-------------------------------------------")



      }


      #todo va mal
      if (class(model.SSweibull1) !="nls"){
        #intervalos de confianza de las predicciones
        Asym1<- NA
        Asym1.l95<- NA

        Asym1.u95<- NA

        #parametro del n? de otus optimo
        pwr <- NA
        pwr.l95 <- NA
        pwr.u95 <- NA
      }

    }


  }

  par(mfrow=c(1,1))

}



#####################################################################
# N-MIXTURES ABUNDANCE-RICHNESS MODEL OF SIMULATION
#####################################################################
################ MATRIZ SIMULADA CON VARIAS SUB-POBLACIONES CON N-MIXT##############################
#ver aqui
#https://groups.nceas.ucsb.edu/non-linear-modeling/projects/nmix/WRITEUP/nmix.pdf
#funcion para hacer simulaciones de N-mixturas
data.fn <-  function(R = 10, T = 5, lambda = 5, p0 = 1, p1 = 1, pSD = 0.5, nG = 40, xSD = 1){
  #     R: number of surveyed sites
  #     T: number of surveys at each site
  #     lambda: expected abundance
  #     p0: intercept of detection probability (logit scale)
  #     p1: slope of detection probability on covariate x (logit scale)
  #     pSD:       standard deviation of normal distribution from
  #     which observer effects u are drawn
  #     nG    : number of different observers    (called K in section 2)
  #     xSD: standard deviation of zero    -      mean normal distribution from
  #     which covariate values x are generated

  #     State equation:       Generate abundance from Poisson distribution
  N <-      rpois(R, lambda)

  # Draw values of covariate X
  x <-      rnorm(R, 0, xSD)

  # Generate observer ID array
  gID <-matrix(sort(rep(1:nG, 25)), nrow = R, ncol = T, byrow = TRUE)

  # Draw values of   covariate X
  x <-rnorm(R, 0, xSD)

  # Draw values of observer effects u and put them in R-T matrix
  u0 <-rnorm(nG, 0, pSD)
  u <-matrix(rep(u0, each =25), nrow = R, byrow = TRUE)

  # Compute R-T matrix of detection probability
  p <-plogis(p0 + p1 * x + u)

  #  Observation equation: Generate counts from Binomial distribution
  y <-array(dim = c(R, T))
  for(t in 1:T){
    y[,t] <-rbinom(R, N, p)
  }

  # Return stuff
  return(list(R=R, T=T, lambda=lambda, N=N, nG=nG, p0=p0, p1=p1, p=p,
              gID=gID, pSD=pSD, x=x, y=y, xSD=xSD, u=u, u0=u0))
}


