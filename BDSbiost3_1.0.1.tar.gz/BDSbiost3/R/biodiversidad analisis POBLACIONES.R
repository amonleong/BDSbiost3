
#toni monleon (8-11-2017)

#Function to calculate the biodiversity and a multiple test to determine the differences between groups
##################################################################################################
# a mixed bayesian entropy index: diversity and phylogenetics - USING THE MIXTURE OF MULTINOMIALS
#################################################################################################
#' Metagenomic analysis of biodiversity
#'
#' Function to caculate biodiversity indices by group of labels
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param vector.labels parameter
#' @param test.hill parameter
#' @param use.conditions use experimental conditions (levels of a factor)
#' @return print biodiversity
#' @export


#####################################################################################
#####   BIODIVERSITY ANALYSIS  (EXPERIMENTAL CONDITIONS)
#####################################################################################

#matriu matriz de frecuencias (OTUxsamples)
Analysis.Biodiver.Metagen <- function(matriu, use.conditions =F, vector.labels, test.hill=T) {
  #hace un calculo de la biodiversidad de submuestras de samples para todas las otus
  #vector.labels <- vector.labels2

  #libraries to upload
  library(radarchart)
  #devtools::install_github("MangoTheCat/radarchart")
  library(vegan)
  library(vcd)
  library(gplots)


  options(warning = F) # turn off

  #condition depending on the experimental conditions
  if(use.conditions==F){ #No subgrups/experimental conditions
    n1<-1 #only one class/group
    #change the names of the columns
    colnames(matriu)<-rep("TOTAL_SAMPLE",dim(matriu)[2])
    vector.labels<-rep("TOTAL_SAMPLE",dim(matriu)[2])
  }
  if(use.conditions==T){ #subgrups/experimental conditions
    n1<-length(levels(factor(vector.labels))) #numero de grupos diferentes
  }

  #NUMERO DE GRUPOS y crear una matriz paa almacenar los datos de biodiversidad
  my.array.BIODIVERSITY <- array(NA, dim=c(n1,10))#MATRIZ DE CONTINE LOS VALORES DE DIVERSIDAD

  #calcular la biodiversidad: riqueza, biodiversidad alpha, otra
    print("DESCRIPTIVE BIODIVERSITY ANALYSIS BDSbiost3")
    print( "see Vegan: http://cc.oulu.fi/~jarioksa/softhelp/vegan/html/diversity.html")
    print("ACRONIMS...: Species richness (S); SHANNON index, entropy index (H); Simpson index (simp); inverse of simpson (invsimp); alpha parameter of Fisher's logarithmic series (alpha); Pielou's evenness (J)")



    j<-1
    for (i in levels(factor(vector.labels))){
      #i="Sana"
      #i="FG"
      #i="V"
      #i="2013"
      #i="ARCYVEESNH"
      #rownames(my.array.BIODIVERSITY)= levels(factor(vector.labels))

      cat("Sample group: ", i, fill=T, sep="")
      #i<-"A"
      matriu.analisis<-matriu
      colnames(matriu.analisis)<-vector.labels
      matriu.analisis1<-matriu[,grep(i, colnames(matriu.analisis))]
      #View(matriu2013)
      #plot(poolaccum(t(matriu2013))) #plot de Richness

      #etiqueta del grupo
      #rownames(my.array.BIODIVERSITY)[j]<-"AA"
      #Riqueza muestral:
      #Richness by group of samples
      if(NCOL(matriu.analisis1)>3){
        #etiqueta del grupo
        #rownames(my.array.BIODIVERSITY)[j]<-i
        res.richness<-poolaccum(t(matriu.analisis1))
        #View(t(matriu.analisis1))
        #richness
        JK2<-res.richness$jack2[length(res.richness$jack2)] #JACKNIFE2
        chao<-res.richness$chao[length(res.richness$chao)] #CHAO
        #confidence intervals 95% para Chao
        aa<-unlist(summary(res.richness, display = "chao"))
        mat <- matrix(aa, ncol = 5, byrow = F)
        #str(aa)
        chao_ui <- mat[NROW(mat),3] #Chao95%li
        chao_li <- mat[NROW(mat),4] #Chao95_ui
      }

      #Richness each sample, one by one:
      if(NCOL(matriu.analisis1)<=1){ #una sola muestra
        #etiqueta del grupo
        #rownames(my.array.BIODIVERSITY)[j]<-i

        res.richness<-specnumber(t(matriu.analisis1)) #rarefaccion con una muestra, numero de especies esperada

        #richness
        JK2<-specnumber(t(matriu.analisis1))
        chao<-specnumber(t(matriu.analisis1))
        #confidence intervals 95% para Chao
        #aa<-unlist(summary(res.richness, display = "chao"))
        #mat <- matrix(aa, ncol = 5, byrow = F)
        #str(aa)
        chao_ui <- specnumber(t(matriu.analisis1))
        chao_li <- specnumber(t(matriu.analisis1))
      }

      #Other biodiversity indixes:
        #see Vegan: http://cc.oulu.fi/~jarioksa/softhelp/vegan/html/diversity.html
        H <- diversity(colSums(t(matriu.analisis1)), "shannon") #shannon
        simp <- diversity(colSums(t(matriu.analisis1)), "simpson") #simpson
        invsimp <- diversity(colSums(t(matriu.analisis1)), "inv") #inverse of simpson
        alpha <- fisher.alpha(colSums(t(matriu.analisis1)))#estimates the α parameter of Fisher's logarithmic series
        S <- specnumber(colSums(t(matriu.analisis1))) # Species richness (S)
        J <- H/log(S) #Pielou's evenness (J)





        #biodiversity indixes (mean)
        my.array.BIODIVERSITY[j,1] <- JK2 #JACKNIFE2
        my.array.BIODIVERSITY[j,2] <- chao #CHAO
        my.array.BIODIVERSITY[j,3] <- S #Species richness (S)
        my.array.BIODIVERSITY[j,4] <- H #SHANNON
        my.array.BIODIVERSITY[j,5] <- simp #simpson
        my.array.BIODIVERSITY[j,6] <- invsimp #inverse of simpson
        my.array.BIODIVERSITY[j,7] <- alpha #α parameter of Fisher's logarithmic series
        my.array.BIODIVERSITY[j,8] <- J #Pielou's evenness (J)

        #confidence intervals
        my.array.BIODIVERSITY[j,9] <- chao_li #Chao li
        my.array.BIODIVERSITY[j,10] <- chao_ui #Chao ui

        #print the biodiversity:
        cat(" |Richness............: ", "JACKNIFE2= ", JK2, " ,CHAO= ", chao, "( ", chao_li, " - ", chao_ui, " )",
            " ,S= ", S,  fill=T, sep="")
        cat(" |Alpha diversity.....: ",
            " H= ", H,
            " ,simp= ", simp,
            " ,invsimp= ", invsimp,
            " ,alpha= ", alpha,   fill=T, sep="")
        cat(" |Eveness.............: ",
            " J Pielou's= ", J,
            fill=T, sep="")

        #plot the biodiversity
        #classical rarefaction method:
        print("Rarefaction plot:-------------------------")
        zzz<-poolaccum(t(matriu.analisis1))
        plot(zzz,main="Richness estimation") #plot de Richness
        #poolaccum(t(matriu.analisis1))


      #}
      j<-j+1
    }

    #se podria hacer un radar plot: http://rstudio-pubs-static.s3.amazonaws.com/5795_e6e6411731bb4f1b9cc7eb49499c2082.html
    #source("http://pcwww.liv.ac.uk/~william/Geodemographic%20Classifiability/func%20CreateRadialPlot.r")
    #colnames(my.array.BIODIVERSITY)<-c("i1","i2","i3","i4","i5","i6","i7","i8")
    #rownames(my.array.BIODIVERSITY)<-levels(factor(vector.labels))
    #CreateRadialPlot(as.data.frame(my.array.BIODIVERSITY))
    #plot(my.array.BIODIVERSITY)
    #return(my.array.BIODIVERSITY)
    #library("kohonen")
    #set.seed(42)
    #model <- som(scale(ds[numi[1:14]]), grid = somgrid(5, 4, "hexagonal"))
    #plot(model, main="Weather Data")



    #source("http://pcwww.liv.ac.uk/~william/Geodemographic%20Classifiability/func%20CreateRadialPlot.r")

    #CreateRadialPlot(df2, plot.extent.x = 1.5)

    #class(my.array.BIODIVERSITY)

    # a radar-chart to represent the biodiversity
    #chartJSRadar(scores = my.array.BIODIVERSITY, labs = rownames(my.array.BIODIVERSITY), maxScale = 10)

    #Description of the biodiversiy
    rownames(my.array.BIODIVERSITY)<-levels(factor(vector.labels))
    my.array.BIODIVERSITY1<-na.omit(my.array.BIODIVERSITY)
    scores <- data.frame("Label"=c("JK2", "chao", "S",
                                   "H",  "simp", "invsimp", "alpha", "J"),
                         t(my.array.BIODIVERSITY1[,1:8]))

    #print("####################################################################################################")
    #print("CONFIDENCE INTERVAL 95% for Chao and Jacknife")


    #confidence intervals 95%
    #pool <- poolaccum(t(matriu.analisis1))
    #summary(pool, display = "chao")
    #plot(pool)


    if(test.hill==T){
      #mcpHill test for biodiversity between groups
      #Multiplicity-adjusted p-values for comparing biodiversity via simul-
      #  taneous inference of a user-defined selection of diversity indices
      #see at https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3470749/
      print("####################################################################################################")
      print("mcpHill : simultaneous statistic test for biodiversity between groups (Palman et al, 2012)")
      library(simboot)
      data.frame.biod <- as.data.frame(t(matriu))
      #View(data.frame.biod[,1:40])
      print("Groups and mcpHill tests (Method Tukey: --------------")
      print(levels(as.factor(vector.labels)))
      res1<-mcpHill(dataf=data.frame.biod, fact=as.factor(vector.labels), mattype = "Tukey", boots=5000, qval=c(-1,0,1,2))
      res2<-mcpHill(dataf=data.frame.biod, fact=as.factor(vector.labels), mattype = "Sequen", boots=5000, qval=c(-1,0,1,2))
      print("Groups and mcpHill tests (Method Tukey: --------------")
      print(res1)
      print("Groups and mcpHill tests (Method Sequen: --------------")
      print(res2)
      #ver en:
      #https://cran.r-project.org/web/packages/simboot/simboot.pdf
      #library(simboot)
      #data(Bacteria)
      #str(Bacteria)
      #View(Bacteria)
      ### Assess whether there is a difference in biodiversity and
      ### community composition species richness (Shannon index,
      ### Simpson index) between grassland and forest.
      ### Bootstrap times set to 50 due to example time settings
      #mcpHill(dataf=Bacteria[,2:24], fact=Bacteria[,1], boots=50000, qval=c(-1,0,1,2))

      return(list(Biodiversity=my.array.BIODIVERSITY, test.mcpHill = res1))
    }

    if(test.hill==F){
      return(list(Biodiversity=my.array.BIODIVERSITY))
    }

    #dev.new(width=5, height=10)
    #radarchar (no sale)
    #chartJSRadar(scores[1:3,], maxScale = max(my.array.BIODIVERSITY1[,1:3],na.rm = T), showToolTipLabel=TRUE)
    #chartJSRadar(scores[4:5,], maxScale = max(my.array.BIODIVERSITY1[,4:5],na.rm = T), showToolTipLabel=TRUE)
    #chartJSRadar(scores[7:8,], maxScale = max(my.array.BIODIVERSITY1[,7:8],na.rm = T), showToolTipLabel=TRUE)




    #library("CMplot")
    #CMplot(my.array.BIODIVERSITY,plot.type="c",col=c("darkgreen", "yellow", "red"),file="jpg",memo="",dpi=300)

    #HEATMAP DE LA BIODIVERSITY POR GRUPOS
    #colnames(my.array.BIODIVERSITY1)<-c("JK2", "chao", "S",
    #"H",  "simp", "invsimp", "alpha", "J", "chao_li", "chao_ui")
    #rownames(my.array.BIODIVERSITY)<-levels(factor(vector.labels))
#hclustfunc <- function(x) hclust(x, method="complete")
#distfunc <- function(x) dist(x,method="euclidean")

#d <- distfunc(my.array.BIODIVERSITY1[,1:8])
#fit <- hclustfunc(d)
#clusters <- cutree(fit, h=100)
#nofclust.height <-  length(unique(as.vector(clusters)));
    # Colorings
#hmcols <- rev(bluered(2750))
#selcol <- colorRampPalette(brewer.pal(12,"Set3"))
#selcol2 <- colorRampPalette(brewer.pal(9,"Set1"))
#clustcol.height = selcol2(nofclust.height)
    #BIODIV
    #dev.new(width=5, height=10)
#heatmap.2(as.matrix(t(my.array.BIODIVERSITY1)),
#trace='none',
#dendrogram='both',
#key=F,
#Colv=T,
#scale='col',
#hclust=hclustfunc, distfun=distfunc, col=hmcols,
#symbreak=T,
#margins=c(7,10), keysize=0.1,
#lwid=c(5,0.5,3), lhei=c(0.05,0.5),
#lmat=rbind(c(5,0,4),c(3,1,2)),
#labRow=colnames((my.array.BIODIVERSITY1)),
              #ColSideColors=c(1,1,3,1,1,1,1,8,9,1,1),  # This line doesn't work
#RowSideColors=clustcol.height[clusters])


    #ASSOCIATION PLOT
    #library(vcd)
    #dev.new(width=15, height=10)
    #assoc(my.array.BIODIVERSITY1, shade=TRUE)

    #bootstrap confidence interval
    #data <- data.frame(xs = rnorm(15, 2))

    #library(boot)
    #meanfun <- function(data, i){
    #  d <- data[i, ]
    #  return(mean(d))
    #}
    #bo <- boot(data[, "xs", drop = FALSE], statistic=meanfun, R=5000)
    #boot.ci(bo, conf=0.95, type="bca")
    #boot.ci(bo, conf=0.95, type="basic")


    ## Accumulation model
    #pool <- poolaccum(BCI)
    #summary(pool, display = "chao")
    #plot(pool)


     # turn off

}


