
#toni monleon (8-11-2017)

#EXPLORATORY DATA AND MDS, DISCRIMINANT BETWEEN GROUPS
##################################################################################################
# a mixed bayesian entropy index: diversity and phylogenetics - USING THE MIXTURE OF MULTINOMIALS
#################################################################################################
#' Metagenomic exploratory analysis: HEAT-MAPS, MDS AND DISCRIMINANT
#'
#' Function to explore data using MDS and discriminant analysis
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param use.conditions use experimental conditions (levels of a factor)
#' @param perc percentage of sample richness permitted (cuttoff)
#' @param KL Kulvart Leivert divergence or Battachryya distance
#' @param OTU if OTU = T, matrix of OTUS in the rows, OTU = F matrix of samples in columns
#' @param label.yes microorganism net complexity
#' @param vector.labels parameter
#' @param nrows number of rows at maximum to represent (OTU)
#' @param subgroup.kmeans do a SVD-KMEANS analysis of subgroups
#' @param K number of subgroups at SVD
#' @param vector.labels2 labels for subgroups of columns (samples)
#' @param DISCRI Do a LDA discriminant analysis when OTU = F, for samples
#' @param biodiv.indices Do a Biodiversity analysis
#' @param CV.s Cross Validation Training Set populations
#' @param xgb XGBoost xtreme boosting (random forest xtreme)
#' @return print of MDS results
#' @export



#####################################################################################
#####   dbhatta.PAM.Metagen
#####################################################################################



#Multivariate description of a metgenomic matrix, based on Rodriguez & Monleon(2017)
# using a Battacharya distance
LinesMDS<- function(matriu, use.conditions=F, KL=F, OTU=T, label.yes=F, vector.labels, nrows=50) {

  library(entropy)
  library(gplots)
  library(gplots)
  library(RColorBrewer)
  library(e1071) #SVM
  require(kohonen)
  require(RColorBrewer)
  library(RCurl)
  library(magrittr)
  library(xgboost)
  library(caret)

  #funcion para la descripcion multivariante y reduccion de la dimension de la matriz
  # ver articulo en el IOS Journal of Mathematics (Rodriguez et al, 2017)

  #nrows es el numero de otus O rows que selecciono
  if(dim(matriu)[1]<10){
    print("Number of OTU < 10. Is not possible perform the analysis")
    }
  #if(nrows < dim(matriu)[1]){nrows <- dim(matriu)[1]}

  ################## check number of experimental conditions #######################################
  #condition depending on the experimental conditions
  if(use.conditions==F){ #No subgrups/experimental conditions
    n1<-1 #only one class/group
    #change the names of the columns
    #colnames(matriu)<-rep("TOTAL_SAMPLE",dim(matriu)[2])
    vector.labels<-colnames(matriu)
    vector.labels2<-colnames(matriu)
  }
  if(use.conditions==T){ #subgrups/experimental conditions
    n1<-length(levels(factor(vector.labels))) #numero de grupos diferentes
  }

  #labels de las rows: OTU
  labels.rows <- rownames((matriu))

  #class(labels.rows)
  #vector.labels<- vector.labels1
  #parametros de la funci?n: matriu=matriz OTUS X SAMPLES DE FRECUENCIAS 16S, 18S,
  # perc. PARA EL HEATMAP PORCENTAJE DE FREC RELATIVA EN SAMPLES MEDIO QUE SE QUIERE VISUALIZAR

  #varios graficos a la vez
  #par(mfrow=c(2,2))
  #matriu <- t(matriu[,1:100])


  ############ transform count matrix in a percent matrix ###########################################################################
  #se transforma la matriz de contajes a matriz de porcentajes en tanto por uno
  #las filas suman 1 para cada columna
  #funcion que transforma filas a tanto por uno
  Get.matrix.CODA <- function(matriu1) {
    m<-ncol(matriu1) #cols
    n<-nrow(matriu1) #filas
    matriu.CODA<-matrix(0,nrow = n,ncol = m)
    #sum(matriz_mdsHP.1[,2])
    for (i in 1:m){ #col
      for (j in 1:n){ #row
        #print(samp)
        matriu.CODA[j,i]<-as.numeric(matriu1[j,i]/sum(matriu1[,i]))
      }
    }
    #entregable:
    matriu.CODA <<- matriu.CODA
    #sum(matriu.CODA[,3])
  }


  #dim(matriu.CODA)
  #se requiere la matriz de OTUs, OTU in the rows, columns samples
  #if (OTU == T){
  #matriu.ORDERED<-Get.matrix.CODA(matriu)
    #matriu.ORDERED[,1]
    #}

  #SE FILTRA POR NUMERO DE FILAS MAS ABUNDANTES
  #se requiere la matriz de samples, samples in the rows, columns OTU, hay que limitarla a una cantidad nrows
  #if (OTU == F){
    DF<- (matriu) #ordenar la matriz por la suma de otus de las filas
    DF<- DF[order(rowSums(DF),decreasing=T),]
    DF <- DF[1:nrows,] #escoger solo unas cuantas otus, nrows primeras
    #rowSums(DF)
    #View(t(DF))

    matriu.ORDERED<-Get.matrix.CODA(matriu1=t(DF))
    #View(matriu.ORDERED)
    #View(DF)
    #dim(t(DF))
    #dim(matriu.ORDERED)
    #matriu.ORDERED[,1]
    #}

  #library(MASS)
  #write.table(matriu.ORDERED, file = "mat_jf.csv", sep = ",", col.names = NA,
  #            qmethod = "double")

  ###########calculo de la distancia de Battacharya ######################################################################
  if (KL==F ) {
    #CALCULO DE LA DISTANCIA DE BATTACHARIA MATRICIALMENTE
    # Coeficient de Bhattacharyya (cal escalar les dades entre 0 i 1)
    #class(matriu.ORDERED) #ha de ser una matriz
    Q <- sqrt(matriu.ORDERED)
    BC <- Q%*%t(Q)
    # Dist?ncia de Bhattacharyya (al quadrat)
    BC <- ifelse(BC>1., 1., BC)
    D2B <- acos(BC)
    D2B
    #class(D2B)
    lletra <- "Metric MDS using Battacharyya distance"
  }
  #calculate the dissimilarity of Bray-Curtis & MDS
  #D2B<-vegdist((matriu),method="bray")


  ############################## metrica con la divergencia de Kullback-Leiwer ###########################
  #si se pide divergencia de Kullback-Leiwer
  #See at: https://www.stat.cmu.edu/~cshalizi/754/2006/notes/lecture-28.pdf
  #In probability theory and information theory, the Kullback-Leibler divergence,[1][2] also called information divergence, information gain, relative entropy, KLIC, or KL divergence, is a measure (but not a metric) of the non-symmetric difference between two probability distributions P and Q. The Kullback-Leibler divergence was originally introduced by Solomon Kullback and Richard Leibler in 1951 as the directed divergence between two distributions; Kullback himself preferred the name discrimination information.[3] It is discussed in Kullback's historic text, Information Theory and Statistics.[2]
  #Expressed in the language of Bayesian inference, the Kullback-Leibler divergence from Q to P, denoted DKL(P???Q), is a measure of the information gained when one revises one's beliefs from the prior probability distribution Q to the posterior probability distribution P. In other words, it is the amount of information lost when Q is used to approximate P.[4] In applications, P typically represents the "true" distribution of data, observations, or a precisely calculated theoretical distribution, while Q typically represents a theory, model, description, or approximation of P.
  if (KL==TRUE & OTU==T) {

    lletra<- "Metric MDS using Kullback-Leiwer divergence"
    #pairwise comparations #############################3
    #calcular la matriz de DIVERGENCIAS de Kullback-Leiwer

    f<-t(matriu)
    c<-ncol(t(matriu))
    KL.matrix <- matrix(0, c, c)
    n<-1
    for (i in 1:ncol(f)){
      for (j in n:ncol(f)){
        #i<-1
        #j<-2
        KL.matrix[i,j]<-KL.Dirichlet(f[,i], f[,j], a1=1/10, a2=1/10)
      }
      n= n+1
    }

    #matriz simetrica de distancias
    for (i in 1:ncol(KL.matrix)){
      for (j in 1:ncol(KL.matrix)){
        KL.matrix[j,i]<-KL.matrix[i,j]
      }
    }
    D2B<-KL.matrix
  }


  ################## mds #############################################################
  #MAKE THE MDS
  fit.mds <- cmdscale(D2B, eig = TRUE, k = 3)
  x <- fit.mds$points[, 1]
  y <- fit.mds$points[, 2]
  #summary(fit.mds)
  #fit.mds$eig
  eigen <- data.frame(fit.mds$eig, x, y)
  #eigen[266,2:3]

  #VALOR DE LOS COMPONENTES PRINCIPALES (EJES)
  #CRITERIO DE mardia
  print(" ########### MDS RESULTS ##########################")
  #round(sum(fit.mds$eig^2))
  un<-round((100*fit.mds$eig[1]^2)/sum(fit.mds$eig^2),3)
  dos<-round((100*fit.mds$eig[2]^2)/sum(fit.mds$eig^2),3)
  total<-round((100*fit.mds$eig[1]^2 + fit.mds$eig[2]^2)/sum(fit.mds$eig^2),3)
  cat("Mardia criteria: MDS1=", un, "% ,MDS2=", dos, "% ,TOTAL=", total, "%", fill=T, sep=""  )

  #criterio de ls eigenvalues
  #sum(abs(fit.mds$eig))
  un<-round((100*fit.mds$eig[1])/sum(abs(fit.mds$eig)),3)
  dos<-round((100*fit.mds$eig[2])/sum(abs(fit.mds$eig)),3)
  total<-round((100*fit.mds$eig[1] + fit.mds$eig[2])/sum(abs(fit.mds$eig)),3)
  cat("Eigenvalues criteria: MDS1=", un, "% ,MDS2=", dos, "% ,TOTAL=", total, "%", fill=T, sep=""  )

  #plot the MDS with good colors and labels
  #fit.mds$GOF
  plot(x, y,
       xlab=paste("MDS1:",un, "%"), ylab=paste("MDS2:",dos, "%"),
       main=lletra, sub="Rodriguez and Monleon, 2017", col="blue", cex = 1, lty = "solid")
  abline(h=0, v=0)

  if (label.yes==TRUE) {
    text(x, y, labels=vector.labels, cex= 0.6,
         pos=4, col= "black") #samples
  }
  if (label.yes==F) {
    text(x, y, labels=as.factor(vector.labels), cex= 0.6,
         pos=4, col= "black") #samples
  }



  #MULTIVARIATE EXPLORATION
  #HEATMAPS AND KOHONEN MAPS TO EPLORE GROUPS
  if (OTU==T){
      #from https://rpubs.com/crazyhottommy/PCA_MDS
      ## get a gradient of colors for grey, green, red.
      ## one can do better use other libraries such RcolorBrewer. see examples later.
      aa = grep("blue",colors())
      bb = grep("green",colors())
      cc = grep("red",colors())
      gcol2<- colors()[c(aa[1:30],bb[1:20],rep(cc,2))]

      #heatmap
      ## use the genes that drive the first PC1. This is the first major patter in the data
      k=1
      #Selecciono las nrows más abundantes
      ord1<- order(abs(fit.mds$points[,k]),decreasing=TRUE)
      x1<- as.matrix(matriu[ord1[1:nrows],])
      #heatmap(x1,col=gcol2)

      #devuelve la matriz seleccionada con nrows mas abundantes
      Selected.nrow.OTUS.Most.abundant <-x1
      #return(Selected.nrow.OTUS.Most.abundant)
      write.table(Selected.nrow.OTUS.Most.abundant, file = "Selected_nrow_OTUS.csv",
                  sep = ",", col.names = NA,
                  qmethod = "double")
      #hacer un analisis de las frecuencias entre muestras
      library("graphics")
      #dev.new(width=5, height=10)

      #MOSAIC PLOT
      mosaicplot(x1, shade = TRUE, las=2,type = 'pearson',
                 main = "MOSAIC - Frequencies: OTUS & samples")
      fm <- loglin(x1, list(1,2))
      #result of the test
      print("Mosaic test Pearson's chi-squared")
      print(pchisq(fm$pearson, fm$df, lower.tail = FALSE))




      #more heatmaps of the rows (OTUS) and columns (groups)
      #values = matrix(x1, nrow=nrows, dimnames=list(ord1[1:nrows], colnames(matriu)))
      #dev.new(width=5, height=10)
      #heatmap(values)

      #best heatmaps: http://www.molecularecologist.com/2013/08/making-heatmaps-with-r-for-microbiome-analysis/
      #library(gplots)  # for heatmap.2
     # to install packages from Bioconductor:
      #source("http://bioconductor.org/biocLite.R")
      #biocLite("Heatplus")  # annHeatmap or annHeatmap2
      #library(Heatplus)
     # load the RColorBrewer package for better colour options
      #library(RColorBrewer)

      hclustfunc <- function(x) hclust(x, method="complete")
      distfunc <- function(x) dist(x,method="euclidean")

      d <- distfunc(x1)
      fit <- hclustfunc(d)
      clusters <- cutree(fit, h=100)
      nofclust.height <-  length(unique(as.vector(clusters)));

      # Colorings
      hmcols <- rev(bluered(2750))
      selcol <- colorRampPalette(brewer.pal(12,"Set3"))
      selcol2 <- colorRampPalette(brewer.pal(9,"Set1"))
      clustcol.height = selcol2(nofclust.height)

      #otus
      #dev.new(width=5, height=10)
      #Heatmap OTUS
      heatmap.2(as.matrix((x1)),
                trace='none',
                dendrogram='both',
                key=F,
                Colv=T,
                scale='col',
                hclust=hclustfunc, distfun=distfunc, col=hmcols,
                symbreak=T,
                margins=c(7,10), keysize=0.1,
                lwid=c(5,0.5,3), lhei=c(0.05,0.5),
                lmat=rbind(c(5,0,4),c(3,1,2)),
                labRow=rownames((x1)),
                #ColSideColors=c(1,1,3,1,1,1,1,8,9,1,1),  # This line doesn't work
                RowSideColors=clustcol.height[clusters])
                #title(main = "HEATMAP OTUS")

                #samples:
                #dev.new(width=5, height=10)

                #Plot HEATMAP
                heatmap.2(as.matrix(t(x1)),
                trace='none',
                dendrogram='both',
                key=F,
                Colv=T,
                scale='col',
                hclust=hclustfunc, distfun=distfunc, col=hmcols,
                symbreak=T,
                margins=c(7,10), keysize=0.1,
                lwid=c(5,0.5,3), lhei=c(0.05,0.5),
                lmat=rbind(c(5,0,4),c(3,1,2)),
                #labRow=vector.labels2, #rownames(t(x1)),
                labRow=rownames(t(x1)),
                #ColSideColors=c(1,1,3,1,1,1,1,8,9,1,1),  # This line doesn't work
                RowSideColors=clustcol.height[clusters])
                #title(main = "HEATMAP SUB-GROUPS")

      #RowSideColors = c(    # grouping row-variables into different
      #rep("gray", 3),   # categories, Measurement 1-3: green
      #rep("blue", 3),    # Measurement 4-6: blue
      #rep("black", 4)))    # Measurement 7-10: red

      #par(lend = 1)           # square line ends for the color legend
      #legend("topright",      # location of the legend on the heatmap plot
      #legend = c("category1", "category2", "category3"), # category labels
      #col = c("gray", "blue", "black"),  # color key
      #lty= 1,             # line style
      #lwd = 10   )         # line width


      #MACHINE LEARNING MAPS - COM
      #The Self-Organizing Maps (SOMs) network is a neural network based method for dimension reduction.
      ##som_model <- som(scale(Selected.nrow.OTUS.Most.abundant), grid = somgrid(6, 3, "rectangular"))
      #plot(NBA.SOM1)
      #som_model <- som(scale(Selected.nrow.OTUS.Most.abundant),
      #                 grid=somgrid(10, 10, "hexagonal"),
      #                 rlen=100,
      #                 alpha=c(0.05),
      #                 keep.data = TRUE)

      #plot machine learning maps
      #dev.new(width=5, height=10)
      ##plot(som_model, type="dist.neighbours",main = "ML SOMs NETWORK")
      #plot(som_model, type="codes")

      #OTRO TIPO DE MAPA DE GRUPOS
      #groups = 4
      #iris.hc = cutree(hclust(dist(Selected.nrow.OTUS.Most.abundant)), groups)
      #dev.new(width=5, height=10)

      #plot cutree
      #plot(som_model, type="codes", bgcol=rainbow(groups)[iris.hc])
      #cluster boundaries
      #add.cluster.boundaries(som_model, iris.hc)

  }





}







#DISCRIMINANT ANALYSIS BETWEEN GROUPS AND NON HIERARQUICAL CLUSTERING EXPLORATORY ANALYSIS
#number of groups (cluster)using different methods (KMEANS, fuzzy cluster, etc)
#with CROSS VALIDATION USING RESAMPLING OF TRAINING-VALIDATION SETS
#ALL BASED IN THE BATTACHARYA DISTANCE AND MDS
MDSdbhatta.PAM.Metagen <- function(matriu, use.conditions=F, group.analysis=T, perc=0.00001, KL=F, OTU=F, label.yes=F, vector.labels,  nrows=50, subgroup.kmeans=T, K=3, vector.labels2, DISCRI=F, biodiv.indices = F, CV.s=F, xgb=F, numsim=100) {


#funcion para la descripcion multivariante y reduccion de la dimension de la matriz
# number of groups



  ################## check number of experimental conditions #######################################
  #condition depending on the experimental conditions
  if(use.conditions==F){ #No subgrups/experimental conditions
      n1<-1 #only one class/group
      #change the names of the columns
      #colnames(matriu)<-rep("TOTAL_SAMPLE",dim(matriu)[2])
      vector.labels<-colnames(matriu)
      vector.labels2<-colnames(matriu)
  }
  if(use.conditions==T){ #subgrups/experimental conditions
      n1<-length(levels(factor(vector.labels))) #numero de grupos diferentes
  }

  #labels de las rows: OTU
  labels.rows <- rownames((matriu))

  #class(labels.rows)
  #vector.labels<- vector.labels1
  #parametros de la funci?n: matriu=matriz OTUS X SAMPLES DE FRECUENCIAS 16S, 18S,
  # perc. PARA EL HEATMAP PORCENTAJE DE FREC RELATIVA EN SAMPLES MEDIO QUE SE QUIERE VISUALIZAR

  #varios graficos a la vez
  #par(mfrow=c(2,2))
  #matriu <- t(matriu[,1:100])


  ############ transform count matrix in a percent matrix ###########################################################################
  #se transforma la matriz de contajes a matriz de porcentajes en tanto por uno
  #las filas suman 1 para cada columna
  #funcion que transforma filas a tanto por uno
  Get.matrix.CODA <- function(matriu1) {
    m<-ncol(matriu1) #cols
    n<-nrow(matriu1) #filas
    matriu.CODA<-matrix(0,nrow = n,ncol = m)
    #sum(matriz_mdsHP.1[,2])
    for (i in 1:m){ #col
        for (j in 1:n){ #row
          #print(samp)
          matriu.CODA[j,i]<-as.numeric(matriu1[j,i]/sum(matriu1[,i]))
        }
    }
    #entregable:
    matriu.CODA <<- matriu.CODA
    #sum(matriu.CODA[,3])
  }


  #dim(matriu.CODA)
  #se requiere la matriz de OTUs, OTU in the rows, columns samples
  if (OTU == T){
      matriu.ORDERED<-Get.matrix.CODA(matriu)
      #matriu.ORDERED[,1]
  }

  #se requiere la matriz de samples, samples in the rows, columns OTU, hay que limitarla a una cantidad nrows
  if (OTU == F){
      DF<- (matriu) #ordenar la matriz por la suma de otus de las filas
      DF<- DF[order(rowSums(DF),decreasing=T),]
      DF <- DF[1:nrows,] #escoger solo unas cuantas otus, nrows primeras
      #rowSums(DF)
      #View(t(DF))

      matriu.ORDERED<-Get.matrix.CODA(matriu1=t(DF))
      #View(matriu.ORDERED)
      #View(DF)
      #dim(t(DF))
      #dim(matriu.ORDERED)
      #matriu.ORDERED[,1]
  }

  #library(MASS)
  #write.table(matriu.ORDERED, file = "mat_jf.csv", sep = ",", col.names = NA,
  #            qmethod = "double")

  ###########calculo de la distancia de Battacharya ######################################################################
  if (KL==F ) {
      #CALCULO DE LA DISTANCIA DE BATTACHARIA MATRICIALMENTE
      # Coeficient de Bhattacharyya (cal escalar les dades entre 0 i 1)
      #class(matriu.ORDERED) #ha de ser una matriz
      Q <- sqrt(matriu.ORDERED)
      BC <- Q%*%t(Q)
      # Dist?ncia de Bhattacharyya (al quadrat)
      BC <- ifelse(BC>1., 1., BC)
      D2B <- acos(BC)
      D2B
      #class(D2B)
      lletra <- "Metric MDS using Battacharyya distance"
  }
  #calculate the dissimilarity of Bray-Curtis & MDS
  #D2B<-vegdist((matriu),method="bray")


  ############################## metrica con la divergencia de Kullback-Leiwer ###########################
  #si se pide divergencia de Kullback-Leiwer
  #See at: https://www.stat.cmu.edu/~cshalizi/754/2006/notes/lecture-28.pdf
  #In probability theory and information theory, the Kullback-Leibler divergence,[1][2] also called information divergence, information gain, relative entropy, KLIC, or KL divergence, is a measure (but not a metric) of the non-symmetric difference between two probability distributions P and Q. The Kullback-Leibler divergence was originally introduced by Solomon Kullback and Richard Leibler in 1951 as the directed divergence between two distributions; Kullback himself preferred the name discrimination information.[3] It is discussed in Kullback's historic text, Information Theory and Statistics.[2]
  #Expressed in the language of Bayesian inference, the Kullback-Leibler divergence from Q to P, denoted DKL(P???Q), is a measure of the information gained when one revises one's beliefs from the prior probability distribution Q to the posterior probability distribution P. In other words, it is the amount of information lost when Q is used to approximate P.[4] In applications, P typically represents the "true" distribution of data, observations, or a precisely calculated theoretical distribution, while Q typically represents a theory, model, description, or approximation of P.
  if (KL==TRUE & OTU==T) {

    lletra<- "Metric MDS using Kullback-Leiwer divergence"
    #pairwise comparations #############################3
    #calcular la matriz de DIVERGENCIAS de Kullback-Leiwer

    f<-t(matriu)
    c<-ncol(t(matriu))
    KL.matrix <- matrix(0, c, c)
    n<-1
    for (i in 1:ncol(f)){
      for (j in n:ncol(f)){
        #i<-1
        #j<-2
        KL.matrix[i,j]<-KL.Dirichlet(f[,i], f[,j], a1=1/10, a2=1/10)
      }
      n= n+1
    }

    #matriz simetrica de distancias
    for (i in 1:ncol(KL.matrix)){
      for (j in 1:ncol(KL.matrix)){
        KL.matrix[j,i]<-KL.matrix[i,j]
      }
    }
    D2B<-KL.matrix
  }


  ################## mds #############################################################
  #MAKE THE MDS
  fit.mds <- cmdscale(D2B, eig = TRUE, k = 3)
  x <- fit.mds$points[, 1]
  y <- fit.mds$points[, 2]
  #summary(fit.mds)
  #fit.mds$eig
  eigen <- data.frame(fit.mds$eig, x, y)
  #eigen[266,2:3]


  #############################################################################
  ############### discriminant ################################################
  #salvo el fichero para hacer un analisis discriminante
  #DISCRI<-T
  if (OTU == F & DISCRI==T & label.yes==TRUE & use.conditions==T){



    #BIODIVERSITY ANALYSIS if so necessary
    #analisis de biodiversidad
    if (biodiv.indices == T){
      #BIODIVERSIDAD MEDIA POR GRUPO
      ##anal_biodiversity <- Analysis.Biodiver.Metagen(matriu, vector.labels,)

      #BIODIVERSIDAD POR CADA MUESTRA
      vector.labels_aa<-vector.labels #originales
      factor.name<-replicate(length(vector.labels), paste(sample(LETTERS, 10, replace=TRUE), collapse=""))
      #factori <- rep(round(1:length(vector.labels),3),1)
      anal_biodiversity <- Analysis.Biodiver.Metagen(matriu=matriu, vector.labels=factor.name, test.hill = F)

      DISCRIM.DATA.FRAME <- data.frame(class=factor.name,
                                       MDS1=fit.mds$points[, 1],
                                       MDS2=fit.mds$points[, 2],
                                       MDS3=fit.mds$points[, 3])
      #colnames(my.array.BIODIVERSITY1[,1:8])<-c("JK2", "chao", "S",
      #"H",  "simp", "invsimp", "alpha", "J")
      #add biodiversity data
      #JK2
      DISCRIM.DATA.FRAME$JK2 <- NA
      #chao
      DISCRIM.DATA.FRAME$chao <- NA
      #H
      DISCRIM.DATA.FRAME$H <- NA
      #simp
      DISCRIM.DATA.FRAME$simp <- NA
      #invsimp
      DISCRIM.DATA.FRAME$invsimp <- NA
      #alpha
      DISCRIM.DATA.FRAME$alpha <- NA
      #J
      DISCRIM.DATA.FRAME$J <- NA
      for (i in 1:NROW(DISCRIM.DATA.FRAME)){
        #i<-1
        seq <- as.character(DISCRIM.DATA.FRAME$class[i])
        result.seq<-anal_biodiversity$Biodiversity[grep(seq, rownames(anal_biodiversity$Biodiversity)),]
        #JK2
        DISCRIM.DATA.FRAME[i,5] <- result.seq[1]
        #chao
        DISCRIM.DATA.FRAME[i,6] <- result.seq[2]
        #H
        DISCRIM.DATA.FRAME[i,7] <- result.seq[4]
        #simp
        DISCRIM.DATA.FRAME[i,8] <- result.seq[5]
        #invsimp
        DISCRIM.DATA.FRAME[i,9] <- result.seq[6]
        #alpha
        DISCRIM.DATA.FRAME[i,10] <- result.seq[7]
        #J
        DISCRIM.DATA.FRAME[i,11] <- result.seq[8]
      }
      #volver a cambiarlo
      DISCRIM.DATA.FRAME$class <- vector.labels_aa

    }

    #sin analisis de biodiversidad, matriz solo del MDS
    if (biodiv.indices == F){
      DISCRIM.DATA.FRAME <- data.frame(class=vector.labels,
                                       MDS1=fit.mds$points[, 1],
                                       MDS2=fit.mds$points[, 2],
                                       MDS3=fit.mds$points[, 3])
    }


    #save the biodiversity file
    print("save the biodiversity file")
    write.table(DISCRIM.DATA.FRAME, file = "discrim_matrix.csv",
                sep = ",", col.names = NA,
                qmethod = "double")

    #si no hay indices de biodiversidad
    if (biodiv.indices == F){

      #LDA: LINEAR DISCRIMINANT ANALYSIS
      library(MASS)
      print("")
      print("")
      print("####################################################################")
      print("·········································.....................······")
      #print("LDA discriminant for samples wih Cross validation-------------------")
      fit <- lda(class ~ ., data=DISCRIM.DATA.FRAME, na.action="na.omit", CV=TRUE)
      #print(fit)

      # Assess the accuracy of the prediction
      # percent correct for each category of G
      ct <- table(DISCRIM.DATA.FRAME$class, fit$class)
      print("% good classification GROUPS")
      print(diag(prop.table(ct, 1)))
      # total percent correct
      capacity <- sum(diag(prop.table(ct)))
      #print("% good classification TOTAL")
      #print( sum(diag(prop.table(ct))))
      print("")
      print("")
      print("LINEAR DISCRIMINANT ANALYSIS LDA..................................:")
      cm1<-confusionMatrix(factor(DISCRIM.DATA.FRAME$class),
                      factor(fit$class),
                      mode = "everything")
      print(confusionMatrix(factor(DISCRIM.DATA.FRAME$class),
                            factor(fit$class),
                            mode = "everything"))
      #cm1$overall[1] LDA ACCURACY
      ####################################################################################
    }


    #SVM: support vector machine
    library(e1071)
    print("############################################################################")
    print("---SUPPORT VECTOR MACHINE (method=nu-classification, kernel=radial)---------")
    print("Discriminant with SVM--------------------------------------------------------")
    #set seed to ensure reproducible results
    #set.seed(42)
    #split into training and test sets
    if(CV.s==T){num.samples<-0.7}
    if(CV.s==F){num.samples<-1}
    DISCRIM.DATA.FRAME[,'train'] <- ifelse(runif(nrow(DISCRIM.DATA.FRAME))<num.samples,1,0)
    #separate training and test sets
    trainset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==1,]
    testset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==0,]
    #get column index of train flag
    trainColNum <- grep("train",names(trainset))
    #remove train flag column from train and test sets
    trainset <- trainset[,-trainColNum]
    testset <- testset[,-trainColNum]
    #get column index of predicted variable in dataset
    typeColNum <- grep("class",names(DISCRIM.DATA.FRAME))

    #model optimization
    svm_tune <-tune(svm, as.factor(class)~., data = DISCRIM.DATA.FRAME,
                    ranges = list(gamma = 2^(-1:1), cost = 2^(2:4)),
                    tunecontrol = tune.control(sampling = "boot") )
    #optimizar el modelo svm y los parametros gamma y cost
    #print(svm_tune[1]) #optimizacion del svm
    cost.1<-as.numeric(svm_tune$best.parameters[1]) #cost
    gamma.1<-as.numeric(svm_tune$best.parameters[2]) #gamma

    #mejor modelo con SVM
    if(CV.s==F){
      #build model – linear kernel and C-classification (soft margin) with default cost (C=1)
      svm_model <- svm(as.factor(class)~ ., data=DISCRIM.DATA.FRAME, method="nu-classification", kernel="radial", cross=dim(DISCRIM.DATA.FRAME)[1])
      #training set predictions
      pred1 <-predict(svm_model,DISCRIM.DATA.FRAME)

      print("Result of Cross-Validation of SVM model")
      print(summary(svm_model))
      #print(system.time(predict(svm_model_after_tune,x)))
      library(caret)
      print("Number of samples SVM predicted (test set): ")
      print(length(DISCRIM.DATA.FRAME$class))
      print("% good classification TOTAL SVM of total set (100% samples)")

      #print(confusionMatrix(as.factor(DISCRIM.DATA.FRAME$class), pred))
      print("")
      print("")
      print("SVM..................................:")
      print(confusionMatrix(factor(DISCRIM.DATA.FRAME$class),
                            factor(pred1),
                            mode = "everything"))
      cm2<-confusionMatrix(factor(DISCRIM.DATA.FRAME$class),
                           factor(pred1),
                           mode = "everything")
      #cm2$overall[1] SVM ACCURACY
    }


    if(CV.s==T){
      #CROSS-VALIDATION USING ONLY SVM
      library(e1071)
      library(caret)
      library(gplots)
      num.samples<-0.7
      DISCRIM.DATA.FRAME[,'train'] <- ifelse(runif(nrow(DISCRIM.DATA.FRAME))<num.samples,1,0)
      #separate training and test sets
      trainset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==1,]
      testset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==0,]
      #get column index of train flag
      trainColNum <- grep("train",names(trainset))
      #remove train flag column from train and test sets
      trainset <- trainset[,-trainColNum]
      testset <- testset[,-trainColNum]
      #get column index of predicted variable in dataset
      typeColNum <- grep("class",names(DISCRIM.DATA.FRAME))

      #model optimization
      svm_tune <-tune.svm(as.factor(class)~., data = DISCRIM.DATA.FRAME,
                          nu =  0.001:0.5,  gamma = 10^(-2:0),
                          type='nu-classification', kernel="radial")

      nu1 = svm_tune$best.parameters$nu
      gamma1 = svm_tune$best.parameters$gamma


      #optimizar el modelo svm y los parametros gamma y cost
      #print(svm_tune[1]) #optimizacion del svm
      #cost.1<-as.numeric(svm_tune$best.parameters[1]) #cost
      #gamma.1<-as.numeric(svm_tune$best.parameters[2]) #gamma
      #CV.s=F, xgb=F, numsim=100
      #numero de veces que se repite la validación con el conjunto de test

      num.iter<-numsim
      my.array.validation.model <- array(NA, dim=c(num.iter,4))
      for (i in 1:num.iter){
        #num.iter <- 1
        #selection of training and test set
        DISCRIM.DATA.FRAME[,'train'] <- ifelse(runif(nrow(DISCRIM.DATA.FRAME))<num.samples,1,0)
        #separate training and test sets
        trainset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==1,]
        testset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==0,]
        #get column index of train flag
        trainColNum <- grep("train",names(trainset))
        #remove train flag column from train and test sets
        trainset <- trainset[,-trainColNum]
        testset <- testset[,-trainColNum]
        #get column index of predicted variable in dataset
        typeColNum <- grep("class",names(DISCRIM.DATA.FRAME))


        #model
        #build model – linear kernel and C-classification (soft margin) with default cost (C=1)
        #svm_model <- svm(as.factor(class)~ ., data=trainset, method="C-classification", kernel="polynomial", degree=3, cost=cost.1, gamma=gamma.1)
        #svm_model <- svm(as.factor(class)~ ., data=trainset, method="C-classification", kernel="polynomial", degree=4, cost=cost.1, gamma=gamma.1)
        #svm_model <- svm(as.factor(class)~ ., data=trainset, method="nu-classification", kernel="radial", nu = nu1,
        #                 gamma = gamma1)
        svm_model <- svm(as.factor(class)~ ., data=trainset, method="nu-classification", kernel="radial")

        #svm_model summary(svm_model)
        #my.array.validation.model

        #print("Result of Cross-Validation of SVM model")
        #print(summary(svm_model))

        #training set predictions
        #pred_train <-predict(svm_model,trainset)
        #print("Prediction of trainig set SVM polynomic OPTIMIZED")
        #mean(pred_train==trainset$class)

        #test set predictions
        pred_test <-predict(svm_model,testset)
        mean(pred_test==testset$class)

        #print(system.time(predict(svm_model_after_tune,x)))

        #print("Number of samples SVM predicted (test set): ")
        #print(length(testset$class))
        #print("% good classification TOTAL SVM of the test set (30% samples)")

        aa<-(confusionMatrix(as.factor(testset$class), pred_test))
        #accuracy
        my.array.validation.model[i,1] <- aa$overall[1]
        my.array.validation.model[i,2] <- aa$overall[3]
        my.array.validation.model[i,3] <- aa$overall[4]
        #return(my.array.validation.model)
      }
      #my.array.validation.model
      bandplot(x=rep(1:num.iter,1), my.array.validation.model[,1], xlab="Iterations SVM", ylab="Accuracy(testset) n=50 sets")
      title(main = "VALIDATION PREDICTION SVM")
      #text(1, 1, cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,1]),2), " ,sd=", round(sd(my.array.validation.model[,1]),2), "]", fill=T, sep=""  ),cex = .8)
      print("")
      print("")
      print(cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,1]),2), " ,sd=", round(sd(my.array.validation.model[,1]),2), "]", fill=T, sep=""  ))
      text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,1]),2), ",sd=", round(sd(my.array.validation.model[,1]),2), "]" ,sep = "")
      #text1
      mtext(text1, side = 3)

    }
    #print("···············································")
    #print("############### fin prediction SVM ###############################")


    #support vector machine
    ##svm_model <- svm(as.factor(class) ~ ., data=DISCRIM.DATA.FRAME)
    #table(predict(svm_model), DISCRIM.DATA.FRAME$class, dnn=c("Prediction", "Actual"))
    #summary(svm_model)
    ##yy <- as.factor(DISCRIM.DATA.FRAME$class)
    ##xx <- subset(DISCRIM.DATA.FRAME, select=-class)
    ##svm_model1 <- svm(xx,yy)
    ##summary(svm_model1)
    ##pred <- predict(svm_model1,xx)
    ##system.time(pred <- predict(svm_model1,xx))
    ##table(pred,yy)

    #sum(diag(table(pred,y)))
    #dividir la matriz en train y en set
    ##svm_tune <- tune(svm, train.x=xx, train.y=yy,
    ##                 kernel="radial", ranges=list(cost=10^(-1:2), gamma=c(.5,1,2)))
    #optimizar el modelo svm
    ##print(svm_tune[1])
    ##cost.1<-as.numeric(svm_tune$best.parameters[1]) #cost
    ##gamma.1<-as.numeric(svm_tune$best.parameters[2]) #gamma
    #mejor modelo con SVM
    ##svm_model_after_tune <- svm(as.factor(class) ~ ., data=DISCRIM.DATA.FRAME, kernel="radial", cost=cost.1, gamma=gamma.1)
    #svm_model_after_tune <- svm(as.factor(class) ~ ., data=DISCRIM.DATA.FRAME, kernel="radial", cost=1, gamma=0.2476)

    ##summary(svm_model_after_tune)
    ##pred1 <- predict(svm_model_after_tune,xx)
    #print(system.time(predict(svm_model_after_tune,x)))
    ##library(caret)
    ##print("% good classification TOTAL SVM")
    ##print(confusionMatrix(as.factor(DISCRIM.DATA.FRAME$class), pred))

    ##print("···············································")
    ##print("############### fin prediction SVM ##################################")


    #otros metodos discriminantes:

    ####################################################################################
    #kernlab: Kernel-Based Machine Learning Lab
    #Kernel-based machine learning methods for classification, regression, clustering, novelty detection, quantile regression and dimensionality reduction. Among other methods 'kernlab' includes Support Vector Machines, Spectral Clustering, Kernel PCA, Gaussian Processes and a QP solver.
    #https://cran.r-project.org/web/packages/kernlab/index.html
    library(kernlab)
    test <- gausspr(class ~ as.matrix(DISCRIM.DATA.FRAME[,2:4]), data=DISCRIM.DATA.FRAME)
    ##test
    #alpha(test)
    # predict on the training set
    fit_class<-predict(test,as.matrix(DISCRIM.DATA.FRAME[,2:4]))
    # Assess the accuracy of the prediction
    # percent correct for each category of G
    ct <- table(DISCRIM.DATA.FRAME$class, fit_class)
    print("Kernel-Based Machine Lening discriminant-------------------")
    print("% good classification GROUPS")
    print(diag(prop.table(ct, 1)))
    # total percent correct
    capacity <- sum(diag(prop.table(ct)))
    #print("% good classification TOTAL")
    #print( sum(diag(prop.table(ct))))
    print("")
    print("")
    print("Kernel-Based Machine Lening discriminant..................................:")
    print(confusionMatrix(factor(DISCRIM.DATA.FRAME$class),
                          factor(fit_class),
                          mode = "everything"))
    cm3<-confusionMatrix(factor(DISCRIM.DATA.FRAME$class),
                         factor(fit_class),
                         mode = "everything")
    #cm3$overall[1] SVM ACCURACY

    ###################################################################################
    #xboost
    #ver en: https://rpubs.com/mharris/multiclass_xgboost
    library("xgboost")  # the main algorithm
    #library("archdata") # for the sample dataset
    library("caret")    # for the confusionmatrix() function (also needs e1071 package)
    library("dplyr")    # for some data preperation
    library("Ckmeans.1d.dp") # for xgb.ggplot.importance


    test <- gausspr(class ~ as.matrix(DISCRIM.DATA.FRAME[,2:4]), data=DISCRIM.DATA.FRAME)
    ##test
    #alpha(test)
    # predict on the training set
    fit_class<-predict(test,as.matrix(DISCRIM.DATA.FRAME[,2:4]))


    # set random seed
    #set.seed(717)
    #data(RBGlass1)
    dat <- DISCRIM.DATA.FRAME
    dat$class <- as.numeric(dat$class) -1


    #summary(dat)


    # Make split index
    train_index <- sample(1:nrow(dat), nrow(dat)*0.75)
    # Full data set
    data_variables <- as.matrix(dat[,-1])
    data_label <- dat[,"class"]
    data_matrix <- xgb.DMatrix(data = as.matrix(dat), label = data_label)
    # split train data and make xgb.DMatrix
    train_data   <- data_variables[train_index,]
    train_label  <- data_label[train_index]
    train_matrix <- xgb.DMatrix(data = train_data, label = train_label)
    # split test data and make xgb.DMatrix
    test_data  <- data_variables[-train_index,]
    test_label <- data_label[-train_index]
    test_matrix <- xgb.DMatrix(data = test_data, label = test_label)




    numberOfClasses <- length(unique(dat$class))
    xgb_params <- list("objective" = "multi:softprob",
                       "eval_metric" = "mlogloss",
                       "num_class" = numberOfClasses)
    nround    <- 50 # number of XGBoost rounds
    cv.nfold  <- 5

    # Fit cv.nfold * cv.nround XGB models and save OOF predictions
    cv_model <- xgb.cv(params = xgb_params,
                       data = train_matrix,
                       nrounds = nround,
                       nfold = cv.nfold,
                       verbose = FALSE,
                       prediction = TRUE)


    OOF_prediction <- data.frame(cv_model$pred) %>%
      mutate(max_prob = max.col(., ties.method = "last"),
             label = train_label + 1)
    head(OOF_prediction)


    # confusion matrix
    confusionMatrix(factor(OOF_prediction$max_prob),
                    factor(OOF_prediction$label),
                    mode = "everything")


    bst_model <- xgb.train(params = xgb_params,
                           data = train_matrix,
                           nrounds = nround)

    # Predict hold-out test set
    test_pred <- predict(bst_model, newdata = test_matrix)
    test_prediction <- matrix(test_pred, nrow = numberOfClasses,
                              ncol=length(test_pred)/numberOfClasses) %>%
      t() %>%
      data.frame() %>%
      mutate(label = test_label + 1,
             max_prob = max.col(., "last"))
    # confusion matrix of test set
    print("")
    print("")
    print("XBOOST for MULTICLASS..................................:")
    print(confusionMatrix(factor(test_prediction$max_prob),
                    factor(test_prediction$label),
                    mode = "everything"))
    cm4<-confusionMatrix(factor(test_prediction$max_prob),
                         factor(test_prediction$label),
                         mode = "everything")
    #cm4$overall[1] SVM ACCURACY

    # get the feature real names
    names <-  colnames(dat[,-1])
    # compute feature importance matrix
    importance_matrix = xgb.importance(feature_names = names, model = bst_model)
    head(importance_matrix)

    # plot
    gp = xgb.ggplot.importance(importance_matrix)
    print(gp)
    print("")
    print("")

    #solo si no hay cross validation entonces si hacer
    if(CV.s == F){
      #resultados resumen de los analisis
      #discriminantes
      print("Discriminant comparative results:")
      print("Accuracy LDA:------------------")
      print(cm1.n<-as.numeric(cm1$overall[1]))
      print("Accuracy SVM:------------------")
      print(cm2.n<-as.numeric(cm2$overall[1]))
      print("Accuracy KERNEL DISCRIMINANT:------------------")
      print(cm3.n<-as.numeric(cm3$overall[1]))
      print("Accuracy XBOOST:------------------")
      print(cm4.n<-as.numeric(cm4$overall[1]))

      #devolver informacion
      return(c(cm1.n, cm2.n, cm3.n, cm4.n))
    }


  }

  #CRITERIO DE mardia
  print(" ########### MDS RESULTS ##########################")
  #round(sum(fit.mds$eig^2))
  un<-round((100*fit.mds$eig[1]^2)/sum(fit.mds$eig^2),3)
  dos<-round((100*fit.mds$eig[2]^2)/sum(fit.mds$eig^2),3)
  total<-round((100*fit.mds$eig[1]^2 + fit.mds$eig[2]^2)/sum(fit.mds$eig^2),3)
  cat("Mardia criteria: MDS1=", un, "% ,MDS2=", dos, "% ,TOTAL=", total, "%", fill=T, sep=""  )

  #criterio de ls eigenvalues
  #sum(abs(fit.mds$eig))
  un<-round((100*fit.mds$eig[1])/sum(abs(fit.mds$eig)),3)
  dos<-round((100*fit.mds$eig[2])/sum(abs(fit.mds$eig)),3)
  total<-round((100*fit.mds$eig[1] + fit.mds$eig[2])/sum(abs(fit.mds$eig)),3)
  cat("Eigenvalues criteria: MDS1=", un, "% ,MDS2=", dos, "% ,TOTAL=", total, "%", fill=T, sep=""  )

  #plot the MDS with good colors and labels
  #fit.mds$GOF
  plot(x, y,
       xlab=paste("MDS1:",un, "%"), ylab=paste("MDS2:",dos, "%"),
       main=lletra, col="blue", cex = 1, lty = "solid")
  abline(h=0, v=0)

  if (label.yes==TRUE) {

    text(x, y, labels=vector.labels, cex= 0.6,
         pos=4, col= "black") #samples
  }
  if (label.yes==F) {
    text(x, y, labels=as.factor(vector.labels), cex= 0.6,
         pos=4, col= "black") #samples
  }


  #plot(0,0)
  #text(0,.8, "INERTIA 2 COMPONENTS")
  #a1<-(abs(fit.mds$eig[1])/sum(abs(fit.mds$eig)))
  #a2<-(abs(fit.mds$eig[2])/sum(abs(fit.mds$eig)))
  #a1.2<- a1 +  a2
  #text(-0.7,0,"2 COORD:" )
  #text(0,0,a1.2 )
  #text(-0.7,0.3,"1ST COOORD:" )
  #text(0,0.3,a1 )
  #text(-0.7,0.6,"2ND COOORD:" )
  #text(0,0.6,a2 )

  #cluster & analysis of groups non supervised
  #respecto a grupos que haya en las muestras
  #K-means clustering.
  #Read about K-means, hierachinal clustering, distance matrix and different linkages here

  #One needs to specify a K (how many clusters you want).

  #ANALISIS DEL NUMERO DE GRUPOS, SE HACE TAMBIEN CUANDO SE PIDE UN DISCRIMINANTE
  #analisis KMEANS
  if(group.analysis == T){

        #MDS DISTANCIA DE BATTACHARYA---------------------
        if(OTU==F){
          #Selecciono las nrows más abundantes
          matriu.ORDERED1<-matriu.ORDERED    }

        if(OTU==T){
          k=1
          #Selecciono las nrows más abundantes
          ord1<- order(abs(fit.mds$points[,k]),decreasing=TRUE)
          xx1<- as.matrix(matriu[ord1[1:nrows],])
          #heatmap(x1,col=gcol2)
          matriu.ORDERED1<-Get.matrix.CODA(t(xx1))
          matriu.ORDERED1[,1]
        }

        #CALCULO DE LA DISTANCIA DE BATTACHARIA MATRICIALMENTE
        # Coeficient de Bhattacharyya (cal escalar les dades entre 0 i 1)
        #class(matriu.ORDERED) #ha de ser una matriz
        Q1 <- sqrt(matriu.ORDERED1)
        BC1 <- Q1%*%t(Q1)
        # Dist?ncia de Bhattacharyya (al quadrat)
        BC1 <- ifelse(BC1>1., 1., BC1)
        D2B1 <- acos(BC1)
        D2B1
        fit.mds1 <- cmdscale(D2B1, eig = TRUE, k = 3)
        x1 <- fit.mds1$points[, 1]
        y1 <- fit.mds1$points[, 2]
        fit.mds1$eig
        #criterio de ls eigenvalues
        #sum(abs(fit.mds$eig))
        un1<-round((100*fit.mds1$eig[1])/sum(abs(fit.mds1$eig)),3)
        dos1<-round((100*fit.mds1$eig[2])/sum(abs(fit.mds1$eig)),3)
        total1<-round((100*fit.mds1$eig[1] + fit.mds1$eig[2])/sum(abs(fit.mds1$eig)),3)
        cat("Eigenvalues criteria: MDS1=", un1, "% ,MDS2=", dos1, "% ,TOTAL=", total1, "%", fill=T, sep=""  )

        # how do we visualize K-means results?
        ## overlay K-means result on the PCA plot.
        #plot(x1,y1,col=km$cluster,xlab="PCA1",ylab="PCA1" )
        #K = 9
        km = kmeans(D2B1,centers=K)
        #dev.new(width=5, height=10)
        #dev.new(width=5, height=10)
        #plot(x1, y1,xlab=paste("MDS1:",un1, "%"), ylab=paste("MDS2:",dos1, "%"),
        #     cex = 1, lty = 1, pch=levels(as.factor(vector.labels)), col=km$cluster, xlim=c(1.1*min(x1),1.1*max(x1)), ylim=c(1.1*min(y1),1.1*max(y1)))

        plot(x1, y1,xlab=paste("MDS1:",un1, "%"), ylab=paste("MDS2:",dos1, "%"),
             cex = 1, lty = 1, pch=km$cluster, col=km$cluster, xlim=c(1.1*min(x1),1.1*max(x1)), ylim=c(1.1*min(y1),1.1*max(y1)))

        abline(h=0, v=0,  lwd=0.3, col=2, lty=2)
        legend("topright", levels(as.factor(vector.labels)), pch=1,col=2, inset = .02,border = "red")
        title(main = "KMEANS/BATTACHARYA subgroups SAMPLES")
        text(x1,y1-0.007,vector.labels2,cex=.5,col=km$cluster)
        #cens = km$centers
        #points(cens%*%fit.mds$points[, 1],cens%*%fit.mds$points[, 2],col=1:K,pch=11,cex=3)

        print("GROUPS  ###################")
        for (i in 1:K){
          cat("Sample group: ", i, fill=T, sep="")
          print(subset(km$cluster, km$cluster==i))
          print("Samples with this group....:")
          a<-which(km$cluster == i)
          print(a)
        }

        ################### metodos mas Sofisticados #####################3
        #kernsmooth function:
        #Details
        #This is the binned approximation to the 2D kernel density estimate. Linear binning is used to obtain
        #the bin counts and the Fast Fourier Transform is used to perform the discrete convolutions. For each
        #x1,x2 pair the bivariate Gaussian kernel is centered on that location and the heights of the kernel,
        #scaled by the bandwidths, at each datapoint are summed. This sum, after a normalization, is the
        #corresponding fhat value in the output.
        #References
        #Wand, M. P. (1994). Fast Computation of Multivariate Kernel Estimators. Journal of Computational
        #and Graphical Statistics, 3, 433-445.
        #Wand, M. P. and Jones, M. C. (1995). Kernel Smoothing. Chapman and Hall, London.
        #http://ftp.auckland.ac.nz/software/CRAN/doc/packages/KernSmooth.pdf
        #funcion cid (density plot)
        #dev.new(width=20, height=10)
        library(gplots)
        ci2d(x = x1, y = y1, xlab=paste("MDS1:",un1, "%"), ylab=paste("MDS2:",dos1, "%"),
             pch = 19, show.points = T,     points.col = "yellow",
             factor=1.0, ci.levels=c(0.50,0.75,0.90,0.95,0.975), nbins=51, method=c("bkde2D"))
        title(main = "KernelDP bkde2D BATTACHARYA")
        text(x1-0.1,y1,vector.labels,cex=1)



        ############################################################
        # number of groups #######
        #cuantos clusters necesito en este espacio metrico de la distancia de Battacharya
        #more complex
        #see http://www.sthda.com/english/articles/30-advanced-clustering/104-model-based-clustering-essentials/
        #dev.new(width=5, height=10)
        library(factoextra)
        library(mclust)
        df <- scale(D2B1) # Standardize the data
        mc <- Mclust(df)            # Model-based-clustering
        summary(mc)                 # Print a summary
        # BIC values used for choosing the number of clusters
        aa<-fviz_mclust(mc, "BIC", palette = "jco")
        plot(aa)
        #dev.new(width=5, height=10)
        # Classification: plot showing the clustering
        aa<-fviz_mclust(mc, "classification", geom = "point",
                        pointsize = 1.5, palette = "jco")
        plot(aa)

        #dev.new(width=5, height=10)
        # Classification uncertainty
        aa<-fviz_mclust(mc, "uncertainty", palette = "jco")
        plot(aa)


        ############################################################
        #fuzzy clusters ############################################
        #http://www.sthda.com/english/articles/30-advanced-clustering/101-fuzzy-clustering-essentials/
        library(cluster)
        df <- scale(D2B1)     # Standardize the data
        res.fanny <- fanny(df, K)  # Compute fuzzy clustering with k = 2
        library(factoextra)
        aa<-fviz_cluster(res.fanny, ellipse.type = "norm", repel = TRUE,
                         palette = "jco", ggtheme = theme_minimal(),
                         legend = "right")
        plot(aa)
        title(main = "FUZZY CLUSTERS")

        ############################################################
        # More complex - CLUSPLOT
        #dev.new(width=5, height=10)
        kfit <- kmeans(D2B1, K)
        #plot – need library cluster
        library(cluster)
        clusplot((D2B1), kfit$cluster, color=TRUE, shade=TRUE,
                 labels=2, lines=0, main = "COMPLEX KMEANS/BATTACHARYA clusplot SAMPLES" )

  }


}




#do a dimension rediction based on a TSNE (T-Distributed Stochastic Neighbor Embedding for R (t-SNE))
Lines.TSNE <- function(matriu, labs, perpl=50,  k = 2, initial_dims = 30,  epoch=100, max_iter = 100){
  library(tsne)

  #tsne
  #see https://cran.r-project.org/web/packages/tsne/tsne.pdf
  #library(tsne)
  ## Not run:
  ## colors = rainbow(length(unique(iris$Species)))
  ## names(colors) = unique(iris$Species)
  ## ecb = function(x,y){ plot(x,t='n'); text(x,labels=iris$Species, col=colors[iris$Species]) }
  ## tsne_iris = tsne(iris[,1:4], epoch_callback = ecb, perplexity=50)
  # compare to PCA
  ## dev.new()
  ## pca_iris = princomp(iris[,1:4])$scores[,1:2]
  ## plot(pca_iris, t='n')
  ## text(pca_iris, labels=iris$Species,col=colors[iris$Species])
  ## End(Not run)

  colors = rainbow(length(unique(labs)))
  names(colors) = unique(labs)
  ecb = function(x,y){ plot(x,t='n'); text(x,labels=labs, col=colors[labs]) }
  tsne_iris = tsne(matriu, epoch_callback=ecb, perpl=perpl, k = k, initial_dims = initial_dims,  epoch=epoch, max_iter = max_iter)
}









#sep-2018-nueva version de la discriminacion
#DISCRIMINANT ANALYSIS BETWEEN GROUPS AND NON HIERARQUICAL CLUSTERING EXPLORATORY ANALYSIS
#number of groups (cluster)using different methods (KMEANS, fuzzy cluster, etc)
#with CROSS VALIDATION USING RESAMPLING OF TRAINING-VALIDATION SETS
#ALL BASED IN THE BATTACHARYA DISTANCE AND MDS
MDSdbhatta.PAM.Metagen1 <- function(matriu, use.conditions=F, group.analysis=T, perc=0.00001, KL=F, OTU=F, label.yes=F, vector.labels,  nrows=50, subgroup.kmeans=T, K=3, vector.labels2, DISCRI=F, biodiv.indices = F, CV.s=F, numsim=100) {

  #library()
  #funcion para la descripcion multivariante y reduccion de la dimension de la matriz
  # number of groups



  ################## check number of experimental conditions #######################################
  #condition depending on the experimental conditions
  if(use.conditions==F){ #No subgrups/experimental conditions
    n1<-1 #only one class/group
    #change the names of the columns
    #colnames(matriu)<-rep("TOTAL_SAMPLE",dim(matriu)[2])
    vector.labels<-colnames(matriu)
    vector.labels2<-colnames(matriu)
  }
  if(use.conditions==T){ #subgrups/experimental conditions
    n1<-length(levels(factor(vector.labels))) #numero de grupos diferentes
  }

  #labels de las rows: OTU
  labels.rows <- rownames((matriu))

  #class(labels.rows)
  #vector.labels<- vector.labels1
  #parametros de la funci?n: matriu=matriz OTUS X SAMPLES DE FRECUENCIAS 16S, 18S,
  # perc. PARA EL HEATMAP PORCENTAJE DE FREC RELATIVA EN SAMPLES MEDIO QUE SE QUIERE VISUALIZAR

  #varios graficos a la vez
  #par(mfrow=c(2,2))
  #matriu <- t(matriu[,1:100])


  ############ transform count matrix in a percent matrix ###########################################################################
  #se transforma la matriz de contajes a matriz de porcentajes en tanto por uno
  #las filas suman 1 para cada columna
  #funcion que transforma filas a tanto por uno
  Get.matrix.CODA <- function(matriu1) {
    m<-ncol(matriu1) #cols
    n<-nrow(matriu1) #filas
    matriu.CODA<-matrix(0,nrow = n,ncol = m)
    #sum(matriz_mdsHP.1[,2])
    for (i in 1:m){ #col
      for (j in 1:n){ #row
        #print(samp)
        matriu.CODA[j,i]<-as.numeric(matriu1[j,i]/sum(matriu1[,i]))
      }
    }
    #entregable:
    matriu.CODA <<- matriu.CODA
    #sum(matriu.CODA[,3])
  }


  #dim(matriu.CODA)
  #se requiere la matriz de OTUs, OTU in the rows, columns samples
  if (OTU == T){
    matriu.ORDERED<-Get.matrix.CODA(matriu)
    #matriu.ORDERED[,1]
  }

  #se requiere la matriz de samples, samples in the rows, columns OTU, hay que limitarla a una cantidad nrows
  if (OTU == F){
    DF<- (matriu) #ordenar la matriz por la suma de otus de las filas
    DF<- DF[order(rowSums(DF),decreasing=T),]
    DF <- DF[1:nrows,] #escoger solo unas cuantas otus, nrows primeras
    #rowSums(DF)
    #View(t(DF))

    matriu.ORDERED<-Get.matrix.CODA(matriu1=t(DF))
    #View(matriu.ORDERED)
    #View(DF)
    #dim(t(DF))
    #dim(matriu.ORDERED)
    #matriu.ORDERED[,1]
  }

  #library(MASS)
  #write.table(matriu.ORDERED, file = "mat_jf.csv", sep = ",", col.names = NA,
  #            qmethod = "double")

  ###########calculo de la distancia de Battacharya ######################################################################
  if (KL==F ) {
    #CALCULO DE LA DISTANCIA DE BATTACHARIA MATRICIALMENTE
    # Coeficient de Bhattacharyya (cal escalar les dades entre 0 i 1)
    #class(matriu.ORDERED) #ha de ser una matriz
    Q <- sqrt(matriu.ORDERED)
    BC <- Q%*%t(Q)
    # Dist?ncia de Bhattacharyya (al quadrat)
    BC <- ifelse(BC>1., 1., BC)
    D2B <- acos(BC)
    D2B
    #class(D2B)
    lletra <- "Metric MDS using Battacharyya distance"
  }
  #calculate the dissimilarity of Bray-Curtis & MDS
  #D2B<-vegdist((matriu),method="bray")


  ############################## metrica con la divergencia de Kullback-Leiwer ###########################
  #si se pide divergencia de Kullback-Leiwer
  #See at: https://www.stat.cmu.edu/~cshalizi/754/2006/notes/lecture-28.pdf
  #In probability theory and information theory, the Kullback-Leibler divergence,[1][2] also called information divergence, information gain, relative entropy, KLIC, or KL divergence, is a measure (but not a metric) of the non-symmetric difference between two probability distributions P and Q. The Kullback-Leibler divergence was originally introduced by Solomon Kullback and Richard Leibler in 1951 as the directed divergence between two distributions; Kullback himself preferred the name discrimination information.[3] It is discussed in Kullback's historic text, Information Theory and Statistics.[2]
  #Expressed in the language of Bayesian inference, the Kullback-Leibler divergence from Q to P, denoted DKL(P???Q), is a measure of the information gained when one revises one's beliefs from the prior probability distribution Q to the posterior probability distribution P. In other words, it is the amount of information lost when Q is used to approximate P.[4] In applications, P typically represents the "true" distribution of data, observations, or a precisely calculated theoretical distribution, while Q typically represents a theory, model, description, or approximation of P.
  if (KL==TRUE & OTU==T) {

    lletra<- "Metric MDS using Kullback-Leiwer divergence"
    #pairwise comparations #############################3
    #calcular la matriz de DIVERGENCIAS de Kullback-Leiwer

    f<-t(matriu)
    c<-ncol(t(matriu))
    KL.matrix <- matrix(0, c, c)
    n<-1
    for (i in 1:ncol(f)){
      for (j in n:ncol(f)){
        #i<-1
        #j<-2
        KL.matrix[i,j]<-KL.Dirichlet(f[,i], f[,j], a1=1/10, a2=1/10)
      }
      n= n+1
    }

    #matriz simetrica de distancias
    for (i in 1:ncol(KL.matrix)){
      for (j in 1:ncol(KL.matrix)){
        KL.matrix[j,i]<-KL.matrix[i,j]
      }
    }
    D2B<-KL.matrix
  }


  ################## mds #############################################################
  #MAKE THE MDS
  fit.mds <- cmdscale(D2B, eig = TRUE, k = 3)
  x <- fit.mds$points[, 1]
  y <- fit.mds$points[, 2]
  #summary(fit.mds)
  #fit.mds$eig
  eigen <- data.frame(fit.mds$eig, x, y)
  #eigen[266,2:3]


  #############################################################################
  ############### discriminant ################################################
  #salvo el fichero para hacer un analisis discriminante
  #DISCRI<-T
  if (OTU == F & DISCRI==T & label.yes==TRUE & use.conditions==T){



    #BIODIVERSITY ANALYSIS if so necessary
    #analisis de biodiversidad
    if (biodiv.indices == T){
      #BIODIVERSIDAD MEDIA POR GRUPO
      ##anal_biodiversity <- Analysis.Biodiver.Metagen(matriu, vector.labels,)

      #BIODIVERSIDAD POR CADA MUESTRA
      vector.labels_aa<-vector.labels #originales
      factor.name<-replicate(length(vector.labels), paste(sample(LETTERS, 10, replace=TRUE), collapse=""))
      #factori <- rep(round(1:length(vector.labels),3),1)
      anal_biodiversity <- Analysis.Biodiver.Metagen(matriu=matriu, vector.labels=factor.name, test.hill = F)

      DISCRIM.DATA.FRAME <- data.frame(class=factor.name,
                                       MDS1=fit.mds$points[, 1],
                                       MDS2=fit.mds$points[, 2],
                                       MDS3=fit.mds$points[, 3])
      #colnames(my.array.BIODIVERSITY1[,1:8])<-c("JK2", "chao", "S",
      #"H",  "simp", "invsimp", "alpha", "J")
      #add biodiversity data
      #JK2
      DISCRIM.DATA.FRAME$JK2 <- NA
      #chao
      DISCRIM.DATA.FRAME$chao <- NA
      #H
      DISCRIM.DATA.FRAME$H <- NA
      #simp
      DISCRIM.DATA.FRAME$simp <- NA
      #invsimp
      DISCRIM.DATA.FRAME$invsimp <- NA
      #alpha
      DISCRIM.DATA.FRAME$alpha <- NA
      #J
      DISCRIM.DATA.FRAME$J <- NA
      for (i in 1:NROW(DISCRIM.DATA.FRAME)){
        #i<-1
        seq <- as.character(DISCRIM.DATA.FRAME$class[i])
        result.seq<-anal_biodiversity$Biodiversity[grep(seq, rownames(anal_biodiversity$Biodiversity)),]
        #JK2
        DISCRIM.DATA.FRAME[i,5] <- result.seq[1]
        #chao
        DISCRIM.DATA.FRAME[i,6] <- result.seq[2]
        #H
        DISCRIM.DATA.FRAME[i,7] <- result.seq[4]
        #simp
        DISCRIM.DATA.FRAME[i,8] <- result.seq[5]
        #invsimp
        DISCRIM.DATA.FRAME[i,9] <- result.seq[6]
        #alpha
        DISCRIM.DATA.FRAME[i,10] <- result.seq[7]
        #J
        DISCRIM.DATA.FRAME[i,11] <- result.seq[8]
      }
      #volver a cambiarlo
      DISCRIM.DATA.FRAME$class <- vector.labels_aa

    }

    #sin analisis de biodiversidad, matriz solo del MDS
    if (biodiv.indices == F){
      DISCRIM.DATA.FRAME <- data.frame(class=vector.labels,
                                       MDS1=fit.mds$points[, 1],
                                       MDS2=fit.mds$points[, 2],
                                       MDS3=fit.mds$points[, 3])
    }


    #save the biodiversity file
    #print("save the biodiversity file")
    #write.table(DISCRIM.DATA.FRAME, file = "discrim_matrix.csv",
    #            sep = ",", col.names = NA,
    #            qmethod = "double")

    #si no hay indices de biodiversidad
    if (biodiv.indices == F){
      #discriminant analysis
      #NO SE IMPRIMEN LOS BAND PLOTS, SOLO LOS RESULTADOS
      ANNA.DISCRIMINANT.MaLearning.Predict(Y=DISCRIM.DATA.FRAME$class,X=DISCRIM.DATA.FRAME[,-1],num.samples=0.7,num.iter=100,nrounds.it=100,CV=CV.s,print.image=F)
    }

  }

  #CRITERIO DE mardia
  print(" ########### MDS RESULTS ##########################")
  #round(sum(fit.mds$eig^2))
  un<-round((100*fit.mds$eig[1]^2)/sum(fit.mds$eig^2),3)
  dos<-round((100*fit.mds$eig[2]^2)/sum(fit.mds$eig^2),3)
  total<-round((100*fit.mds$eig[1]^2 + fit.mds$eig[2]^2)/sum(fit.mds$eig^2),3)
  cat("Mardia criteria: MDS1=", un, "% ,MDS2=", dos, "% ,TOTAL=", total, "%", fill=T, sep=""  )

  #criterio de ls eigenvalues
  #sum(abs(fit.mds$eig))
  un<-round((100*fit.mds$eig[1])/sum(abs(fit.mds$eig)),3)
  dos<-round((100*fit.mds$eig[2])/sum(abs(fit.mds$eig)),3)
  total<-round((100*fit.mds$eig[1] + fit.mds$eig[2])/sum(abs(fit.mds$eig)),3)
  cat("Eigenvalues criteria: MDS1=", un, "% ,MDS2=", dos, "% ,TOTAL=", total, "%", fill=T, sep=""  )

  #plot the MDS with good colors and labels
  #fit.mds$GOF
  plot(x, y,
       xlab=paste("MDS1:",un, "%"), ylab=paste("MDS2:",dos, "%"),
       main=lletra, col="blue", cex = 1, lty = "solid")
  abline(h=0, v=0)

  if (label.yes==TRUE) {

    text(x, y, labels=vector.labels, cex= 0.6,
         pos=4, col= "black") #samples
  }
  if (label.yes==F) {
    text(x, y, labels=as.factor(vector.labels), cex= 0.6,
         pos=4, col= "black") #samples
  }


  #plot(0,0)
  #text(0,.8, "INERTIA 2 COMPONENTS")
  #a1<-(abs(fit.mds$eig[1])/sum(abs(fit.mds$eig)))
  #a2<-(abs(fit.mds$eig[2])/sum(abs(fit.mds$eig)))
  #a1.2<- a1 +  a2
  #text(-0.7,0,"2 COORD:" )
  #text(0,0,a1.2 )
  #text(-0.7,0.3,"1ST COOORD:" )
  #text(0,0.3,a1 )
  #text(-0.7,0.6,"2ND COOORD:" )
  #text(0,0.6,a2 )

  #cluster & analysis of groups non supervised
  #respecto a grupos que haya en las muestras
  #K-means clustering.
  #Read about K-means, hierachinal clustering, distance matrix and different linkages here

  #One needs to specify a K (how many clusters you want).

  #ANALISIS DEL NUMERO DE GRUPOS, SE HACE TAMBIEN CUANDO SE PIDE UN DISCRIMINANTE
  #analisis KMEANS
  if(group.analysis == T){

    #MDS DISTANCIA DE BATTACHARYA---------------------
    if(OTU==F){
      #Selecciono las nrows más abundantes
      matriu.ORDERED1<-matriu.ORDERED    }

    if(OTU==T){
      k=1
      #Selecciono las nrows más abundantes
      ord1<- order(abs(fit.mds$points[,k]),decreasing=TRUE)
      xx1<- as.matrix(matriu[ord1[1:nrows],])
      #heatmap(x1,col=gcol2)
      matriu.ORDERED1<-Get.matrix.CODA(t(xx1))
      matriu.ORDERED1[,1]
    }

    #CALCULO DE LA DISTANCIA DE BATTACHARIA MATRICIALMENTE
    # Coeficient de Bhattacharyya (cal escalar les dades entre 0 i 1)
    #class(matriu.ORDERED) #ha de ser una matriz
    Q1 <- sqrt(matriu.ORDERED1)
    BC1 <- Q1%*%t(Q1)
    # Dist?ncia de Bhattacharyya (al quadrat)
    BC1 <- ifelse(BC1>1., 1., BC1)
    D2B1 <- acos(BC1)
    D2B1
    fit.mds1 <- cmdscale(D2B1, eig = TRUE, k = 3)
    x1 <- fit.mds1$points[, 1]
    y1 <- fit.mds1$points[, 2]
    fit.mds1$eig
    #criterio de ls eigenvalues
    #sum(abs(fit.mds$eig))
    un1<-round((100*fit.mds1$eig[1])/sum(abs(fit.mds1$eig)),3)
    dos1<-round((100*fit.mds1$eig[2])/sum(abs(fit.mds1$eig)),3)
    total1<-round((100*fit.mds1$eig[1] + fit.mds1$eig[2])/sum(abs(fit.mds1$eig)),3)
    cat("Eigenvalues criteria: MDS1=", un1, "% ,MDS2=", dos1, "% ,TOTAL=", total1, "%", fill=T, sep=""  )

    # how do we visualize K-means results?
    ## overlay K-means result on the PCA plot.
    #plot(x1,y1,col=km$cluster,xlab="PCA1",ylab="PCA1" )
    #K = 9
    km = kmeans(D2B1,centers=K)
    #dev.new(width=5, height=10)
    #dev.new(width=5, height=10)
    #plot(x1, y1,xlab=paste("MDS1:",un1, "%"), ylab=paste("MDS2:",dos1, "%"),
    #     cex = 1, lty = 1, pch=levels(as.factor(vector.labels)), col=km$cluster, xlim=c(1.1*min(x1),1.1*max(x1)), ylim=c(1.1*min(y1),1.1*max(y1)))

    plot(x1, y1,xlab=paste("MDS1:",un1, "%"), ylab=paste("MDS2:",dos1, "%"),
         cex = 1, lty = 1, pch=km$cluster, col=km$cluster, xlim=c(1.1*min(x1),1.1*max(x1)), ylim=c(1.1*min(y1),1.1*max(y1)))

    abline(h=0, v=0,  lwd=0.3, col=2, lty=2)
    legend("topright", levels(as.factor(vector.labels)), pch=1,col=2, inset = .02,border = "red")
    title(main = "KMEANS/BATTACHARYA subgroups SAMPLES")
    text(x1,y1-0.007,vector.labels2,cex=.5,col=km$cluster)
    #cens = km$centers
    #points(cens%*%fit.mds$points[, 1],cens%*%fit.mds$points[, 2],col=1:K,pch=11,cex=3)

    print("GROUPS  ###################")
    for (i in 1:K){
      cat("Sample group: ", i, fill=T, sep="")
      print(subset(km$cluster, km$cluster==i))
      print("Samples with this group....:")
      a<-which(km$cluster == i)
      print(a)
    }

    ################### metodos mas Sofisticados #####################3
    #kernsmooth function:
    #Details
    #This is the binned approximation to the 2D kernel density estimate. Linear binning is used to obtain
    #the bin counts and the Fast Fourier Transform is used to perform the discrete convolutions. For each
    #x1,x2 pair the bivariate Gaussian kernel is centered on that location and the heights of the kernel,
    #scaled by the bandwidths, at each datapoint are summed. This sum, after a normalization, is the
    #corresponding fhat value in the output.
    #References
    #Wand, M. P. (1994). Fast Computation of Multivariate Kernel Estimators. Journal of Computational
    #and Graphical Statistics, 3, 433-445.
    #Wand, M. P. and Jones, M. C. (1995). Kernel Smoothing. Chapman and Hall, London.
    #http://ftp.auckland.ac.nz/software/CRAN/doc/packages/KernSmooth.pdf
    #funcion cid (density plot)
    #dev.new(width=20, height=10)
    library(gplots)
    ci2d(x = x1, y = y1, xlab=paste("MDS1:",un1, "%"), ylab=paste("MDS2:",dos1, "%"),
         pch = 19, show.points = T,     points.col = "yellow",
         factor=1.0, ci.levels=c(0.50,0.75,0.90,0.95,0.975), nbins=51, method=c("bkde2D"))
    title(main = "KernelDP bkde2D BATTACHARYA")
    text(x1-0.1,y1,vector.labels,cex=1)



    ############################################################
    # number of groups #######
    #cuantos clusters necesito en este espacio metrico de la distancia de Battacharya
    #more complex
    #see http://www.sthda.com/english/articles/30-advanced-clustering/104-model-based-clustering-essentials/
    #dev.new(width=5, height=10)
    library(factoextra)
    library(mclust)
    df <- scale(D2B1) # Standardize the data
    mc <- Mclust(df)            # Model-based-clustering
    summary(mc)                 # Print a summary
    # BIC values used for choosing the number of clusters
    aa<-fviz_mclust(mc, "BIC", palette = "jco")
    plot(aa)
    #dev.new(width=5, height=10)
    # Classification: plot showing the clustering
    aa<-fviz_mclust(mc, "classification", geom = "point",
                    pointsize = 1.5, palette = "jco")
    plot(aa)

    #dev.new(width=5, height=10)
    # Classification uncertainty
    aa<-fviz_mclust(mc, "uncertainty", palette = "jco")
    plot(aa)


    ############################################################
    #fuzzy clusters ############################################
    #http://www.sthda.com/english/articles/30-advanced-clustering/101-fuzzy-clustering-essentials/
    library(cluster)
    df <- scale(D2B1)     # Standardize the data
    res.fanny <- fanny(df, K)  # Compute fuzzy clustering with k = 2
    library(factoextra)
    aa<-fviz_cluster(res.fanny, ellipse.type = "norm", repel = TRUE,
                     palette = "jco", ggtheme = theme_minimal(),
                     legend = "right")
    plot(aa)
    title(main = "FUZZY CLUSTERS")

    ############################################################
    # More complex - CLUSPLOT
    #dev.new(width=5, height=10)
    kfit <- kmeans(D2B1, K)
    #plot – need library cluster
    library(cluster)
    clusplot((D2B1), kfit$cluster, color=TRUE, shade=TRUE,
             labels=2, lines=0, main = "COMPLEX KMEANS/BATTACHARYA clusplot SAMPLES" )

  }


}
