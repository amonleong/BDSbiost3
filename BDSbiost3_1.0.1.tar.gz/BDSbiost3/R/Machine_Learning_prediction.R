##############################################################
# prediction using a machine leaning algorithms (XBOOST and SVM)
# for Regression
###################################################################
#' ANUKET.MaLearning.Predict
#'
#' prediction machine-learning using XBOOST, SVM and LM
#' @param X data-set matrix with data containing the metagenomic frequencies (rows: OTUs, columns: samples)
#' @param Y if TRUE the matrix is ordered
#' @param CV cross-validation = T
#' @param num.samples =0.8 number of samples of the trainning set
#' @param num.iter number of iterations for the CV (100)
#' @param nrounds.it number of iteration for the XBOOST method (25)
#' @return List of estimations: bayesian H', bayesian H1' and H2', SCV, CV
#' @export

#exemple amb dades aigues
#prediction machine-learning using XBOOST:
#definir X_i e Y
# dataset<-episodiscompletlog2
#XDtrain <- xgb.DMatrix(data = as.matrix(dataset[,2:18]), label = as.matrix(dataset$durada_cua))
# X<-dataset[,2:18]
# Y<-dataset$durada_cua

#uso
# ANUKET.MaLearning.Predict(Y,X,num.samples=0.6,num.iter=20,nrounds.it=15)



#ploblema de REGRESION--------------------------------------
#DEFINICION DE LA FUNCION: FUNCION PARA REGRESION, QUE
#REALIZA LA VALIDACION DE DIFERENTES METODOS DE PREDICCION
ANUKET.MaLearning.Predict <- function(Y,X,num.samples=0.8,num.iter=10,nrounds.it=200,maxit1=1000, CV=T, bandplot.R2=F) {
  #CV=F
  #reconstruir el data-frame
  dataset <- cbind(Y,X)
  dataset<- na.omit(dataset) #quitar los missings o no funciona

  require(xgboost) #xgboost
  library(kernlab) #kernel regression
  library(nnet)



      #si solo se quiere que te indique los errores de predicción y quizas la R2 de todos los datos es
      #decir del modelo Y~X
      if(CV==F){
        #predicción basada en métodos de regresion
        #modelo Y~X

        #----------------------
        #model optimization SVM
        library(e1071)
        svm_tune <- tune.svm(Y~., data=dataset, sampling = "fix",
                             gamma = 2^c(-8,-4,0,2,3,4,5), cost = 2^c(-8,-4,-2,0,1,2,3))

        cost1 = svm_tune$best.parameters$cost
        gamma1 = svm_tune$best.parameters$gamma
         ########################################
          #calculo de los modelos de regresion con los diferentes metodos
          ########################################


          ########################################
          #SVM: SUPPORT VECTOR MACHINE
          #nu1 = svm_tune$best.parameters$nu
          #gamma1 = svm_tune$best.parameters$gamma
          svm_model_todo <- svm(Y~.,   kernel="radial",tolerance=0.00001,
                           type="eps-regression",  data=dataset,cost=cost1,gamma=gamma1)

          ###################################
          #linear model
          linear_model_todo<-lm(Y~., data=dataset)
          a<-summary(linear_model_todo)
          #a$r.squared
          ###################################

          #xgboost SIN cv NI TRAINING/SET
          #names(trainset)
          library(xgboost)
          clase.train<- as.vector(dataset$Y)
          #dtrain1 <- xgb.DMatrix(data = as.matrix(trainset[,12:20]), label = clase.train)
          num.X<-dim(dataset)[2] #numero de variables independientes
          dtrain1 <- xgb.DMatrix(data = as.matrix(dataset[,2:num.X]), label = clase.train)

          model_xgb_null.train_todo <- xgboost(data = dtrain1,
                                          nrounds=nrounds.it,
                                          objective = "reg:linear",
                                          eval_metric = "rmse",
                                          subsample = .7,
                                          colsample_bytree = .7  )


          ###########################################
          #kernlab: Kernel-Based Machine Learning Lab
          #Kernel-based machine learning methods for classification, regression, clustering, novelty detection, quantile regression and dimensionality reduction. Among other methods 'kernlab' includes Support Vector Machines, Spectral Clustering, Kernel PCA, Gaussian Processes and a QP solver.
          #https://cran.r-project.org/web/packages/kernlab/index.html
          #library(kernlab)
          model_KERNEL.train_todo <- gausspr(Y ~ ., type
                                        ="regression", data=dataset, kernel="rbfdot")

          #ANN: REDES NEURONALES
          MODEL_ANN = nnet(as.matrix(dataset[,2:num.X]), dataset$Y, size=1, linout=T,skip=T,maxit=maxit1,decay=0.01)


          #ACCURACY OF THE MODEL AND R SQUARE/P SQUARE (TARDA MUCHO)
          #test set predictions
          pred_test_todo <-predict(svm_model_todo,dataset[,2:num.X])
          pred_test.lm_todo <-predict(linear_model_todo,dataset[,2:num.X])
          pred_test.xgboost_todo <-predict(model_xgb_null.train_todo, as.matrix(dataset[,2:num.X]))
          pred_test.KERNEL_todo<-as.numeric(predict(model_KERNEL.train_todo,dataset[,2:num.X]))
          pred_ANN_todo <-predict(MODEL_ANN, dataset[,2:num.X])

          # Computing the new root mean squared error
          library(hydroGOF)
          svm.rmse_todo<-rmse(sim=(dataset$Y), obs=pred_test_todo)
          lm.rmse_todo<-rmse(sim=(dataset$Y), obs=pred_test.lm_todo )
          xgboost.rmse_todo<-rmse(sim=(dataset$Y), obs=pred_test.xgboost_todo )
          kernel.rmse_todo<-rmse(sim=(dataset$Y), obs=(pred_test.KERNEL_todo) )
          ann.rmse_todo<-rmse(sim=(dataset$Y), obs=as.numeric(pred_ANN_todo) )

          #absolute error
          svm.abs.error_todo <- (abs((dataset$Y) - (pred_test_todo)))
          lm.abs.error_todo <- (abs((dataset$Y) - (pred_test.lm_todo)))
          xgboost.abs.error_todo <- (abs((dataset$Y) - (pred_test.xgboost_todo)))
          kernel.abs.error_todo <- (abs((dataset$Y) - (pred_test.KERNEL_todo)))
          ann.abs.error_todo <- (abs((dataset$Y) - (pred_ANN_todo)))

          #R2 PREDICTION
          print("SVM prediction R2")
          print(summary(lm(dataset$Y~ pred_test_todo))$r.squared)
          print("lm prediction R2")
          print(summary(lm(dataset$Y~ pred_test.lm_todo))$r.squared)
          print("xboost prediction R2")
          print(summary(lm(dataset$Y~ pred_test.xgboost_todo))$r.squared)
          print("kernel-reg prediction R2")
          print(summary(lm(dataset$Y~ pred_test.KERNEL_todo))$r.squared)
          print("ANN-reg prediction R2")
          print(summary(lm(dataset$Y~ pred_ANN_todo))$r.squared)

          #plots de resultados
          par(mfrow=c(3,1))
          #svm
          plot(dataset$Y~ pred_test_todo,xlab="observed Y",ylab="predicted Y")
          title(main = "VALIDATION PREDICTION SVM")
          text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(svm.abs.error_todo),2), ",sd=", round(sd(svm.abs.error_todo),2), "]" ,sep = "")
          mtext(text1, side = 3)
          #lm
          plot(dataset$Y~ pred_test.lm_todo,xlab="observed Y",ylab="predicted Y")
          title(main = "VALIDATION PREDICTION LM")
          text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(lm.abs.error_todo),2), ",sd=", round(sd(lm.abs.error_todo),2), "]" ,sep = "")
          mtext(text1, side = 3)
          #xboost
          plot(dataset$Y~ pred_test.xgboost_todo,xlab="observed Y",ylab="predicted Y")
          title(main = "VALIDATION PREDICTION XBOOST")
          text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(xgboost.abs.error_todo),2), ",sd=", round(sd(xgboost.abs.error_todo),2), "]" ,sep = "")
          mtext(text1, side = 3)
          par(mfrow=c(2,1))
          #kernel
          plot(dataset$Y~ pred_test.KERNEL_todo,xlab="observed Y",ylab="predicted Y")
          title(main = "VALIDATION PREDICTION kernel-reg")
          text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(kernel.abs.error_todo),2), ",sd=", round(sd(kernel.abs.error_todo),2), "]" ,sep = "")
          mtext(text1, side = 3)
          #ANN
          plot(dataset$Y~ pred_ANN_todo,xlab="observed Y",ylab="predicted Y")
          title(main = "VALIDATION PREDICTION ANN-reg")
          text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(ann.abs.error_todo),2), ",sd=", round(sd(ann.abs.error_todo),2), "]" ,sep = "")
          mtext(text1, side = 3)



          #summary(lm(testset$Y~ pred_test.xgboost))
          #plot(testset$Y~ pred_test.KERNEL)
          #-------------------------
      }


      #si lo que se desea hacer es cross-validacion
      #dataset<-dataset[dataset$Y<200000,]
      #CV.s=T
      if(CV==T){
        #build model – linear kernel and C-classification (soft margin) with default cost (C=1)
        #svm_model <- svm(as.factor(class)~ ., data=trainset, method="C-classification", kernel="polynomial", degree=3, cost=cost.1, gamma=gamma.1, cross=dim(trainset)[1])
        #svm_model summary(svm_model)

        #print("Result of Cross-Validation of SVM model")
        #print(summary(svm_model))

        #training set predictions
        #pred_train <-predict(svm_model,trainset)
        #print("Prediction of trainig set SVM polynomic OPTIMIZED")
        #mean(pred_train==trainset$class)

        #test set predictions
        #pred_test <-predict(svm_model,testset)
        #mean(pred_test==testset$class)

        #print(system.time(predict(svm_model_after_tune,x)))
        #library(caret)
        #print("Number of samples SVM predicted (test set): ")
        #print(length(testset$class))
        #print("% good classification TOTAL SVM of the test set (30% samples)")

        #print(confusionMatrix(as.factor(testset$class), pred_test))

        #num.samples<-0.8
        dataset[,'train'] <- ifelse(runif(nrow(dataset))<num.samples,1,0)
        #separate training and test sets
        trainset <- dataset[dataset$train==1,]
        testset <- dataset[dataset$train==0,]
        #get column index of train flag
        trainColNum <- grep("train",names(trainset))
        #remove train flag column from train and test sets
        trainset <- trainset[,-trainColNum]
        testset <- testset[,-trainColNum]
        #get column index of predicted variable in dataset
        class<-dataset$Y
        typeColNum <- grep("class",names(dataset))

        #model optimization SVM
        library(e1071)
        #svm_tune <-tune.svm(Y~Y2+Y3+Y4+Y5+Y6+Y7+Y8+Y9+Y10+Y11+Y12+Y13+Y14+Y15+Y16+Y17+Y18+Y19+Y20, data = dataset,
        #                    nu =  0.000000000000001:1,  gamma = 10^(-2:0))
        svm_tune <- tune.svm(Y~., data=dataset, sampling = "fix",
                        gamma = 2^c(-8,-4,0,2,3,4,5), cost = 2^c(-8,-4,-2,0,1,2,3))

        cost1 = svm_tune$best.parameters$cost
        gamma1 = svm_tune$best.parameters$gamma


        #optimizar el modelo svm y los parametros gamma y cost
        print(svm_tune[1]) #optimizacion del svm
        #cost.1<-as.numeric(svm_tune$best.parameters[1]) #cost
        #gamma.1<-as.numeric(svm_tune$best.parameters[2]) #gamma
        #CV.s=F, xgb=F, numsim=100
        #numero de veces que se repite la validación con el conjunto de test
        library(caret)
        #num.iter<-25
        #num.samples=0.9
        #Esta array
        my.array.validation.model <- array(NA, dim=c(num.iter,13))
        for (i in 1:num.iter){
          #num.iter <- 5
          #maxit1<-1000
          #selection of training and test set
          dataset[,'train'] <- ifelse(runif(nrow(dataset))<num.samples,1,0)
          #separate training and test sets
          trainset <- dataset[dataset$train==1,]
          testset <- dataset[dataset$train==0,]
          #cuidado: testset puede tener numero de filas 0 !!!
          #get column index of train flag
          trainColNum <- grep("train",names(trainset))
          #remove train flag column from train and test sets
          trainset <- trainset[,-trainColNum]
          testset <- testset[,-trainColNum]
          #get column index of predicted variable in dataset
          typeColNum <- grep("class",names(dataset))


          #model
          #build model – linear kernel and C-classification (soft margin) with default cost (C=1)
          #svm_model <- svm(as.factor(class)~ ., data=trainset, method="C-classification", kernel="polynomial", degree=3, cost=cost.1, gamma=gamma.1)
          #svm_model <- svm(as.factor(class)~ ., data=trainset, method="C-classification", kernel="polynomial", degree=4, cost=cost.1, gamma=gamma.1)
          #svm_model <- svm(as.factor(class)~ ., data=trainset, method="nu-classification", kernel="radial", nu = nu1,
          #                 gamma = gamma1)

          ########################################
          #calculo de los modelos de regresion con los diferentes metodos
          ########################################


          ########################################
          #SVM: SUPPORT VECTOR MACHINE
          #nu1 = svm_tune$best.parameters$nu
          #gamma1 = svm_tune$best.parameters$gamma
          svm_model <- svm(Y~.,   kernel="radial",tolerance=0.00001,
                           type="eps-regression",  data=trainset,cost=cost1,gamma=gamma1)

          #ACCURACY OF THE MODEL AND R SQUARE/P SQUARE (TARDA MUCHO)
          #library(qpcR)
          #PSQUARE<-PRESS(svm_model)
          #PSQUARE$P.square
          #https://cran.r-project.org/web/packages/qpcR/qpcR.pdf

          #print(svm_model)

          ###################################
          #linear model
          linear_model<-lm(Y~., data=trainset)
          #summary(linear_model)

          #modelo optimizado y parsiomonioso
          #linear_model<-lm(Y~Y2+Y3+Y4+Y5+Y6+Y7+Y8+Y9+Y10+Y11+Y12+Y13+Y14+Y15+Y16+Y17+Y18+Y19+Y20+X2+X3+X4+X5+X6+X7+X8+X9+X10+X11+X12+X13+X14+X15+X16+X17+X18+X19+X20 , data=dataset)
          #step(linear_model,direction="both")
          #linear_model <- lm(formula = Y ~ Y3 + Y5 + Y6 + Y10 + Y12 + Y13 +
          #                     Y15 + Y16 + Y18 + Y20 + X3 + X6 + X7 + X8 + X11 + X13 + X18,
          #                   data = trainset)
          summary(linear_model)



          ###################################
          #xgboost SIN cv NI TRAINING/SET
          #names(trainset)
          library(xgboost)
          clase.train<- as.vector(trainset$Y)
          #dtrain1 <- xgb.DMatrix(data = as.matrix(trainset[,12:20]), label = clase.train)
          num.X<-dim(trainset)[2] #numero de variables independientes
          dtrain1 <- xgb.DMatrix(data = as.matrix(trainset[,2:num.X]), label = clase.train)

          #model_xgb_null.train <- xgboost(data = dtrain1, max.depth = 2, eta = 1, nthread = 4, nround = 10, prediction = TRUE, objective="multi:softmax",num_class = nlevels(trainset$class))

          #model_xgb_null.train <- xgboost(data = dtrain1,
          #                                nthread = 2,
          #                                booster = "gbtree",
          #                                nfold = 5,
          #                                nrounds=300,
          #                                max.depth = 5,
          #                                objective="reg:linear",maximize = T,
          #                                metrics = "rmse") #objective="multi:softmax" objective="reg:linear"

          model_xgb_null.train <- xgboost(data = dtrain1,
                                          nrounds=nrounds.it,
                                          objective = "reg:linear",
                                          eval_metric = "rmse",
                                          subsample = .7,
                                          colsample_bytree = .7  )

          #model_xgb_null.train <- xgboost(data = dtrain1,
          #                                max.depth = 7,
          #                                eta = 2, nthread = 2,
          #                                nround = nrounds.it,
          #                                objective="reg:linear",
          #                                eval_metric = "rmse" )


          ###########################################
          #kernlab: Kernel-Based Machine Learning Lab
          #Kernel-based machine learning methods for classification, regression, clustering, novelty detection, quantile regression and dimensionality reduction. Among other methods 'kernlab' includes Support Vector Machines, Spectral Clustering, Kernel PCA, Gaussian Processes and a QP solver.
          #https://cran.r-project.org/web/packages/kernlab/index.html
          #library(kernlab)
          model_KERNEL.train <- gausspr(Y ~ ., type ="regression", data=trainset, kernel="rbfdot")


          #ANN: REDES NEURONALES
          model_ANN.train = nnet(as.matrix(trainset[,-1]), trainset$Y, size=1, linout=T,skip=T,maxit=maxit1)


          #ACCURACY OF THE MODEL AND R SQUARE/P SQUARE (TARDA MUCHO)
          #library(qpcR)
          #PSQUARE1<-PRESS(model_xgb_null.train)
          #PSQUARE1$P.square

          #testset tiene que tener mas de un elemento para predecir
          if (dim(testset)[1]>0) {
              #test set predictions
              pred_test <-predict(svm_model,testset)
              pred_test.lm <-predict(linear_model,testset)
              pred_test.xgboost <-predict(model_xgb_null.train, as.matrix(testset[,2:num.X]))
              pred_test.KERNEL<-as.numeric(predict(model_KERNEL.train,testset))
              pred_test.ANN<-as.numeric(predict(model_ANN.train,testset))
              #summary(lm(testset$Y~ pred_test.xgboost))
              #plot(testset$Y~ pred_test.KERNEL)

              # Computing the new root mean squared error
              library(hydroGOF)
              svm.rmse<-rmse(sim=(testset$Y), obs=pred_test)
              lm.rmse<-rmse(sim=(testset$Y), obs=pred_test.lm )
              xgboost.rmse<-rmse(sim=(testset$Y), obs=pred_test.xgboost )
              kernel.rmse<-rmse(sim=(testset$Y), obs=(pred_test.KERNEL) )
              ANN.rmse<-rmse(sim=(testset$Y), obs=(pred_test.ANN) )

              #absolute error
              svm.abs.error <- mean(abs((testset$Y) - (pred_test)))
              lm.abs.error <- mean(abs((testset$Y) - (pred_test.lm)))
              xgboost.abs.error <- mean(abs((testset$Y) - (pred_test.xgboost)))
              kernel.abs.error <- mean(abs((testset$Y) - (pred_test.KERNEL)))
              ANN.abs.error <- mean(abs((testset$Y) - (pred_test.ANN)))

              #plot(testset$Y, pred_test.xgboost)
              #res<-lm(pred_test.xgboost~testset$Y)
              #summary(res)
              #forma rapida de calcular el rsquare en: https://datascienceplus.com/extreme-gradient-boosting-with-r/
              #Model evaluation svm
              predicted = predict(svm_model,testset)
              y_test<-testset$Y
              residuals = y_test - predicted
              RMSE = sqrt(mean(residuals^2))
              #cat('The root mean square error of the test data is ', round(RMSE,3),'\n')
              #The root mean square error of the test data is 2.856
              y_test_mean = mean(y_test)
              # Calculate total sum of squares
              tss =  sum((y_test - y_test_mean)^2 )
              # Calculate residual sum of squares
              rss =  sum(residuals^2)
              # Calculate R-squared
              rsq1  =  1 - (rss/tss) #rsquare svm
              #cat('The R-square of the test data is ', round(rsq,3), '\n')

              #Model evaluation xboost
              predicted = pred_test.xgboost
              y_test<-testset$Y
              residuals = y_test - predicted
              RMSE = sqrt(mean(residuals^2))
              #cat('The root mean square error of the test data is ', round(RMSE,3),'\n')
              #The root mean square error of the test data is 2.856
              y_test_mean = mean(y_test)
              # Calculate total sum of squares
              tss =  sum((y_test - y_test_mean)^2 )
              # Calculate residual sum of squares
              rss =  sum(residuals^2)
              # Calculate R-squared
              rsq3  =  1 - (rss/tss) #rsquare svm
              #cat('The R-square of the test data is ', round(rsq,3), '\n')

              #Model evaluation lm
              predicted = pred_test.lm
              y_test<-testset$Y
              residuals = y_test - predicted
              RMSE = sqrt(mean(residuals^2))
              #cat('The root mean square error of the test data is ', round(RMSE,3),'\n')
              #The root mean square error of the test data is 2.856
              y_test_mean = mean(y_test)
              # Calculate total sum of squares
              tss =  sum((y_test - y_test_mean)^2 )
              # Calculate residual sum of squares
              rss =  sum(residuals^2)
              # Calculate R-squared
              rsq2  =  1 - (rss/tss) #rsquare svm
              #cat('The R-square of the test data is ', round(rsq,3), '\n')




              # size of the prediction vector
              #print(length(pred))
              #VER EN: (mACHINE LEARNING) https://shiring.github.io/machine_learning/2016/12/02/flu_outcome_ML_2_post
              #pred <-predict(model_xgb_null,as.matrix(DISCRIM.DATA.FRAME$class))
              print("Result of svm testset")
              #print(summary(model_xgb_null))
              #print(pred)
              print("Values of root mean squared error predict using svm using a testset (Validation set)")
              print(svm.rmse)
              #see other validation criteria at: https://www.r-bloggers.com/assessing-the-accuracy-of-our-models-r-squared-adjusted-r-squared-rmse-mae-aic/

              #print("% good classification TOTAL xgboost of total set (100% samples)")
              #convert factor levels in a numerical levels using magrittr library
              #clase.testset<- (unclass(testset$class) %>% as.numeric )-1
              #options(show.error.messages=F) # turn off
              #aa<-try(print(confusionMatrix(clase.testset, pred1)))
              #accuracy
              #if (substr(aa[1],1,5)!="Error"){
              my.array.validation.model[i,1] <- svm.rmse
              my.array.validation.model[i,2] <- svm.abs.error
              my.array.validation.model[i,3] <- lm.rmse
              my.array.validation.model[i,4] <- lm.abs.error
              my.array.validation.model[i,5] <- xgboost.rmse
              my.array.validation.model[i,6] <- xgboost.abs.error
              my.array.validation.model[i,7] <- rsq1 #rsquare svm
              my.array.validation.model[i,8] <- rsq2 #rsquare lm
              my.array.validation.model[i,9] <- rsq3 #rsquare xboost
              my.array.validation.model[i,10] <- kernel.rmse
              my.array.validation.model[i,11] <- kernel.abs.error
              my.array.validation.model[i,12] <- ANN.rmse
              my.array.validation.model[i,13] <- ANN.abs.error
              #}
              #options(show.error.messages=T) # turn on
          }

        }
        my.array.validation.model #array que contiene la información de las remuestras (abserror, rmse, r2) para todos los metodos utilizado
        library(gplots)


        #quiero que me de un histograma de my.array.validation.model
        par(mfrow=c(3,2))
        #title(main = "HISTOGRAM abs.error-SVM")
        hist(my.array.validation.model[,2],breaks=20, main="HISTOGRAM abs.error-SVM", xlab="abs error")
        #q.deseada<- 2 #2horas
        #unos calculos suponiendo distribucion normal:
        #m1<-mean(my.array.validation.model[,2])
        #sd1<-sd(my.array.validation.model[,2])
        #print("Probabilidad normal de ser menor que: ")
        #print(q.deseada)
        #print(pnorm(q = q.deseada,mean=m1, sd=sd1))
        #print("==============================")

        #title(main = "HISTOGRAM abs.error-lm")
        hist(my.array.validation.model[,4],breaks=20, main="HISTOGRAM abs.error-lm", xlab="abs error")

        #title(main = "HISTOGRAM abs.error-xboost")
        hist(my.array.validation.model[,6],breaks=20, main="HISTOGRAM abs.error-xboost", xlab="abs error")

        #title(main = "HISTOGRAM abs.error-kernel")
        hist(my.array.validation.model[,11],breaks=20, main="HISTOGRAM abs.error-kernel", xlab="abs error")

        #title(main = "HISTOGRAM abs.error-ANN")
        hist(my.array.validation.model[,13],breaks=20, main="HISTOGRAM abs.error-ANN", xlab="abs error")


        #graficos de los errores RMSE y de los abs-error:
        par(mfrow=c(3,2))
        #svm
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,1], xlab="Iterations SVM", ylab="rmse (testset) n=200 sets")
        title(main = "VALIDATION PREDICTION SVM")
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,1],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,1],na.rm=TRUE),2), "]" ,sep = "")
        mtext(text1, side = 3)

        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,2], xlab="Iterations SVM", ylab="ABS ERROR (testset) n=200 sets")
        title(main = "VALIDATION PREDICTION SVM")
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,2],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,2],na.rm=TRUE),2), "]" ,sep = "")
        mtext(text1, side = 3)



        #lm
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,3], xlab="Iterations lm", ylab="rmse(testset) n=200 sets")
        title(main = "VALIDATION PREDICTION lm")
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,3],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,3],na.rm=TRUE),2), "]" ,sep = "")
        mtext(text1, side = 3)

        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,4], xlab="Iterations lm", ylab="ABS ERROR(testset) n=200 sets")
        title(main = "VALIDATION PREDICTION lm")
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,4],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,4],na.rm=TRUE),2), "]" ,sep = "")
        mtext(text1, side = 3)

        #xgboost
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,6], xlab="Iterations xgboost", ylab="rmse(testset) n=200 sets")
        title(main = "VALIDATION PREDICTION xgboost")
        #text(1, 1, cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,1]),2), " ,sd=", round(sd(my.array.validation.model[,1]),2), "]", fill=T, sep=""  ),cex = .8)
        print(cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,5],na.rm=TRUE),2), " ,sd=", round(sd(my.array.validation.model[,5],na.rm=TRUE),2), "]", fill=T, sep=""  ))
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,5],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,5],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text1, side = 3)

        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,6], xlab="Iterations xgboost", ylab="ABS ERROR(testset) n=200 sets")
        title(main = "VALIDATION PREDICTION xgboost")
        #text(1, 1, cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,1]),2), " ,sd=", round(sd(my.array.validation.model[,1]),2), "]", fill=T, sep=""  ),cex = .8)
        print(cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,6],na.rm=TRUE),2), " ,sd=", round(sd(my.array.validation.model[,6],na.rm=TRUE),2), "]", fill=T, sep=""  ))
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,6],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,6],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text1, side = 3)

        #ahora los de kernel regression
        par(mfrow=c(2,1))
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,10], xlab="Iterations kernel", ylab="rmse(testset) n=200 sets")
        title(main = "VALIDATION PREDICTION kernel")
        #text(1, 1, cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,1]),2), " ,sd=", round(sd(my.array.validation.model[,1]),2), "]", fill=T, sep=""  ),cex = .8)
        print(cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,10]),2), " ,sd=", round(sd(my.array.validation.model[,10],na.rm=TRUE),2), "]", fill=T, sep=""  ))
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,10],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,10],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text1, side = 3)

        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,11], xlab="Iterations kernel", ylab="ABS ERROR(testset) n=200 sets")
        title(main = "VALIDATION PREDICTION kernel")
        #text(1, 1, cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,1]),2), " ,sd=", round(sd(my.array.validation.model[,1]),2), "]", fill=T, sep=""  ),cex = .8)
        print(cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,11],na.rm=TRUE),2), " ,sd=", round(sd(my.array.validation.model[,11],na.rm=TRUE),2), "]", fill=T, sep=""  ))
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,11],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,11],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text1, side = 3)


        #ahora los de ANN regression
        par(mfrow=c(3,1))
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,12], xlab="Iterations kernel", ylab="rmse(testset) n=200 sets")
        title(main = "VALIDATION PREDICTION ANN")
        #text(1, 1, cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,1]),2), " ,sd=", round(sd(my.array.validation.model[,1]),2), "]", fill=T, sep=""  ),cex = .8)
        print(cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,12]),2), " ,sd=", round(sd(my.array.validation.model[,12],na.rm=TRUE),2), "]", fill=T, sep=""  ))
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,12],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,12],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text1, side = 3)

        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,13], xlab="Iterations kernel", ylab="ABS ERROR(testset) n=200 sets")
        title(main = "VALIDATION PREDICTION ANN")
        #text(1, 1, cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,1]),2), " ,sd=", round(sd(my.array.validation.model[,1]),2), "]", fill=T, sep=""  ),cex = .8)
        print(cat("ACCURACY OF ALL ITERTIONS: [Mean=", round(mean(my.array.validation.model[,13],na.rm=TRUE),2), " ,sd=", round(sd(my.array.validation.model[,13],na.rm=TRUE),2), "]", fill=T, sep=""  ))
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,13],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,13],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text1, side = 3)

        #plot the R2 plots
        if(bandplot.R2 == T){
          #r2
          par(mfrow=c(3,1))
          bandplot(x=rep(1:num.iter,1), my.array.validation.model[,7], xlab="Iterations SVM", ylab="rsquare (testset) n sets")
          title(main = "VALIDATION PREDICTION SVM")
          text1<-paste( "MEAN R2: [Mean=", round(mean(my.array.validation.model[,7],na.rm=TRUE),3), ",sd=", round(sd(my.array.validation.model[,7],na.rm=TRUE),3), "]" ,sep = "")
          mtext(text1, side = 3)

          #r2
          bandplot(x=rep(1:num.iter,1), my.array.validation.model[,8], xlab="Iterations lm", ylab="rsquare (testset) n sets")
          title(main = "VALIDATION PREDICTION lm")
          text1<-paste( "MEAN R2: [Mean=", round(mean(my.array.validation.model[,8],na.rm=TRUE),3), ",sd=", round(sd(my.array.validation.model[,8],na.rm=TRUE),3), "]" ,sep = "")
          mtext(text1, side = 3)

          #r2
          bandplot(x=rep(1:num.iter,1), my.array.validation.model[,9], xlab="Iterations xboost", ylab="rsquare (testset) n sets")
          title(main = "VALIDATION PREDICTION xboost")
          text1<-paste( "MEAN R2: [Mean=", round(mean(my.array.validation.model[,9],na.rm=TRUE),3), ",sd=", round(sd(my.array.validation.model[,9],na.rm=TRUE),3), "]" ,sep = "")
          mtext(text1, side = 3)
        }

        #otros plots
        #svm
        #plot(testset$Y, pred_test)
        #res<-lm(pred_test~testset$Y)
        #summary(res)

        #lm
        #plot(testset$Y, pred_test.lm)
        #res<-lm(pred_test.lm~testset$Y)
        #summary(res)

        #boost
        #plot(testset$Y, pred_test.xgboost)
        #res<-lm(pred_test.xgboost~testset$Y)
        #summary(res)




      }
      #print("···············································")
      #print("############### fin prediction SVM ###############################")


}


#ploblema de REGRESION--------------------------------------
#validacion para regresión Y ~ X, utilizando leave-one-out
#leave one out validation
ANUKET.Leave.one.out<- function(Y,X, nrounds.it=25){
  #calcular el numero de filas
  length.Y<- length(Y)
  trainset1<- as.data.frame(cbind(Y,X))

  #model optimization
  library(e1071)
  #svm_tune <-tune.svm(Y~Y2+Y3+Y4+Y5+Y6+Y7+Y8+Y9+Y10+Y11+Y12+Y13+Y14+Y15+Y16+Y17+Y18+Y19+Y20, data = dataset,
  #                    nu =  0.000000000000001:1,  gamma = 10^(-2:0))
  svm_tune <- tune.svm(Y~as.matrix(X), data=dataset, sampling = "fix",
                       gamma = 2^c(-8,-4,0,2,3,4,5), cost = 2^c(-8,-4,-2,0,1,2,3))

  cost1 = svm_tune$best.parameters$cost
  gamma1 = svm_tune$best.parameters$gamma


  my.array.validation.model <- array(NA, dim=c(length.Y,9))
  for (i in 1:length.Y){
    #i<-1 Y[1]
    Y.1 <- Y[-i]
    X.1 <- X[-i, ]
    trainset<- cbind(Y.1,X.1)
    #valor observado de Y
    #Y[length.Y]
    #guardarlos:
    my.array.validation.model[1]<-Y[i] #valor observado
    #svm
    #nu1 = svm_tune$best.parameters$nu
    #gamma1 = svm_tune$best.parameters$gamma
    svm_model <- svm(Y.1~.,   kernel="radial",tolerance=0.00001,
                     type="eps-regression",  cost=cost1, gamma= gamma1, data=trainset)

    #ACCURACY OF THE MODEL AND R SQUARE/P SQUARE (TARDA MUCHO)
    #library(qpcR)
    #PSQUARE<-PRESS(svm_model)
    #PSQUARE$P.square
    #https://cran.r-project.org/web/packages/qpcR/qpcR.pdf

    #print(svm_model)
    #linear model
    linear_model<-lm(Y.1~., data=trainset)
    #summary(linear_model)

    #modelo optimizado y parsiomonioso
    #linear_model<-lm(Y~Y2+Y3+Y4+Y5+Y6+Y7+Y8+Y9+Y10+Y11+Y12+Y13+Y14+Y15+Y16+Y17+Y18+Y19+Y20+X2+X3+X4+X5+X6+X7+X8+X9+X10+X11+X12+X13+X14+X15+X16+X17+X18+X19+X20 , data=dataset)
    #step(linear_model,direction="both")
    #linear_model <- lm(formula = Y ~ Y3 + Y5 + Y6 + Y10 + Y12 + Y13 +
    #                     Y15 + Y16 + Y18 + Y20 + X3 + X6 + X7 + X8 + X11 + X13 + X18,
    #                   data = trainset)
    summary(linear_model)

    #xgboost SIN cv NI TRAINING/SET
    #names(trainset)
    library(xgboost)
    clase.train<- as.vector(trainset$Y.1)
    #dtrain1 <- xgb.DMatrix(data = as.matrix(trainset[,12:20]), label = clase.train)
    num.X<-dim(trainset)[2] #numero de variables independientes
    dtrain1 <- xgb.DMatrix(data = as.matrix(trainset[,2:num.X]), label = clase.train)

    #model_xgb_null.train <- xgboost(data = dtrain1, max.depth = 2, eta = 1, nthread = 4, nround = 10, prediction = TRUE, objective="multi:softmax",num_class = nlevels(trainset$class))

    #model_xgb_null.train <- xgboost(data = dtrain1,
    #                                nthread = 2,
    #                                booster = "gbtree",
    #                                nfold = 5,
    #                                nrounds=300,
    #                                max.depth = 5,
    #                                objective="reg:linear",maximize = T,
    #                                metrics = "rmse") #objective="multi:softmax" objective="reg:linear"

    model_xgb_null.train <- xgboost(data = dtrain1,
                                    nrounds=nrounds.it,
                                    objective = "reg:linear",
                                    eval_metric = "rmse",
                                    subsample = .9,
                                    colsample_bytree = .9  )

    #model_xgb_null.train <- xgboost(data = dtrain1,
    #                                max.depth = 7,
    #                                eta = 2, nthread = 2,
    #                                nround = nrounds.it,
    #                                objective="reg:linear",
    #                                eval_metric = "rmse" )



    #ACCURACY OF THE MODEL AND R SQUARE/P SQUARE (TARDA MUCHO)
    #library(qpcR)
    #PSQUARE1<-PRESS(model_xgb_null.train)
    #PSQUARE1$P.square

    #test set predictions
    pred_test <-predict(svm_model,X[i,]) #Y[i]
    pred_test.lm <-predict(linear_model,as.data.frame(X[i,]))
    pred_test.xgboost <-predict(model_xgb_null.train, as.matrix(X[i,]))


    # Computing the new root mean squared error
    library(hydroGOF)
    svm.rmse<-rmse(sim=(Y[i]), obs=pred_test)
    lm.rmse<-rmse(sim=(Y[i]), obs=pred_test.lm )
    xgboost.rmse<-rmse(sim=(Y[i]), obs=pred_test.xgboost )

    #absolute error
    svm.abs.error <- mean(abs((Y[i]) - (pred_test)))
    lm.abs.error <- mean(abs((Y[i]) - (pred_test.lm)))
    xgboost.abs.error <- mean(abs((Y[i]) - (pred_test.xgboost)))

    my.array.validation.model[i,1] <- Y[i] #valor real
    my.array.validation.model[i,2] <- pred_test #prediccion SVM
    my.array.validation.model[i,3] <- svm.abs.error
    my.array.validation.model[i,4] <- pred_test.lm #predic lm
    my.array.validation.model[i,5] <- lm.abs.error
    my.array.validation.model[i,6] <- pred_test.xgboost #predicc xgboost
    my.array.validation.model[i,7] <- xgboost.abs.error




  }
  #my.array.validation.model
  m1<-lm(my.array.validation.model[,1]~ my.array.validation.model[,2])

  plot(my.array.validation.model[,1], my.array.validation.model[,2],
       xlab="real y", ylab="prediction", main="SVM", col="blue")
  m2<-lm(my.array.validation.model[,1]~ my.array.validation.model[,4])

  plot(my.array.validation.model[,1], my.array.validation.model[,4],
       xlab="real y", ylab="prediction", main="LM", col="red")
  m3<-lm(my.array.validation.model[,1]~ my.array.validation.model[,6])

  plot(my.array.validation.model[,1], my.array.validation.model[,6],
       xlab="real y", ylab="prediction ", main="XGBOOST", col="green")

  #print("RMSE svm")
  #print(mean(my.array.validation.model[,2]))

  print("R2 prediction svm")
  print(summary(m1)$r.squared)
  print("ABS ERROR svm")
  print(mean(my.array.validation.model[,3]))

  #print("RMSE lm")
  #print(mean(my.array.validation.model[,4]))
  print("R2 prediction lm")
  print(summary(m2)$r.squared)
  print("ABS ERROR lm")
  print(mean(my.array.validation.model[,5]))

  #print("RMSE xboost")
  #print(mean(my.array.validation.model[,6]))

  print("R2 prediction xboost")
  print(summary(m3)$r.squared)
  print("abs error xboost")
  print(mean(my.array.validation.model[,7]))

  return(c(summary(m1)$r.squared, mean(my.array.validation.model[,3]), summary(m2)$r.squared,
                mean(my.array.validation.model[,5]),summary(m3)$r.squared, mean(my.array.validation.model[,7])))


}

#ploblema de CLASIFICACION--------------------------------------
#analisis discriminante machine learning
#con y sin cross validation
ANNA.DISCRIMINANT.MaLearning.Predict <- function(Y,X,num.samples=0.8,num.iter=15,nrounds.it=200,CV=T, xboost.tunning = F, print.image=T) {
  #CV=F

    #num.iter=150
  #CV = cross-validation
  #xboost.tunning = F #tunning dels parametres, triga molt
  #example iris
  #library(MASS)
  #Y<-iris$Species
  #X<-iris[,-5]

  #reconstruir el data-frame
  dataset <- cbind(Y,X)
  require(xgboost) #xgboost
  library(kernlab) #kernel regression
  library(caret)
  library(e1071)
  library(MASS)
  library("dplyr")    # for some data preperation
  library("Ckmeans.1d.dp") # for xgb.ggplot.importance
  library(nnet)
  library(ggplot2)
  #################################
  #model optimization para el SVM:
  svm_tune <-tune.svm(Y~., data = dataset,
                      nu =  0.00001:1,  gamma = 10^(-3:1),
                      type='nu-classification', kernel="radial")

  nu1 = svm_tune$best.parameters$nu
  gamma1 = svm_tune$best.parameters$gamma
  ##########################################

  #si solo se quiere que te indique los errores de predicción y quizas la R2 de todos los datos es
  #decir del modelo Y~X
  #clasificacion, variable Y
  #CV<-F
  if(CV==F){
    #predicción basada en métodos discriminantes
    #modelo Y~X, Y=clase o factor



    #modelo discriminante SVM
    svm_model <- svm(Y~ ., data=dataset, method="nu-classification", kernel="radial",nu=nu1, gamma=gamma1)
    pred_test_SVM <-predict(svm_model,dataset[,-1])
    #accuracy
    aa_svm<-(confusionMatrix(as.factor(dataset$Y), pred_test_SVM))
    svm.accuracy <- aa_svm$overall[1]
    print("svm")
    print(aa_svm)


    #kernel-discriminante-----------------------------------
    ####################################################################################
    #kernlab: Kernel-Based Machine Learning Lab
    #Kernel-based machine learning methods for classification, regression, clustering, novelty detection, quantile regression and dimensionality reduction. Among other methods 'kernlab' includes Support Vector Machines, Spectral Clustering, Kernel PCA, Gaussian Processes and a QP solver.
    #https://cran.r-project.org/web/packages/kernlab/index.html
    library(kernlab)
    pred_test_kernel_discr<- gausspr(Y ~ as.matrix(dataset[,-1]), data=dataset)
    pred_test_kernel <-predict(pred_test_kernel_discr,dataset[,-1])
    #accuracy
    aa_kernel<-(confusionMatrix(pred_test_kernel, dataset$Y ))
    kernel.accuracy <- aa_kernel$overall[1]
    print("kernel discriminant")
    print(aa_kernel)

    #lda-----------------------------------
    lda.model <- lda(Y ~ ., dataset)
    pred_lda <-predict(lda.model,dataset[,-1])
    #accuracy
    aa_lda<-(confusionMatrix(pred_lda$class, dataset$Y ))
    lda.accuracy <- aa_lda$overall[1]
    print("LDA discriminant")
    print(aa_lda)

    #XBOOST-----------------------------------
    library(xgboost)
    clase.train<- as.vector(as.numeric(factor(dataset$Y))-1)
    #clase.train<-as.factor(clase.train)
    #dtrain1 <- xgb.DMatrix(data = as.matrix(trainset[,12:20]), label = clase.train)
    num.X<-dim(dataset)[2] #numero de variables independientes
    dtrain1 <- xgb.DMatrix(data = as.matrix(dataset[,2:num.X]), label = clase.train)
    numberOfClasses <- length(unique(dataset$Y))
    #optimize

    xgb_params <- list(eta = 0.01,
                       max_depth = 50,
                       "objective" = "multi:softprob",
                       "eval_metric" = "merror",
                       "num_class" = numberOfClasses,
                       nthread = 4,
                       subsample = 0.8,
                       colsample_bytree = 0.8)
    # Fit cv.nfold * cv.nround XGB models and save OOF predictions
    cv_model_xboost <- xgb.cv(params = xgb_params,
                       data = dtrain1,
                       nfold = 10,
                       nrounds = nrounds.it,
                       verbose = T,
                       prediction = TRUE,
                       maximize = F, showsd = T)
    #optimize see at:
    #https://www.hackerearth.com/practice/machine-learning/machine-learning-algorithms/beginners-tutorial-on-xgboost-parameter-tuning-r/tutorial/
    #xgb1 <- xgb.train (params = xgb_params, data = dtrain1, nrounds = 79, watchlist = list(val=dtest,train=dtrain), print.every.n = 10, early.stop.round = 10, maximize = F )
    #xgbcv.error <-  mean(as.vector(cv_model_xboost$evaluation_log[,2]))


    OOF_prediction <- data.frame(cv_model_xboost$pred) %>%
      mutate(max_prob = max.col(., ties.method = "last"),
             label = clase.train+1)
    head(OOF_prediction)
    aa_xboost<-confusionMatrix(factor(OOF_prediction$max_prob),
                    factor(OOF_prediction$label),
                    mode = "everything")

    xboost.accuracy <- aa_xboost$overall[1]
    print("XBOOST discriminant")
    print(aa_xboost)

    #neural nets: ANN -----------------
    #require(neuralnet)
    #require(nnet)
    #require(ggplot2)
    #https://www.r-bloggers.com/multilabel-classification-with-neuralnet-package/
    #library(nnet)
    ideal <- class.ind(Y)
    irisANN = nnet(X, ideal, size=1, softmax=TRUE)
    pred_ANN <-predict(irisANN, X, type="class")
    #accuracy
    aa_ANN<-(confusionMatrix(as.factor(pred_ANN), dataset$Y ))
    ANN.accuracy <- aa_ANN$overall[1]
    print("ANN discriminant")
    print(aa_ANN)


    #PRINT RESUMEN FINAL
    print("========================================")
    print("Accuracy of the discriminant methods")
    print("========================================")
    print("SVM:.........")
    print(svm.accuracy)
    print("Kernel-discriminant:......... ")
    print(kernel.accuracy)
    print("LDA:......... ")
    print(lda.accuracy)
    print("XBOOST:......... ")
    print(xboost.accuracy)
    print("ANN(Artificial Neural nets):.............")
    print(ANN.accuracy)
  }

  #con cross-validacion
  if(CV==T){
    #lo que debe entregarse con unos band plots con accuracy
    #sensibilidad y especificidad
    DISCRIM.DATA.FRAME<-dataset
    #num.samples<-0.7
    DISCRIM.DATA.FRAME[,'train'] <- ifelse(runif(nrow(DISCRIM.DATA.FRAME))<num.samples,1,0)
    #separate training and test sets
    trainset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==1,]
    testset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==0,]
    #get column index of train flag
    trainColNum <- grep("train",names(trainset))
    #remove train flag column from train and test sets
    trainset <- trainset[,-trainColNum]
    testset <- testset[,-trainColNum]
    #get column index of predicted variable in dataset
    typeColNum <- grep("Y",names(DISCRIM.DATA.FRAME))
    #View(DISCRIM.DATA.FRAME)


    ######### tunning XBOOST ###############
    if (xboost.tunning==T){
          ######### tunning XBOOST ###############
          numberOfClasses <- length(unique(dataset$Y))
          dataset1<-dataset
          dataset1$Y<-as.factor(as.numeric(dataset$Y))
          #View(dataset1)
          #set.seed(6879)
          # define training control using k-fold Cross Validation
          #train_control <- trainControl(method="cv", number=10)
          bootControl <- trainControl(method="cv", number=10)
          #parametros a optimizar
          xgbGrid <- expand.grid(
            eta = c(0.01, 0.1, 0.3, 0.5, 0.8, 1),
            max_depth = 6,
            nrounds = nrounds.it,
            gamma = c(0, 3, 10),
            colsample_bytree = 0.6,
            min_child_weight = 1,
            subsample=0.7
          )

          modFitxgb_B <-  train(
            Y ~ .,
            data = dataset1,
            trControl = bootControl,
            tuneGrid = xgbGrid,
            metric = "Accuracy",
            method = "xgbTree",
            verbose = 1,
            num_class = numberOfClasses,
            eval_metric = "mlogloss",
            objective = "multi:softprob",
            kfold=1

          )
          print("optimizacion de parametros XGBOOST")
          print(modFitxgb_B$bestTune)
          #parametros
          max_depth.xb<-modFitxgb_B$bestTune[2]#max-depth
          eta.xb<-modFitxgb_B$bestTune[3]#eta
          gamma.xb<-modFitxgb_B$bestTune[4]#gamma
    }
    if (xboost.tunning==F){
      #por defecto
      #https://xgboost.readthedocs.io/en/latest/parameter.html
      max_depth.xb<-6#max-depth
      eta.xb<-0.3#eta
      gamma.xb<-0#gamma
    }

    #num.iter<-numsim
    #num.iter<-10
    my.array.validation.model <- array(NA, dim=c(num.iter,20))
    for (i in 1:num.iter){
      #num.iter <- 25
      #i=1
      #selection of training and test set

      DISCRIM.DATA.FRAME[,'train'] <- ifelse(runif(nrow(DISCRIM.DATA.FRAME))<num.samples,1,0)
      #separate training and test sets
      trainset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==1,]
      testset <- DISCRIM.DATA.FRAME[DISCRIM.DATA.FRAME$train==0,]
      #get column index of train flag
      trainColNum <- grep("train",names(trainset))
      #remove train flag column from train and test sets
      trainset <- trainset[,-trainColNum]
      testset <- testset[,-trainColNum]
      #get column index of predicted variable in dataset
      typeColNum <- grep("Y",names(DISCRIM.DATA.FRAME))


      #model SVM-----------------------
      svm_model <- svm(as.factor(Y)~ ., data=trainset, method="nu-classification", kernel="radial",nu=nu1, gamma=gamma1)
      #test set predictions
      pred_test <-predict(svm_model,testset)
      mean(pred_test==testset$Y)
      aa<-(confusionMatrix(as.factor(testset$Y), pred_test))
      #accuracy-SENSIBILITY-SPECIFICITY
      my.array.validation.model[i,1] <- as.numeric(aa$overall[1])
      my.array.validation.model[i,2] <- as.numeric(aa$overall[2])
      if( is.na(as.numeric(aa$byClass[1]) )==F ){
        my.array.validation.model[i,3] <- as.numeric(aa$byClass[1]) #sens
      }
      if( is.na(as.numeric(aa$byClass[1]) )==T ){
        my.array.validation.model[i,3] <- 0 #sens es NA
      }
      my.array.validation.model[i,4] <- as.numeric(aa$byClass[2])#specificity


      #kernel-discriminante-----------------------------------
      library(kernlab)
      pred_test_kernel_discr<- gausspr(Y ~ as.matrix(trainset[,-1]), data=trainset)
      pred_test_kernel <-predict(pred_test_kernel_discr,testset[,-1])
      aa11<-(confusionMatrix(as.factor(testset$Y), pred_test))
      #accuracy-SENSIBILITY-SPECIFICITY
      my.array.validation.model[i,5] <- as.numeric(aa11$overall[1])
      my.array.validation.model[i,6] <- as.numeric(aa11$overall[2])
      my.array.validation.model[i,7] <- as.numeric(aa11$byClass[1]) #sens
      my.array.validation.model[i,8] <- as.numeric(aa11$byClass[2])#specificity


      #lda-----------------------------------
      lda.model <- lda(Y ~ ., trainset)
      pred_lda <-predict(lda.model,testset[,-1])
      #accuracy
      aa_lda<-(confusionMatrix(testset$Y, pred_lda$class))
      #accuracy-SENSIBILITY-SPECIFICITY
      my.array.validation.model[i,9] <- as.numeric(aa_lda$overall[1])
      my.array.validation.model[i,10] <- as.numeric(aa_lda$overall[2])
      my.array.validation.model[i,11] <- as.numeric(aa_lda$byClass[1]) #sens
      my.array.validation.model[i,12] <- as.numeric(aa_lda$byClass[2])#specificity

      #XGBOOST-------------------------------
      # Create numeric labels with one-hot encoding
      #(as.numeric(dataset$Y)-1)
      train_labs <- (as.numeric(trainset$Y)-1) #labels[0,numclases]
      val_labs <- (as.numeric(testset$Y)-1) #labels[0,numclases]
      # Prepare matrices
      xgb_train <- xgb.DMatrix(data = as.matrix(trainset[,-1]), label = train_labs)
      xgb_val <- xgb.DMatrix(data = as.matrix(testset[,-1]), label = val_labs)
      # Set parameters(default)
      numberOfClasses <- length(unique(trainset$Y))
      #parameters
      params <- list(booster = "gbtree",
                       objective = "multi:softprob",
                       num_class = numberOfClasses,
                       eval_metric = "mlogloss",
                       eta=as.numeric(eta.xb),
                       gamma=as.numeric(gamma.xb),
                       max_depth=as.numeric(max_depth.xb))


      # Create the model
      xgb_model <- xgb.train(params = params, data = xgb_train, nrounds = nrounds.it)
      # Predict for validation set
      xgb_val_preds <- predict(xgb_model, newdata = xgb_val,na.action = na.pass)
      #predictionsTree <- predict(treeFit, testdata,na.action = na.pass)
      xgb_val_out <- matrix(xgb_val_preds, nrow = numberOfClasses, ncol = length(xgb_val_preds) / numberOfClasses) %>%
        t() %>%
        data.frame() %>%
        mutate(max = max.col(., ties.method = "last"), label = val_labs + 1)
      # Confustion Matrix
      xgb_val_conf <- table(true = val_labs + 1, pred = xgb_val_out$max)
      # Function to compute classification error
      classification_error <- function(conf_mat) {
        conf_mat = as.matrix(conf_mat)
        error = 1 - sum(diag(conf_mat)) / sum(conf_mat)
        return (error)
      }

      cat("XGB Validation Classification Error Rate:", classification_error(xgb_val_conf), "\n")

      #check if the number of levels are the same or not

      if (identical(levels(factor(testset$label)), levels(factor(xgb_val_out$max)))==F){
        #solucion buena
        #https://www.reddit.com/r/Rlanguage/comments/733g6p/predicting_with_caret_confusionmatrix_giving_me/

        #join the two Y reals - Y predicted: \\\-\\\
        tot.factor <- c(as.character(xgb_val_out$label),as.character(xgb_val_out$max))
        tot.factor  <- as.factor(tot.factor )

        #tot.factor<-factor(cbind(xgb_val_out$label,xgb_val_out$max))

        #solucion cutre
        predict.y<- as.factor(xgb_val_out$max) #TODOS LOS NIVELES DEL Y ORIGINAL
        levels(predict.y)<-c(levels(factor(tot.factor)))

        xgb_val_conf2 <- confusionMatrix(factor(xgb_val_out$label),
                                         predict.y,
                                         mode = "everything")
      }

      if (identical(levels(factor(xgb_val_out$label)), levels(factor(xgb_val_out$max)))==T){
        # Automated confusion matrix using "caret"
        xgb_val_conf2 <- confusionMatrix(factor(xgb_val_out$label),
                                         factor(xgb_val_out$max),
                                         mode = "everything")
      }




      #print(xgb_val_conf2)
      #accuracy-SENSIBILITY-SPECIFICITY
      my.array.validation.model[i,13] <- as.numeric(xgb_val_conf2$overall[1])
      my.array.validation.model[i,14] <- as.numeric(xgb_val_conf2$overall[2])
      my.array.validation.model[i,15] <- as.numeric(xgb_val_conf2$byClass[1]) #sens
      my.array.validation.model[i,16] <- as.numeric(xgb_val_conf2$byClass[2])#specificity
      #xgboost at:
      #https://www.r-bloggers.com/an-introduction-to-xgboost-r-package/
      #https://www.analyticsvidhya.com/blog/2016/01/xgboost-algorithm-easy-steps/
      #optimizacion de los parametros
      #https://analyticsdataexploration.com/xgboost-model-tuning-in-crossvalidation-using-caret-in-r/

      #neural nets
      #https://www.r-bloggers.com/multilabel-classification-with-neuralnet-package/
      ideal1 <- class.ind(trainset$Y)
      irisANN = nnet(trainset[,-1], ideal1, size=2, softmax=TRUE)
      pred_ANN1 <-predict(irisANN, testset[,-1], type="class")
      #accuracy
      #check if the number of cattegories are the same
      if (identical(levels(factor(pred_ANN1)), levels(factor(testset$Y)))==F){
        #solucion buena
        #https://www.reddit.com/r/Rlanguage/comments/733g6p/predicting_with_caret_confusionmatrix_giving_me/

        #join the two Y reals - Y predicted: \\\-\\\
        #tot.factor1<-as.factor(cbind(pred_ANN1,testset$Y))

        #solucion cutre
        predict.yy<- as.factor(pred_ANN1)
        levels(predict.yy)<-c(levels(factor(testset$Y )))
        #levels(testset$Y)<-c(levels(factor(tot.factor1)))
        aa_ANN<-(confusionMatrix(predict.yy, testset$Y ))
      }
      if (identical(levels(factor(pred_ANN1)), levels(factor(testset$Y)))==T){
        #NUMERO DE NIVELES IGUAles
        aa_ANN<-(confusionMatrix(as.factor(pred_ANN1), testset$Y ))
      }
      #ANN.accuracy <- aa_ANN$overall[1]
      #print("ANN discriminant")
      #print(aa_ANN)
      #accuracy-SENSIBILITY-SPECIFICITY
      my.array.validation.model[i,17] <- as.numeric(aa_ANN$overall[1])
      my.array.validation.model[i,18] <- as.numeric(aa_ANN$overall[2])
      my.array.validation.model[i,19] <- as.numeric(aa_ANN$byClass[1]) #sens
      my.array.validation.model[i,20] <- as.numeric(aa_ANN$byClass[2])#specificity

    }
    options(show.error.messages=T) # turn off

    #si se quiere visualizar los graficos o no
    if(print.image==T){
      library(gplots)
        #my.array.validation.model
        #my.array.validation.model
        #library(gplots)
        #SVM-----------------------
        par(mfrow=c(4,1))
        #accuracy
        if(all(is.na(my.array.validation.model[,1]))==T){my.array.validation.model[,1]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,1], xlab="Iterations SVM", ylab="Accuracy(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION SVM")
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,1],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,1],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text1, side = 3)
        #kappa----
        if(all(is.na(my.array.validation.model[,2]))==T){my.array.validation.model[,2]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,2], xlab="Iterations SVM", ylab="kappa(testset) n=50 sets")
        title(main = "kappa SVM")
        text2<-paste( "MEAN kappa: [Mean=", round(mean(my.array.validation.model[,2],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,2],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text2, side = 3)
        #sensibility -----
        if(all(is.na(my.array.validation.model[,3]))==T){my.array.validation.model[,3]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,3], xlab="Iterations SVM", ylab="SENSIBILITY(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION SVM")
        text3<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,3],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,3],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text3, side = 3)
        #specificity----
        if(all(is.na(my.array.validation.model[,4]))==T){my.array.validation.model[,4]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,4], xlab="Iterations SVM", ylab="SPECIFICITY(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION SVM")
        text4<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,4],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,4],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text4, side = 3)


        #KERNEL-----------------------
        par(mfrow=c(4,1))
        #accuracy
        if(all(is.na(my.array.validation.model[,5]))==T){my.array.validation.model[,5]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,5], xlab="Iterations KERNEL", ylab="Accuracy(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION KERNEL-DISCRIM")
        text5<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,5],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,5],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text5, side = 3)
        #kappa
        if(all(is.na(my.array.validation.model[,6]))==T){my.array.validation.model[,6]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,6], xlab="Iterations KERNEL", ylab="kappa(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION KERNEL-DISCRIM")
        text6<-paste( "MEAN kappa: [Mean=", round(mean(my.array.validation.model[,6],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,6],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text6, side = 3)
        #sensibility -----
        if(all(is.na(my.array.validation.model[,7]))==T){my.array.validation.model[,7]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,7], xlab="Iterations SVM", ylab="SENSIBILITY(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION KERNEL-DISCRIM")
        text7<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,7],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,7],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text7, side = 3)
        #specificity----
        if(all(is.na(my.array.validation.model[,8]))==T){my.array.validation.model[,8]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,8], xlab="Iterations SVM", ylab="SPECIFICITY(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION KERNEL-DISCRIM")
        text8<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,8],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,8],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text8, side = 3)

        #LDA-----------------------
        par(mfrow=c(4,1))
        #accuracy
        if(all(is.na(my.array.validation.model[,9]))==T){my.array.validation.model[,9]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,9], xlab="Iterations KERNEL", ylab="Accuracy(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION LDA")
        text9<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,9],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,9],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text9, side = 3)
        #kappa
        if(all(is.na(my.array.validation.model[,10]))==T){my.array.validation.model[,10]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,10], xlab="Iterations KERNEL", ylab="KAPPA(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION LDA")
        text10<-paste( "MEAN kappa: [Mean=", round(mean(my.array.validation.model[,10],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,10],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text10, side = 3)
        #sensibility -----
        if(all(is.na(my.array.validation.model[,11]))==T){my.array.validation.model[,11]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,11], xlab="Iterations SVM", ylab="SENSIBILITY(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION LDA")
        text11<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,11],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,11],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text11, side = 3)
        #specificity----
        if(all(is.na(my.array.validation.model[,12]))==T){my.array.validation.model[,12]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,12], xlab="Iterations SVM", ylab="SPECIFICITY(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION LDA")
        text12<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,12],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,12],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text12, side = 3)

        #xgboost---------------------------------
        par(mfrow=c(4,1))
        #accuracy
        if(all(is.na(my.array.validation.model[,13]))==T){my.array.validation.model[,13]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,13], xlab="Iterations KERNEL", ylab="Accuracy(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION XBOOST")
        text13<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,13],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,13],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text13, side = 3)
        #KAPPA
        if(all(is.na(my.array.validation.model[,14]))==T){my.array.validation.model[,14]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,14], xlab="Iterations KERNEL", ylab="KAPPA(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION XBOOST")
        text14<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,14],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,14],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text14, side = 3)
        #sensibility -----
        if(all(is.na(my.array.validation.model[,15]))==T){my.array.validation.model[,15]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,15], xlab="Iterations SVM", ylab="SENSIBILITY(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION XBOOST")
        text15<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,15],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,15],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text15, side = 3)
        #specificity----
        if(all(is.na(my.array.validation.model[,16]))==T){my.array.validation.model[,16]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,16], xlab="Iterations SVM", ylab="SPECIFICITY(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION XBOOST")
        text16<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,16],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,16],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text16, side = 3)

        #ANN---------------------------------
        par(mfrow=c(4,1))
        #accuracy
        if(all(is.na(my.array.validation.model[,17]))==T){my.array.validation.model[,17]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,17], xlab="Iterations ANN", ylab="Accuracy(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION ANN")
        text17<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,17],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,17],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text17, side = 3)
        #KAPPA
        if(all(is.na(my.array.validation.model[,18]))==T){my.array.validation.model[,18]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,18], xlab="Iterations ANN", ylab="KAPPA(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION ANN")
        text18<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,18],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,18],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text18, side = 3)
        #sensibility -----
        if(all(is.na(my.array.validation.model[,19]))==T){my.array.validation.model[,19]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,19], xlab="Iterations ANN", ylab="SENSIBILITY(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION ANN")
        text19<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,19],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,19],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text19, side = 3)
        #specificity----
        if(all(is.na(my.array.validation.model[,20]))==T){my.array.validation.model[,20]=0} #filtro para evitar errores con los NA
        bandplot(x=rep(1:num.iter,1), my.array.validation.model[,20], xlab="Iterations ANN", ylab="SPECIFICITY(testset) n=50 sets")
        title(main = "VALIDATION PREDICTION ANN")
        text20<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,20],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,20],na.rm=TRUE),2), "]" ,sep = "")
        #text1
        mtext(text20, side = 3)
    }
    #SOLO CALCULAR LOS ESTADISTICOS E IMPRIMIR...
    if(print.image==F){
        text1<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,1],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,1],na.rm=TRUE),2), "]" ,sep = "")
        text2<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,2],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,2],na.rm=TRUE),2), "]" ,sep = "")
        text3<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,3],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,3],na.rm=TRUE),2), "]" ,sep = "")
        text4<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,4],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,4],na.rm=TRUE),2), "]" ,sep = "")

        text5<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,5],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,5],na.rm=TRUE),2), "]" ,sep = "")
        text6<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,6],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,6],na.rm=TRUE),2), "]" ,sep = "")
        text7<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,7],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,7],na.rm=TRUE),2), "]" ,sep = "")
        text8<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,8],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,8],na.rm=TRUE),2), "]" ,sep = "")

        text9<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,9],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,9],na.rm=TRUE),2), "]" ,sep = "")
        text10<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,10],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,10],na.rm=TRUE),2), "]" ,sep = "")
        text11<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,11],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,11],na.rm=TRUE),2), "]" ,sep = "")
        text12<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,12],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,12],na.rm=TRUE),2), "]" ,sep = "")

        text13<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,13],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,13],na.rm=TRUE),2), "]" ,sep = "")
        text14<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,14],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,14],na.rm=TRUE),2), "]" ,sep = "")
        text15<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,15],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,15],na.rm=TRUE),2), "]" ,sep = "")
        text16<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,16],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,16],na.rm=TRUE),2), "]" ,sep = "")

        text17<-paste( "MEAN ACCURACY: [Mean=", round(mean(my.array.validation.model[,17],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,17],na.rm=TRUE),2), "]" ,sep = "")
        text18<-paste( "MEAN KAPPA: [Mean=", round(mean(my.array.validation.model[,18],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,18],na.rm=TRUE),2), "]" ,sep = "")
        text19<-paste( "MEAN SENSIBILITY: [Mean=", round(mean(my.array.validation.model[,19],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,19],na.rm=TRUE),2), "]" ,sep = "")
        text20<-paste( "MEAN SPECIFICITY: [Mean=", round(mean(my.array.validation.model[,20],na.rm=TRUE),2), ",sd=", round(sd(my.array.validation.model[,20],na.rm=TRUE),2), "]" ,sep = "")


        print("RESULTS CLASSIFICATION --------")
        print("SVM-----------------------")
        print(text1)
        print(text2)
        print(text3)
        print(text4)

        print("KERNEL-----------------------")
        print(text5)
        print(text6)
        print(text7)
        print(text8)

        print("LDA-----------------------")
        print(text9)
        print(text10)
        print(text11)
        print(text12)

        print("xgboost---------------------------------")
        print(text13)
        print(text14)
        print(text15)
        print(text16)

        print("ANN---------------------------------")
        print(text17)
        print(text18)
        print(text19)
        print(text20)
    }
    options(show.error.messages=T) # turn off

  }
}

