
#toni monleon (26-08-2019)

##################################################################################################
# ESTIMATE PARAMETERS OF A WEIBULL OF 4 PARAMETERS:
# FUNCTION WEIBULL: SATURATIVE FUNCTION WITH MULTIPLE USES
#################################################################################################
#' Estimate parameters of a Weibull(4parameters)  function with multiple purposes
#'
#' @param X vector X for the function weibull4p
#' @param Y vector Y for the function weibull4p
#' @param a parameter a for a Weibull-4p
#' @param b parameter b for a Weibull-4p
#' @param c parameter c for a Weibull-4p
#' @param d parameter d for a Weibull-4p
#' @param force.a a is a constant (defect = F-> a is a free parameter)
#' @param Print.curve parameter
#' @param brfr.it=10 number of iterations for the numerical method
#' @return print a.w4p, b.w4p, c.w4p, d.w4p, x.for.maximum.90_1, x.for.maximum.95_1, x.for.maximum.99_1, vec.curveXY, good.fit.model
#' @export
#' #'
#' @examples
#' # Represent plot where X are number of genetic reads in RNA biological samples and Y are number of genes (bioinformatic example)
#' X<-c(1.0e+05, 2.0e+05, 3.0e+05, 4.0e+05, 5.0e+05, 6.0e+05, 7.0e+05,
#'     8.0e+05, 9.0e+05, 1.0e+06, 2.0e+06)
#' Y<-c( 6953.333, 12418.333, 17158.000, 21572.667, 25482.000,
#'      29164.333, 32683.333, 36010.000, 39040.000, 41989.000,
#'      42071.000)
#' plot(X,Y, xlim=c(0,15e6), ylim=c(0,1.5*max(Y)),col="red", main="Projection plot and parameters estimation", sub="using a Weibull function 4p")
#'
#' # Estimate a Weibull 4p to project the data for a infinite X and estimate 90,95 and 99% to reach maximum Y
#' library(rcompanion)
#' aaa<-Weibull4p.monle1(X<-c(1.0e+05, 2.0e+05, 3.0e+05, 4.0e+05, 5.0e+05, 6.0e+05, 7.0e+05,
#'                    8.0e+05, 9.0e+05, 1.0e+06, 2.0e+06),
#'               Y<-c( 6953.333, 12418.333, 17158.000, 21572.667, 25482.000,
#'                     29164.333, 32683.333, 36010.000, 39040.000, 41989.000,
#'                     42071.000), a=max(Y), b=a, c=3, d=2, Print.curve = T, force.a = F)
#' abline(v=aaa[c(5,6,7)],col="green",lwd=0.5, lty =2)
#'  #a, b, c, d are priori parameters of the 4p weibull function.
#' # Print parameters and information: a.w4p, b.w4p, c.w4p, d.w4p, x.for.maximum.90_1, x.for.maximum.95_1, x.for.maximum.99_1, vec.curveXY, good.fit.model
#' aaa
#'

#' @references
#' CI Rodríguez-Casado, A Monleon-Getino, M Cubedo, M Ríos- Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32
#'
#' Antonio Monleon-Getino; Clara Isabel Rodriguez Casado; Javier Mendez. 2017. How to calculate the number of samples in the design of pre/pro-biotics studies (metagenomic studies)
#' Conference: III WorkShop anual Insa-UB
#' https://www.researchgate.net/publication/321168771_How_to_calculate_the_number_of_samples_in_the_design_of_prepro-biotics_studies_metagenomic_studies
#' Monleon-Getino T. Frias-Lopez, T. 2020. A priori estimation of sequencing effort in complex microbial metatranscriptomes. Ecology and evolution (pending of publication).
#' Monleon-Getino T. 2018. Quantitative metagenomics. Lulu Press inc.



Weibull4p.monle1<- function(X, Y, a, b = a, c, d, Print.curve = T, brfr.it=10, force.a = F){

  options(show.error.messages=T) # turn off

  library(minpack.lm)
  library(nls2)
  library(rcompanion)
  #library(forecast)

  #parametro a, no es una constante, sino variable y busca el mejor
  if(force.a == F){
        out222 <- try(model.w4p <- nls2(Y ~ SSweibull(X, a, b, c,d)))
        if (substr(out222[1],1,5) != "Error"){
          a.w4p =as.numeric(coef(model.w4p)[1])
          b.w4p =as.numeric(coef(model.w4p)[2])
          c.w4p =as.numeric(coef(model.w4p)[3])
          d.w4p =as.numeric(coef(model.w4p)[4])
          #print("nls2 SSweibull")
          #gooness of fit (R2)
          library(rcompanion)
          good.fit.model<-accuracy(list(model.w4p),
                                   plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
          #print("Efron.r.squared: weibull4p nls2")
          #print(good.fit.model)

          #Interval of prediction of CI95% -18.03.20--------------------------------------------
          #predCI <- predict(as.lm.nls(model.w4p), interval = "confidence", level = 0.95)
          #print("s2")
          #plot the CI95% Weibull model
          #xx<- myfit.data.frame$time
          #lines(X,predCI[,2],col="blue",lty=2)
          #lines(X,predCI[,3],col="blue",lty=2)--------------------------------------------

        }
        if (substr(out222[1],1,5) == "Error"){
          a.w4p =NA
          b.w4p =NA
          c.w4p =NA
          d.w4p =NA
          #sugiere un nuevo punto a, a ver si es mejor y quizas unos intervalos de confianza?
          #print("two: nlsLM with grid parameters")
          out333 <- try(model.SSweibull.W1 <- nlsLM(formula = Y ~ a-b*exp(-exp(c)*X^d),
                                                    control = nls.lm.control(ftol = 1e-5, ptol = 1e-5),
                                                    start = list(a=a, b=a, c=c, d=d),
                                                    lower = c(a=0, b = 0, c = -Inf, d = -Inf),
                                                    upper = c(a = Inf,  b = Inf, c = Inf, d = Inf)))

          if (substr(out333[1],1,5) != "Error"){
            a.w4p<-as.numeric(coef(model.SSweibull.W1)[1])
            b.w4p =as.numeric(coef(model.SSweibull.W1)[2])
            c.w4p =as.numeric(coef(model.SSweibull.W1)[3])
            d.w4p =as.numeric(coef(model.SSweibull.W1)[4])
            #print("cuatro")

            #gooness of fit (R2)
            library(rcompanion)
            good.fit.model<-accuracy(list(model.SSweibull.W1),
                                     plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
            #print("Efron.r.squared: weibull4p nls2")
            #print(good.fit.model)

            #Interval of prediction of CI95% -18.03.20--------------------------------------------
            #predCI <- predict(as.lm.nls(model.SSweibull.W1), interval = "confidence", level = 0.95)
            #print("s2")
            #plot the CI95% Weibull model
            #xx<- myfit.data.frame$time
            #lines(X,predCI[,2],col="blue",lty=2)
            #lines(X,predCI[,3],col="blue",lty=2) #--------------------------------------------
          }
          if (substr(out333[1],1,5) == "Error"){
            print("Force brute algorithm nls2. Long time...Wait a moment")
            fo <- Y ~ a-b*exp(-exp(c)*X^d)
            st1 <- expand.grid(a = seq(0, a*3, len = brfr.it),b = seq(0, a*3, len = brfr.it), c = seq(-500, 0, len = brfr.it), d=seq(0.5, 50, len=brfr.it))
            out2222 <- try(model.SSweibull.W3 <- nls2(fo, start = st1, algorithm = "brute-force"))
            #print("five: brute force algorithm")

            if (substr(out2222[1],1,5) != "Error"){
              a.w4p<-as.numeric(coef(model.SSweibull.W3)[1])
              b.w4p =as.numeric(coef(model.SSweibull.W3)[2])
              c.w4p =as.numeric(coef(model.SSweibull.W3)[3])
              d.w4p =as.numeric(coef(model.SSweibull.W3)[4])
              print("seis")

              #gooness of fit (R2)
              #library(rcompanion)
              good.fit.model<-accuracy(list(model.SSweibull.W3),
                                       plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
              #print("Efron.r.squared: weibull4p nls2")
              #print(good.fit.model)

              #Interval of prediction of CI95% -18.03.20--------------------------------------------
              #predCI <- predict(as.lm.nls(model.SSweibull.W3), interval = "confidence", level = 0.95)
              #print("ci95%")
              #plot the CI95% Weibull model
              #xx<- myfit.data.frame$time
              #lines(X,predCI[,2],col="blue",lty=2)
              #lines(X,predCI[,3],col="blue",lty=2)--------------------------------------------

            }


          }


        }
  }
  #el parametro a, la asindota si es una constante
  if(force.a ==T){
    print("Force brute algorithm nls2. Long time...Wait a moment")
    fo <- Y ~ a-b*exp(-exp(c)*X^d)
    st1 <- expand.grid(a = a,b = seq(0, a*3, len = brfr.it), c = seq(-500, 0, len = 2*brfr.it), d=seq(0.5, 50, len=2*brfr.it))
    out2222 <- try(model.SSweibull.W3 <- nls2(fo, start = st1, algorithm = "brute-force"))
    #print("cinco")

    if (substr(out2222[1],1,5) != "Error"){
      a.w4p<-as.numeric(coef(model.SSweibull.W3)[1])
      b.w4p =as.numeric(coef(model.SSweibull.W3)[2])
      c.w4p =as.numeric(coef(model.SSweibull.W3)[3])
      d.w4p =as.numeric(coef(model.SSweibull.W3)[4])
      #print("seis")

      #gooness of fit (R2)
      #library(rcompanion)
      good.fit.model<-accuracy(list(model.SSweibull.W3),
                               plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
      #print("Efron.r.squared: weibull4p nls2: ")
      #print(good.fit.model)
      #print(good.fit.model)

      #Interval of prediction of CI95% -18.03.20--------------------------------------------
      #tt <- seq(0, 300, length = 101)
      #lines(tt, predict(model.SSweibull.W3, list(X = tt), interval = "confidence", level = 0.95),col="red")
      #aa<-predict(model.SSweibull.W3, list(X = tt), interval = "confidence", level = 0.95)
      #predCI <- predict(as.lm.nls(model.SSweibull.W3), interval = "confidence", level = 0.95)
      #print("CI95%")

      #newdat <- data.frame(X = c(X,48:300), Y = c(Y,rep(NA,length(c(48:300)))))
      #pred1 <- predict(model.SSweibull.W3, newdat)

      #predCI1 <- predict(as.lm.nls(model.SSweibull.W3), newdata=newdat, interval = "confidence", level = 0.95)
      #plot the CI95% Weibull model
      #xx<- myfit.data.frame$time
      #lines(X,predCI[,2],col="blue",lty=2)
      #lines(X,predCI[,3],col="blue",lty=2)--------------------------------------------

    }


  }


  if(is.na(a.w4p)==F){

    #numero de reads para el 95%---------------------
    #metodo analitico-con la inversa
    #analisis de la curva: X para 90,95 y 99% maximo
    #grafica en pantalla estimada a partir del primer millon 1M
    #curve( (Asym1.es.upr)-Drop.upr*exp(-exp(lrc.upr)*x^pwr.upr), col = "red", lty=2, add = TRUE)
    ################ CALCULO DEL ESFUERZO 90 Y 95% DEL MAXIMO DE LOS GENES ##########################
    #esfuerzo para el 90% del maximo de genes
    #La funcion inversa es: x <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
    #90% del esfuerzo maximo
    y <- 0.90*a.w4p
    x.para.maximo.90_1<- as.numeric((log((a.w4p-y)/b.w4p)/-exp(c.w4p))^(1/d.w4p) )
    #95% esfuerzo maximo
    y <- 0.95*a.w4p
    x.para.maximo.95_1<- as.numeric((log((a.w4p-y)/b.w4p)/-exp(c.w4p))^(1/d.w4p) )
    #99% esfuerzo maximo
    y <- 0.99*a.w4p
    x.para.maximo.99_1<- as.numeric((log((a.w4p-y)/b.w4p)/-exp(c.w4p))^(1/d.w4p) )

    #print curve
    if(Print.curve == T){
      #plot(X,Y, xlim=c(0,max(x.para.maximo.99, X)), ylim=c(0,1.5*a.w4p))
      curve(a.w4p-b.w4p*exp(-exp(c.w4p)*x^d.w4p), col = "blue", lty=2, lwd=1, add = TRUE)

      #intervalod e confianza del 95%
      #lines(X,predCI[,2],col="blue",lty=2)
      #lines(X,predCI[,3],col="blue",lty=2) #--------------------------------------------
    }
    #vector resultante (curva weibull)
    color.white=rgb(0,0,0,alpha=0) #para aumentar la transparencia
    vec.curve<-curve(a.w4p-b.w4p*exp(-exp(c.w4p)*x^d.w4p), col = color.white, lty=0, lwd=1, add = TRUE,n=50000)

    #metodo numerico (sale regular): consiste en aproximar el valor
    #reads.90.otu<-a.w4p*0.9
    #reads.95.otu<-a.w4p*0.95
    #reads.99.otu<-a.w4p*0.99
    #mat.res<-curva.rarefaccion.predicha.weibull
    #for (i in 1:length(vec.curve$y)){
    #i<-1
    #y otu // x son reads
    #reads para cobertura segun ToniM
    #  if(vec.curve$y[i]<=reads.90.otu){ x.para.maximo.90=vec.curve$x[i]}
    #  if(vec.curve$y[i]<=reads.95.otu){ x.para.maximo.95=vec.curve$x[i]}
    #  if(vec.curve$y[i]<=reads.99.otu){ x.para.maximo.99=vec.curve$x[i]}
    #}
    color.white=rgb(0,0,0,alpha=0) #para aumentar la transparencia
    vec.curve<-curve(a.w4p-b.w4p*exp(-exp(c.w4p)*x^d.w4p), col = color.white, lty=0, lwd=1, add = TRUE)




  }
  #todo mal no sale nada de nada
  if(is.na(a.w4p)==T){
    vec.curve=NA
  }

  #return(list(a.w4p, b.w4p, c.w4p, d.w4p, x.para.maximo.90_1, x.para.maximo.95_1, x.para.maximo.99_1, vec.curve, good.fit.model, predCI))
  return(list(a.w4p, b.w4p, c.w4p, d.w4p, x.para.maximo.90_1, x.para.maximo.95_1, x.para.maximo.99_1, vec.curve, good.fit.model))
}

#X, Y, a, b = a, c, d, Print.curve = T
#X<-c(1.0e+05, 2.0e+05, 3.0e+05, 4.0e+05, 5.0e+05, 6.0e+05, 7.0e+05,
#                    8.0e+05, 9.0e+05, 1.0e+06, 2.0e+06)
#Y<-c( 6953.333, 12418.333, 17158.000, 21572.667, 25482.000,
#                29164.333, 32683.333, 36010.000, 39040.000, 41989.000,
#                42071.000)
#plot(X,Y, xlim=c(0,15e6), ylim=c(0,1.5*max(Y)))
#aaa<-Weibull4p(X<-c(1.0e+05, 2.0e+05, 3.0e+05, 4.0e+05, 5.0e+05, 6.0e+05, 7.0e+05,
#               8.0e+05, 9.0e+05, 1.0e+06, 2.0e+06),
#          Y<-c( 6953.333, 12418.333, 17158.000, 21572.667, 25482.000,
#                29164.333, 32683.333, 36010.000, 39040.000, 41989.000,
#                42071.000), a = 42000, b = 42000, c=-10, d=0.9,Print.curve = T)
