
#toni monleon (5-4-2019) (8-11-2017)

##################################################################################################
# #EXPLORATORY DATA AND MDS, DISCRIMINANT BETWEEN GROUPS:
#  dimension reduction based on a TSNE (T-Distributed Stochastic Neighbor Embedding for R (t-SNE))
#################################################################################################
#' Dimension reduction of a frequency matrix based on a TSNE (T-Distributed Stochastic Neighbor Embedding for R (t-SNE))
#'
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param use.conditions use experimental conditions (levels of a factor)
#' @param perc percentage of sample richness permitted (cuttoff)
#' @param KL Kulvart Leivert divergence or Battachryya distance
#' @param OTU if OTU = T, matrix of OTUS in the rows, OTU = F matrix of samples in columns
#' @param label.yes microorganism net complexity
#' @param vector.labels parameter
#' @param nrows number of rows at maximum to represent (OTU)
#' @param subgroup.kmeans do a SVD-KMEANS analysis of subgroups
#' @param K number of subgroups at SVD
#' @param vector.labels2 labels for subgroups of columns (samples)
#' @param DISCRI Do a LDA discriminant analysis when OTU = F, for samples
#' @return print of MDS results
#' @export
#' #'
#' @examples
#'library(HMP) #16S rRNA Sequencing Data from the Human Microbiome Proje
#'data(saliva) #saliva metagenomic test (sample vs taxa)
#'saliva1<- data.frame(saliva)
#'Lines.TSNE(matriu=saliva1, labs=rownames(saliva1),perpl = 30,max_iter = 2000,epoch = 100)

#'
#' @references
#' CI Rodríguez-Casado, A Monleon-Getino, M Cubedo, M Ríos- Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32



#do a dimension reduction based on a TSNE (T-Distributed Stochastic Neighbor Embedding for R (t-SNE))
Lines.TSNE <- function(matriu, labs, perpl=50,  k = 2, initial_dims = 30,  epoch=100, max_iter = 100){
  library(tsne)

  #tsne
  #see https://cran.r-project.org/web/packages/tsne/tsne.pdf
  #library(tsne)
  ## Not run:
  ## colors = rainbow(length(unique(iris$Species)))
  ## names(colors) = unique(iris$Species)
  ## ecb = function(x,y){ plot(x,t='n'); text(x,labels=iris$Species, col=colors[iris$Species]) }
  ## tsne_iris = tsne(iris[,1:4], epoch_callback = ecb, perplexity=50)
  # compare to PCA
  ## dev.new()
  ## pca_iris = princomp(iris[,1:4])$scores[,1:2]
  ## plot(pca_iris, t='n')
  ## text(pca_iris, labels=iris$Species,col=colors[iris$Species])
  ## End(Not run)

  colors = rainbow(length(unique(labs)))
  names(colors) = unique(labs)
  ecb = function(x,y){ plot(x,t='n'); text(x,labels=labs, col=colors[labs]) }
  tsne_iris = tsne(matriu, epoch_callback=ecb, perpl=perpl, k = k, initial_dims = initial_dims,  epoch=epoch, max_iter = max_iter)
}





