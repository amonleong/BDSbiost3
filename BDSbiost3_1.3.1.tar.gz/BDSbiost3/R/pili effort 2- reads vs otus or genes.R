#############################################################################3
# SAMPLE SIZE IN METAGENOMICS: READS VS OTUS/genes
##############################################################################

# Toni Monleon. Biost3. 8-2017


#############################################################
# Functions to sample size and rarefaction in metagenomics
#############################################################
#' Sampling deepthness: number of reads (hits/frequencies) to reach saturation: reads vs OTU/genes
#' Richness analysis and effort sampling in function of number reads (frequencies/hits)
#'
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @return Plot for richness analysis and effort sampling in function of number reads.
#' @export
#' #'
#' @examples

#' ###########################################################################
#' # FIRST EXAMPLE: SIMULATION OF A NON SATURATIVE CURVE GENES VS READS
#' ###########################################################################
#' #Generate Multinomial Random Variables With Varying Probabilities
#' num_genes<- 10000
#' total_reads <- 2000
#' number_of_samples <- 5
#' my_prob <- c(rep(1/num_genes, num_genes) ) #uniform distribution

#' #generate a matrix
#' experiment <- (rmultinom(n=number_of_samples, size=total_reads, prob=my_prob))
#' experiment
#' PILI3(matriu = experiment) #example of non saturation and poor deepthness
#'
#'
#' ###########################################################################
#' # SECOND EXAMPLE: SIMULATION OF A NON SATURATIVE CURVE GENES VS READS
#' ###########################################################################
#'
#' #Generate Multinomial Random Variables With Varying Probabilities
#' num_genes<- 5000
#' total_reads <- 200
#' number_of_samples <- 5
#' my_prob <- c(rep(1/num_genes, num_genes) ) #uniform distribution

#' #generate a matrix
#' experiment <- (rmultinom(n=number_of_samples, size=total_reads, prob=my_prob))
#' experiment
#' PILI3(matriu = experiment) #example of non saturation and poor deepthness

#' ###########################################################################
#' # THIRD EXAMPLE: SIMULATION OF A SATURATIVE CURVE GENES VS READS
#' ###########################################################################
#'
#' #Generate Multinomial Random Variables With Varying Probabilities
#' num_genes<- 12000
#' total_reads <- 50000
#' number_of_samples <- 5
#' my_prob <- c(rep(1/num_genes, num_genes) ) #uniform distribution

#' #generate a matrix
#' experiment <- (rmultinom(n=number_of_samples, size=total_reads, prob=my_prob))
#' experiment
#' PILI3(matriu = experiment) #example of non saturation and poor deepthness


#' @references
#' Monleon-Getino T. Frias-Lopez, T. 2020. A priori estimation of sequencing effort in complex microbial metatranscriptomes. Ecology and evolution (pending of publication).
#' Monleon-Getino T. 2018. Quantitative metagenomics. Lulu Press inc.


##########################################
# analisis de los reads: profundidad genica
################################################################
##################################################################
#FUNCION QUE HACE TODO A LA VEZ, INPUT=MATRIZ METAGENOMICA Y OUTPUT: GRAFICO Y ANALISIS DE ESFUERZO
##################################################################
PILI3<-function(matriu){



  a90<<-0 #90% maximo
  a95<<-0 #95% maximo
  a99<<-0 #99% maximo
  #BB<-PILI2.MetagenSample.size(matriu=matriu, num.remuestras=5)
  #libreria BDSbiost3 para el calculo de riqueza y effort sampling
  a.out<-PILI3.MetagenSample.size.READS.OTU.GENES(matriu=matriu)

  #grafico de resultado rads vs otu
  p<-ggiNEXT1.iNEXT(x=a.out[[1]], type=1, facet.var="site") +
    geom_vline(xintercept=a90, col="green") +
    geom_vline(xintercept=a95, col="green") +
    geom_vline(xintercept=a99, col="green")
  p + annotate("text", x = c(a90,a95, a99), y = c(0,0,0), label = c("90%", "95%", "99%"))

  #return
  #return(c(a.out[[2]],a.out[[3]],a.out[[4]],a.out[[5]],a.out[[6]]))

}





################################################################################
#1-funcion para el calculo de  ESFUERZO EN READS VS (OTU/GENES)
################################################################################

#FUNCION A CARGAR PARA EL GRAFICO
ggiNEXT1.iNEXT<-function (x, type = 1, se = TRUE, facet.var = "none", color.var = "site",
                          grey = FALSE)
{
  TYPE <- c(1, 2, 3)
  SPLIT <- c("none", "order", "site", "both")
  if (is.na(pmatch(type, TYPE)) | pmatch(type, TYPE) == -1)
    stop("invalid plot type")
  if (is.na(pmatch(facet.var, SPLIT)) | pmatch(facet.var, SPLIT) ==
      -1)
    stop("invalid facet variable")
  if (is.na(pmatch(color.var, SPLIT)) | pmatch(color.var, SPLIT) ==
      -1)
    stop("invalid color variable")
  type <- pmatch(type, 1:3)
  facet.var <- match.arg(facet.var, SPLIT)
  color.var <- match.arg(color.var, SPLIT)
  if (facet.var == "order")
    color.var <- "site"
  if (facet.var == "site")
    color.var <- "order"
  options(warn = -1)
  z <- fortify(x, type = type)
  options(warn = 0)
  if (ncol(z) == 7) {
    se <- FALSE
  }
  datatype <- unique(z$datatype)
  if (color.var == "none") {
    if (levels(factor(z$order)) > 1 & "site" %in% names(z)) {
      warning("invalid color.var setting, the iNEXT object consists multiple sites and orders, change setting as both")
      color.var <- "both"
      z$col <- z$shape <- paste(z$site, z$order, sep = "-")
    }
    else if ("site" %in% names(z)) {
      warning("invalid color.var setting, the iNEXT object consists multiple orders, change setting as order")
      color.var <- "site"
      z$col <- z$shape <- z$site
    }
    else if (levels(factor(z$order)) > 1) {
      warning("invalid color.var setting, the iNEXT object consists multiple sites, change setting as site")
      color.var <- "order"
      z$col <- z$shape <- factor(z$order)
    }
    else {
      z$col <- z$shape <- rep(1, nrow(z))
    }
  }
  else if (color.var == "order") {
    z$col <- z$shape <- factor(z$order)
  }
  else if (color.var == "site") {
    if (!"site" %in% names(z)) {
      warning("invalid color.var setting, the iNEXT object do not consist multiple sites, change setting as order")
      z$col <- z$shape <- factor(z$order)
    }
    z$col <- z$shape <- z$site
  }
  else if (color.var == "both") {
    if (!"site" %in% names(z)) {
      warning("invalid color.var setting, the iNEXT object do not consist multiple sites, change setting as order")
      z$col <- z$shape <- factor(z$order)
    }
    z$col <- z$shape <- paste(z$site, z$order, sep = "-")
  }
  z$lty <- factor(z$method, levels=unique(c("interpolated", "observed", "extrapolated"),
                                          c("interpolation", "interpolation", "extrapolation")))
  z$col <- factor(z$col)
  data.sub <- z[which(z$method == "observed"), ]
  g <- ggplot(z, aes_string(x = "x", y = "y", colour = "col")) +
    geom_point(aes_string(shape = "shape"), size = 5, data = data.sub)
  g <- g + geom_line(aes_string(linetype = "lty"), lwd = 1.5) +
    guides(linetype = guide_legend(title = "Method"), colour = guide_legend(title = "Guides"),
           fill = guide_legend(title = "Guides"), shape = guide_legend(title = "Guides")) +
    theme(legend.position = "bottom", legend.title = element_blank(),
          text = element_text(size = 18))
  if (type == 2L) {
    g <- g + labs(x = "Number of sampling units", y = "Sample coverage")
    if (datatype == "abundance")
      g <- g + labs(x = "Number of reads", y = "Sample coverage")
  }
  else if (type == 3L) {
    g <- g + labs(x = "Sample coverage", y = "Species diversity")
  }
  else {
    g <- g + labs(x = "Number of sampling units", y = "Counting")
    if (datatype == "abundance")
      g <- g + labs(x = "Number of reads", y = "Counting")
  }
  if (se)
    g <- g + geom_ribbon(aes_string(ymin = "y.lwr", ymax = "y.upr",
                                    fill = "factor(col)", colour = "NULL"), alpha = 0.2)
  if (facet.var == "order") {
    if (length(levels(factor(z$order))) == 1 & type != 2) {
      warning("invalid facet.var setting, the iNEXT object do not consist multiple orders.")
    }
    else {
      g <- g + facet_wrap(~order, nrow = 1)
      if (color.var == "both") {
        g <- g + guides(colour = guide_legend(title = "Guides",
                                              ncol = length(levels(factor(z$order))), byrow = TRUE),
                        fill = guide_legend(title = "Guides"))
      }
    }
  }
  if (facet.var == "site") {
    if (!"site" %in% names(z)) {
      warning("invalid facet.var setting, the iNEXT object do not consist multiple sites.")
    }
    else {
      g <- g + facet_wrap(~site, nrow = 1)
      if (color.var == "both") {
        g <- g + guides(colour = guide_legend(title = "Guides",
                                              nrow = length(levels(factor(z$order)))), fill = guide_legend(title = "Guides"))
      }
    }
  }
  if (facet.var == "both") {
    if (length(levels(factor(z$order))) == 1 | !"site" %in%
        names(z)) {
      warning("invalid facet.var setting, the iNEXT object do not consist multiple sites or orders.")
    }
    else {
      g <- g + facet_wrap(site ~ order)
      if (color.var == "both") {
        g <- g + guides(colour = guide_legend(title = "Guides",
                                              nrow = length(levels(factor(z$site))), byrow = TRUE),
                        fill = guide_legend(title = "Guides"))
      }
    }
  }
  if (grey) {
    g <- g + theme_bw(base_size = 18) + scale_fill_grey(start = 0,
                                                        end = 0.4) + scale_colour_grey(start = 0.2, end = 0.2) +
      guides(linetype = guide_legend(title = "Method"),
             colour = guide_legend(title = "Guides"), fill = guide_legend(title = "Guides"),
             shape = guide_legend(title = "Guides")) + theme(legend.position = "bottom",
                                                             legend.title = element_blank())
  }
  g <- g + theme(legend.box = "vertical")

  return(g)
}




#me dice la probabilidad de saturacion, la de oversampling, IC95% X95
PILI3.MetagenSample.size.READS.OTU.GENES<-function(matriu, calc.matrix = "sum"){

  #funcion de
  library(iNEXT)
  library(ggplot2)
  library(proto)
  library(nls2)
  library(rcompanion)

  #calssical analysis of effort reads vs otu
  ##library(vegan)
  # method = "rarefaction" vegan
  ##plot(specaccum(t(matriu),
  ##               method = "rarefaction"),
  ##     xvar = "individuals",
  ##     main = "rarefaction, xvar = individuals")
  ##legend("bottomleft", legend = "Note x-axis has large range")


  #si hay varias replicas, suma o media
  #calc.matrix = "mean"
  if (calc.matrix=="sum"){matriu1<-rowSums(matriu)}
  if (calc.matrix=="mean"){matriu1<-rowMeans(matriu)}


  #rd<-round(sum(matriu)/100,0) #100 partes maximo
  #aqui empieza la funcion para calcula el esfuerzo
  #correccion en: https://stackoverflow.com/questions/46166397/what-the-solution-for-this-ggplot2-error-on-giginext-function-error-in-levels
  #siz <- seq(1, sum(matriu), by=rd)
  out1 <- iNEXT((matriu1),q = 0, datatype="abundance",knots = 100,nboot = 50)
  ##y<-max(out1$iNextEst[7])
  ##current.effort <- y #esfuerzo actual de muestreo for OTU/GENES
  ##k<-sum(matriu)
  ##while(y <0.99){
  ##  #funcion para encontrar el valor de 0.99
  ##  #contador
  ##  k <- k + 10
  ##  #print(k)
  ##  siz <- seq(1, k, by=1)
  ##  out1 <- iNEXT((matriu1), q=0, datatype="abundance", nboot = 1000,size = siz)
  #print(max(out1$iNextEst[7]))
  ##  y<-max(out1$iNextEst[7])
  #print(y)
  ##}

  #reads observed for current.effort
  aaaa<-data.frame(out1$iNextEst)
  current.effort.selection<-subset(aaaa, aaaa$method=="observed")

  #resultados
  ##X1<-as.matrix(out1$iNextEst[1]) #reads
  ##X2<-as.matrix(out1$iNextEst[4]) #OTU
  ##X3<-as.matrix(out1$iNextEst[5]) #OTU LCI95%
  ##X4<-as.matrix(out1$iNextEst[6]) #OTU UCI95%
  ##X5<-as.matrix(out1$iNextEst[7]) #COBERTURA %
  ##X6<-as.matrix(out1$iNextEst[8]) #COBERTURA %
  ##X7<-as.matrix(out1$iNextEst[9]) #COBERTURA %
  ##mat.res<- data.frame(READS=X1, OTUS=X2, OTULCI95=X3, OTUUCI95=X4, COBERTURA=X5, COBERTURALCI95=X6, COBERTURAUCI95=X7)

  ##max.otu<-max(mat.res$qD)#max otus
  ##reads.90.otu<-0.9*max.otu
  ##reads.95.otu<-0.95*max.otu
  ##reads.99.otu<-0.99*max.otu

  #buscar 90, 95 y 99
  #señalar en la grafica
  #maximo numero de otus y esfuerzo actual
  ##for (i in 1:dim(mat.res)[1]){
  #i<-1
  #reads para una cobertura del 90% segun Chao
  ##  if(mat.res$SC[i]<=0.9){reads_90=mat.res$m[i]}
  ##  if(mat.res$SC[i]<=0.95){reads_95=mat.res$m[i]}
  ##  if(mat.res$SC[i]<=0.99){reads_99=mat.res$m[i]}

  #reads para cobertura segun ToniM
  ##  if(mat.res$qD[i]<=reads.90.otu){reads_90.1=mat.res$m[i]}
  ##  if(mat.res$qD[i]<=reads.95.otu){reads_95.1=mat.res$m[i]}
  ##  if(mat.res$qD[i]<=reads.99.otu){reads_99.1=mat.res$m[i]}
  ##}

  ####### utilizar WEIBULL 4 PARAMETROS ############3
  #utilizando una funcion weibull, dar el esfuerzo y representarlo
  #RESULTADOS DE LA FUNCION PILI3.MetagenSample.size.READS.OTU.GENES
  #ES out1
  reads<-as.matrix(out1$iNextEst[1]) #m son las READS - m
  otu<-as.matrix(out1$iNextEst[4]) #m son las otus - qD
  curva.rarefaccion<-data.frame(reads=(reads), otu=(otu))
  #plot(curva.rarefaccion$m, curva.rarefaccion$qD)
  curva.rarefaccion$reads<-curva.rarefaccion$m
  curva.rarefaccion$otu<-curva.rarefaccion$qD

  #weibull
  options(show.error.messages=F) # turn off
  out.weibull4p <- try(model.SSweibull <- nls(otu ~ SSweibull(reads, a, b, c, d), data = curva.rarefaccion))
  options(show.error.messages=T) # turn off

  correcto=T#inicializo esta variable
  #comprobacion del error
  #(substr(out3[1],1,5)!="Error")
  if (substr(out.weibull4p[1],1,5) == "Error"){
    #repetir con el algoritmo de fuerza bruta
    max.otu<-max(as.matrix(out1$iNextEst[4]))
    st1 <- expand.grid(otumax=seq(max.otu, 10*max.otu, len = 5), Drop =seq(max.otu, 5*max.otu, len = 10),
                       lrc = seq(-10, 10, len = 50),
                       pwr = seq(0, 10, len = 50))

    fo <- otu ~ otumax-Drop*exp(-exp(lrc)*reads^pwr)
    #weibull brute force
    out.weibull.bruteforce <- try(model.SSweibull1 <- nls2(fo, start = st1, algorithm = "brute-force", data = curva.rarefaccion))



    # nls optimization.  Same as: control de errores
    options(show.error.messages=F) # turn off
    out.weibull4p2 <- try(model.SSweibull<-nls2(fo, start = coef(model.SSweibull1),data = curva.rarefaccion))
    options(show.error.messages=F) # turn off
    if (substr(out.weibull4p2[1],1,5) == "Error"){
      #EN ESTOS CASOS ES MUY RARO, 1 PUNTO
      model.SSweibull<-out.weibull.bruteforce
    }
    res.4<-accuracy(list( model.SSweibull),
                    plotit=TRUE, digits=3)$Fit.criteria[,c(1,5,10)]
    print("Force brute algorithm!")
    print(res.4)
    correcto=T
  }
  #todo correcto
  if (correcto==T){
    #res.5<-accuracy(list(model.SSweibull),
    #plotit=TRUE, digits=3)$Fit.criteria[,c(1,5,10)]
    #print(res.5)

    #numero de reads para alcanzar el maximo numero de otus################
    #La funcion inversa es: x <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
    Asym<-as.numeric(coef(model.SSweibull)[1])
    Drop<-coef(model.SSweibull)[2]
    lrc<-coef(model.SSweibull)[3]
    pwr<-coef(model.SSweibull)[4]
    y<-Asym-0.1 #sino es infinito
    Reads.maximo.otu <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
    ########################################################################

    #max<-coef(model.SSweibull)[1]
    if (Reads.maximo.otu<100000){paso<-0.5}
    if (Reads.maximo.otu>=100000 & Reads.maximo.otu<1000000){paso<-1}
    if (Reads.maximo.otu>=1000000){paso<-10}

    reads<- seq(0, Reads.maximo.otu, paso)
    pred.weibull.4p <- (predict(model.SSweibull,list(reads=reads)))
    plot(curva.rarefaccion$m, curva.rarefaccion$qD, xlim=c(0,max(reads)), ylim= c(0,Asym), xlab="Reads", ylab="OTU/genes")
    lines(reads, pred.weibull.4p ,lwd=2, col = "red", xlab = "Time (s)", ylab = "Counts")

    curva.rarefaccion.predicha.weibull <- data.frame(qD=as.vector(pred.weibull.4p),m=as.vector(reads))

    reads.90.otu<-Asym*0.9
    reads.95.otu<-Asym*0.95
    reads.99.otu<-Asym*0.99
    mat.res<-curva.rarefaccion.predicha.weibull
    for (i in 1:dim(mat.res)[1]){
      #i<-1
      #qD otu // m son reads
      #reads para cobertura segun ToniM
      if(mat.res$qD[i]<=reads.90.otu){reads_90.2=mat.res$m[i]}
      if(mat.res$qD[i]<=reads.95.otu){reads_95.2=mat.res$m[i]}
      if(mat.res$qD[i]<=reads.99.otu){reads_99.2=mat.res$m[i]}
    }
    abline(v=reads_95.2, col="green")
    text(reads_95.2,0, "95%")
    #AQUI SE OBTIENEN LOS VALORES PARA EL ESFUERZO (READS) PARA ALCANZAR 90,95 Y 99% COBERTURA


    #calcular el current effort segun la weibull (numero de especies actuales respecto a las maximas segun un modelo Weibull de 4p)
    ceff<-current.effort.selection$qD
    #max
    #si max --> 100%, ceff
    current.effort.weibull<-as.numeric(ceff*100/Asym)


    #grafico del esfuerzo
    #p<-ggiNEXT1.iNEXT(x=out1, type=1, facet.var="site") +
    #geom_vline(xintercept=reads_90.1, col="green") +
    #geom_vline(xintercept=reads_95.1, col="green") +
    #geom_vline(xintercept=reads_99.1, col="green")
    #p + annotate("text", x = c(reads_90.1,reads_95.1, reads_99.1), y = c(0,0,0), label = c("90%", "95%", "99%"))
    # print("grafico2")

    print("Sampling effort analysis using iNEXT/WEIBULL#####################")
    print("MAX NUMBER OF COUNTING (iNEXT/WEIBULL)")
    #print(max.otu)
    print(Asym)

    print("CURRENT EFFORT (%) (iNEXT/WEIBULL:")
    #print(100*current.effort)
    print(current.effort.weibull)
    print("Reads for 90% effort (iNEXT/WEIBULL)")
    #print(reads_90.1)
    print(reads_90.2)
    #print(reads_90)
    print("Reads for 95% effort(iNEXT/WEIBULL)")
    #print(reads_95.1)
    print(reads_95.2)
    #print(reads_95)
    print("Reads for 99% effort(iNEXT/WEIBULL)")
    #print(reads_99.1)
    print(reads_99.2)
    #print(reads_99)

    #guardar los resultados en un data frame DE LAS SIMULACIONES
    X<-as.matrix(out1$iNextEst[1])
    Y<-as.matrix(out1$iNextEst[4])
    #en este data frame se guarda todo, valores e la curva simulada y los parametros estimados como los de la weibull de 4p
    resultados.iNEXT <- data.frame(X1=X[1],
                                   X2=X[2],
                                   X3=X[3],
                                   X4=X[4],
                                   X5=X[5],
                                   X6=X[6],
                                   X7=X[7],
                                   X8=X[8],
                                   X9=X[9],
                                   X10=X[10],
                                   X11=X[11],
                                   X12=X[12],
                                   X13=X[13],
                                   X14=X[14],
                                   X15=X[15],
                                   X16=X[16],
                                   X17=X[17],
                                   X18=X[18],
                                   X19=X[19],
                                   X20=X[20],
                                   Y1=Y[1],
                                   Y2=Y[2],
                                   Y3=Y[3],
                                   Y4=Y[4],
                                   Y5=Y[5],
                                   Y6=Y[6],
                                   Y7=Y[7],
                                   Y8=Y[8],
                                   Y9=Y[9],
                                   Y10=Y[10],
                                   Y11=Y[11],
                                   Y12=Y[12],
                                   Y13=Y[13],
                                   Y14=Y[14],
                                   Y15=Y[15],
                                   Y16=Y[16],
                                   Y17=Y[17],
                                   Y18=Y[18],
                                   Y19=Y[19],
                                   Y20=Y[20],
                                   max.otu.observado=Asym,
                                   esfuerzo.alcanzado= current.effort.weibull,
                                   reads_90=reads_90.2,
                                   reads_95=reads_95.2,
                                   reads_99=reads_99.2,
                                   b=max<-coef(model.SSweibull)[2],
                                   c=max<-coef(model.SSweibull)[3],
                                   d=max<-coef(model.SSweibull)[4])

    #save(resultados.iNEXT, file="result_simulaciones.Rda")

    a90<<-reads_90.2 #90% maximo
    a95<<-reads_95.2 #95% maximo
    a99<<-reads_99.2 #99% maximo

  }


  #save the results para andreu paytuvi: se dan los valores estimados por inext, son 100 puntos
  #estos 100 puntos corresponden a reads observados y un poco de proyeccion
  #no se indican los de la curva Weibull que es casi infinita
  #se indica la curva weibull con sus parametros estimados
  #OTU.ACCUMULATION.CURVE <- data.frame(reads_observed.inext=as.matrix(curva.rarefaccion$m),
  #                                     predicted.OTU.inext=as.matrix(curva.rarefaccion$qD),
  #                                     x.para.maximo.90=as.numeric(reads_90.2),
  #                                     x.para.maximo.95=as.numeric(reads_95.2),
  #                                     x.para.maximo.99=as.numeric(reads_99.2),
  #                                     current.effort=as.numeric(current.effort.weibull),
  #                                     otu_gene_predicted = as.numeric(Asym),
  #                                     b=as.numeric(coef(model.SSweibull)[2]),
  #                                     c=as.numeric(coef(model.SSweibull)[3]),
  #                                     d=as.numeric(coef(model.SSweibull)[4]))
  #write.csv(OTU.ACCUMULATION.CURVE, file = "OTU.ACCUMULATION.CURVEREADS.csv")

  graphics.off()
  return(list(out1,Asym, current.effort.weibull, reads_90.2, reads_95.2,reads_99.2))

}







#modelo weibull estimacion de parametros
#input: reads y otu; vectores
#output: modelo weibull y su
#uso:
# modelWeibull(readsX<-as.matrix(out1$iNextEst[1]), otuY<-as.matrix(out1$iNextEst[4]))
AnalysismodelWeibull<-function(readsX, otuY){

  library(nls2)
  library(rcompanion)

  if(length(readsX)<100 | length(readsX)>100){
    #si no son 100 observaciones transformarlo
    print("No son 100 observaciones")
  }
  #funcion que estima parametros weibull de 4p
  ####### utilizar WEIBULL 4 PARAMETROS ############3
  #utilizando una funcion weibull, dar el esfuerzo y representarlo
  #RESULTADOS DE LA FUNCION PILI3.MetagenSample.size.READS.OTU.GENES
  #ES out1
  #reads<-as.matrix(out1$iNextEst[1]) #m son las READS - m
  #otu<-as.matrix(out1$iNextEst[4]) #m son las otus - qD
  curva.rarefaccion<-data.frame(readsXX=as.vector(readsX), otuYY=as.vector(otuY))

  #names(curva.rarefaccion) <- c("readsXX", "otuYY")
  #plot(curva.rarefaccion$reads, curva.rarefaccion$otu)
  #curva.rarefaccion$reads<-curva.rarefaccion$m
  #curva.rarefaccion$otu<-curva.rarefaccion$qD

  #weibull
  options(show.error.messages=T) # turn off
  out.weibull4p <- try(model.SSweibull1 <- nls(otuYY ~ SSweibull(readsXX, a, b, c, d), data = curva.rarefaccion))
  options(show.error.messages=T) # turn off

  correcto=T#inicializo esta variable
  #comprobacion del error
  #(substr(out3[1],1,5)!="Error")
  if (substr(out.weibull4p[1],1,5) == "Error"){
    #repetir con el algoritmo de fuerza bruta
    max.otu<-max(as.matrix(otuY))
    st1 <- expand.grid(otumax=seq(max.otu, 10*max.otu, len = 50), Drop =otumax,
                       lrc = seq(-10, 10, len = 50),
                       pwr = seq(0, 10, len = 50))

    fo <- otuYY ~ otumax-Drop*exp(-exp(lrc)*readsXX^pwr)
    #weibull brute force (el grid tiene que ser grande para que de bien)
    out.weibull.bruteforce <- try(model.SSweibull1 <- nls2(fo, start = st1, algorithm = "brute-force", data = curva.rarefaccion))
    #comprobar que da bien el modelo
    plot (curva.rarefaccion$otuYY, predict(out.weibull.bruteforce))
    summary(lm(curva.rarefaccion$otuYY~ predict(out.weibull.bruteforce)))


    # nls optimization.  Same as: control de errores
    options(show.error.messages=F) # turn off
    out.weibull4p2 <- try(model.SSweibull1<-nls2(fo, start = coef(model.SSweibull1),data = curva.rarefaccion))
    options(show.error.messages=F) # turn off
    if (substr(out.weibull4p2[1],1,5) == "Error"){
      #EN ESTOS CASOS ES MUY RARO, 1 PUNTO
      model.SSweibull1<-out.weibull.bruteforce
      print("The prediction can be incorrect. Check the brute-force model")
    }
    res.4<-accuracy(list( model.SSweibull1),
                    plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
    print("Force brute algorithm!")
    print(res.4)
    print(model.SSweibull1)
    #predict(model.SSweibull1)
    correcto=T
  }
  #todo correcto
  if (correcto==T){
    #res.5<-accuracy(list(model.SSweibull),
    #plotit=TRUE, digits=3)$Fit.criteria[,c(1,5,10)]
    #print(res.5)

    #numero de reads para alcanzar el maximo numero de otus################
    #La funcion inversa es: x <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
    Asym<-as.numeric(coef(model.SSweibull1)[1])
    Drop<-as.numeric(coef(model.SSweibull1)[2])
    lrc<-as.numeric(coef(model.SSweibull1)[3])
    pwr<-as.numeric(coef(model.SSweibull1)[4])
    y<-Asym-0.1 #sino es infinito

    max1<-max(curva.rarefaccion$readsXX)

    if(lrc==0|pwr==0|Drop==0){
      max2<-max1
      Reads.maximo.otu<-max1
    }
    if(lrc!=0 & pwr!=0 & Drop!=0){
      Reads.maximo.otu <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
      max2<-max(Reads.maximo.otu,max1)
    }
    ########################################################################

    #decido el tamaño del paso
    if (max2>=100000){paso=1000}
    if (max2>=1000 & max2 <100000 ){paso=100}
    if (max2<1000 ){paso=1}

    #max<-seq(0, Reads.maximo.otu, 0.5)#readsX
    readsXXX<- seq(0, max2, paso)#readsX
    ##readsXXX<- seq(0, max(readsX), 0.5)#
    pred.weibull.4p <- (predict(model.SSweibull1,newdata=list(readsXX=readsXXX)))
    summary(readsXXX)
    summary(pred.weibull.4p)

  #calculos del esfuerzo, etc
    curva.rarefaccion.predicha.weibull <- data.frame(otuYYY=as.vector(pred.weibull.4p),readsXXX=as.vector(readsXXX))
    names(curva.rarefaccion.predicha.weibull)<-c("otuYYY","readsXXX")
    head(curva.rarefaccion.predicha.weibull)
    reads.90.otu<-Asym*0.9
    reads.95.otu<-Asym*0.95
    reads.99.otu<-Asym*0.99
    mat.res<-curva.rarefaccion.predicha.weibull
    for (i in 1:dim(mat.res)[1]){
      #i<-1
      #qD otu // m son reads
      #reads para cobertura segun ToniM
      if(mat.res$otuYYY[i]<=reads.90.otu){reads_90.2=mat.res$readsXXX[i]}
      if(mat.res$otuYYY[i]<=reads.95.otu){reads_95.2=mat.res$readsXXX[i]}
      if(mat.res$otuYYY[i]<=reads.99.otu){reads_99.2=mat.res$readsXXX[i]}
    }
    #abline(v=reads_95.2, col="green")
    #text(reads_95.2,0, "95%")
    #abline(v=reads_99.2, col="green")
    #text(reads_99.2,0, "99%")
    #AQUI SE OBTIENEN LOS VALORES PARA EL ESFUERZO (READS) PARA ALCANZAR 90,95 Y 99% COBERTURA


    #calcular el current effort segun la weibull (numero de especies actuales respecto a las maximas segun un modelo Weibull de 4p)
    #ceff<-current.effort.selection$qD
    ceff<-max(otuY)

    #max
    #si max --> 100%, ceff
    current.effort.weibull<-as.numeric(ceff*100/Asym)


    #grafico del esfuerzo
    #p<-ggiNEXT1.iNEXT(x=out1, type=1, facet.var="site") +
    #geom_vline(xintercept=reads_90.1, col="green") +
    #geom_vline(xintercept=reads_95.1, col="green") +
    #geom_vline(xintercept=reads_99.1, col="green")
    #p + annotate("text", x = c(reads_90.1,reads_95.1, reads_99.1), y = c(0,0,0), label = c("90%", "95%", "99%"))
    # print("grafico2")


    #grafica de los resultados
    plot(curva.rarefaccion$readsXX, curva.rarefaccion$otuYY, xlim=c(0,max(readsXXX)), ylim= c(0,1.1*Asym), xlab="Reads", ylab="OTU/genes")
    lines(readsXXX, pred.weibull.4p ,lwd=2, col = "red", xlab = "Time (s)", ylab = "Counts")
    title(main = "Rarefaction curve: Weibull model")
    text1<-paste( "[Gene/otu max=", round(Asym,0), ";Effort(%)=", round(current.effort.weibull,1), ";reads-95%=", round(reads_95.2,1),"]" ,sep = "")
    mtext(text1, side = 3)
    abline(v=reads_95.2, col="green")
    text(reads_95.2,0, "95%")

    options(show.error.messages=T) # turn off
    #plotFit(model.SSweibull,interval="both",pch=19,col.pred='light blue',shade=T,xlab="Reads", ylab="OTU/genes")

    #if (substr(out.weibull4p2[1],1,5) == "Error"){
      #EN ESTOS CASOS ES MUY RARO, 1 PUNTO
    #  model.SSweibull<-out.weibull.bruteforce
    #}

    #impresion de los resultados
    print("Sampling effort analysis using iNEXT/WEIBULL#####################")
    print("MAX NUMBER OF OTUS(iNEXT/WEIBULL)")
    #print(max.otu)
    print(Asym)

    print("CURRENT EFFORT (%) (iNEXT/WEIBULL:")
    #print(100*current.effort)
    print(current.effort.weibull)
    print("Reads for 90% effort (iNEXT/WEIBULL)")
    #print(reads_90.1)
    print(reads_90.2)
    #print(reads_90)
    print("Reads for 95% effort(iNEXT/WEIBULL)")
    #print(reads_95.1)
    print(reads_95.2)
    #print(reads_95)
    print("Reads for 99% effort(iNEXT/WEIBULL)")
    #print(reads_99.1)
    print(reads_99.2)
    #print(reads_99)

    #si no son 100 puntos los normaliza a 100 puntos y cogera los 20 primeros
    #max<-coef(model.SSweibull)[1]
    #si el vector es diferente de 100
    if(dim(readsX)<100 | dim(readsX)>100){
      #si no son 100 observaciones transformarlo
      print("No son 100 observaciones. Se procede a normalizar el vector por uno de 100")
      max.de.reads <- max(readsX)
      #sep=100 partes
      sep<-max.de.reads/99
      readsXXX<- seq(0, max.de.reads, sep)
      pred.weibull.4p <- (predict(model.SSweibull,list(readsXX=readsXXX)))
      #plot(curva.rarefaccion$readsXX, curva.rarefaccion$otuYY, xlim=c(0,max(readsXXX)), ylim= c(0,Asym), xlab="Reads", ylab="OTU/genes")
      #lines(readsXXX, pred.weibull.4p ,lwd=2, col = "red", xlab = "Time (s)", ylab = "Counts")


    }
    #guardar los resultados en un data frame DE LAS SIMULACIONES
    X<-as.matrix(readsX) #reads
    Y<-as.matrix(otuY)
    #en este data frame se guarda todo, valores e la curva simulada y los parametros estimados como los de la weibull de 4p
    resultados.iNEXT <- data.frame(X1=X[1],
                                   X2=X[2],
                                   X3=X[3],
                                   X4=X[4],
                                   X5=X[5],
                                   X6=X[6],
                                   X7=X[7],
                                   X8=X[8],
                                   X9=X[9],
                                   X10=X[10],
                                   X11=X[11],
                                   X12=X[12],
                                   X13=X[13],
                                   X14=X[14],
                                   X15=X[15],
                                   X16=X[16],
                                   X17=X[17],
                                   X18=X[18],
                                   X19=X[19],
                                   X20=X[20],
                                   Y1=Y[1],
                                   Y2=Y[2],
                                   Y3=Y[3],
                                   Y4=Y[4],
                                   Y5=Y[5],
                                   Y6=Y[6],
                                   Y7=Y[7],
                                   Y8=Y[8],
                                   Y9=Y[9],
                                   Y10=Y[10],
                                   Y11=Y[11],
                                   Y12=Y[12],
                                   Y13=Y[13],
                                   Y14=Y[14],
                                   Y15=Y[15],
                                   Y16=Y[16],
                                   Y17=Y[17],
                                   Y18=Y[18],
                                   Y19=Y[19],
                                   Y20=Y[20],
                                   max.otu.observado=Asym,
                                   esfuerzo.alcanzado= current.effort.weibull,
                                   reads_90=reads_90.2,
                                   reads_95=reads_95.2,
                                   reads_99=reads_99.2,
                                   b=max<-coef(model.SSweibull)[2],
                                   c=max<-coef(model.SSweibull)[3],
                                   d=max<-coef(model.SSweibull)[4])

    save(resultados.iNEXT, file="result_simulaciones.Rda")

    a90<<-reads_90.2 #90% maximo
    a95<<-reads_95.2 #95% maximo
    a99<<-reads_99.2 #99% maximo


    library(investr)
    plotFit(model.SSweibull,interval="both",pch=19,col.pred='light blue',shade=T,xlab="Reads", ylab="OTU/genes")
    title(main = "Rarefaction curve: Weibull model")
    mtext("95% confidence band", side = 3)
    abline(v=reads_95.2, col="green")

  }


  #save the results para andreu paytuvi
  #OTU.ACCUMULATION.CURVE <- data.frame(samples=as.matrix(aaa.lo$x),predicted.OTU.lo=as.matrix(aaa.lo$y),predicted.OTU.mime=as.matrix(aaa.me$y),
  #                                     x.para.maximo.90=as.numeric(y.90.lo),
  #                                     x.para.maximo.95=as.numeric(y.95.lo),
  #                                     x.para.maximo.99=as.numeric(y.99.lo),
  #                                     x.para.maximo.90.NS=as.numeric(y.90.mime),
  #                                     x.para.maximo.95.NS=as.numeric(y.95.mime),
  #                                     x.para.maximo.99.NS=as.numeric(y.99.mime),
  #                                     max.saturative.model =as.matrix(aaa.lo$y), #blue line horizontal
  #                                     max.nonsaturative.model =as.matrix(aaa.me$y), #red line horizontal
  #                                     result=result,
  #                                     samples=nsimulac)
  #write.csv(OTU.ACCUMULATION.CURVE, file = "OTU.ACCUMULATION.CURVE.csv")


}
