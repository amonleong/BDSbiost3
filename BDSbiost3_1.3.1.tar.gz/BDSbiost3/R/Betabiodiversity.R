
#############################################################################3
# BETA BIODIVERSITY
##############################################################################

# Toni Monleon. Biost3. 4-2019




#' Function to caculate beta-diversity (BRAY CURTIS SIMILARITY)
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param distance distance used to measure the beta biodiversity, see vegdist() from library(Vegan)
#' @return Beta biodiversity Bray-Curtis similarity matrix, heat map with clusters
#' @export
#'
#' @examples
#' #Generate Multinomial Random Variables With Varying Probabilities
#' my_prob <- c(0.2,0.3,0.1,0.3, 0.01, 0.02, 0.01,0.01, 0.01, 0.01, 0.01, 0.01, 0.005, 0.005 )
#' number_of_experiments <- 20
#' number_of_samples <- 20
#' #generate a matrix
#' experiments <- rmultinom(n=number_of_experiments, size=number_of_samples, prob=my_prob)
#' experiments
#' Betabiodiversity(experiments)
#'
#' @references
#' Vegan

################################################################################
#1-funcion para el calculo de  curva de rarefaccion (bayesiano MCMC) en metagenomics y sample size
################################################################################
Betabiodiversity <- function(matriu,distance="bray") {
  #Bray curtis
  library(vegan)
  matrix <- t(matriu)
  braycurtis = vegdist(matrix,method = distance)
  hist(braycurtis)
  heatmap(as.matrix(braycurtis))
  #betadiver(matriu1)-calcula multiples indices de beta-diversidad

  print("Bray curtis matrix---")
  print(braycurtis)
}
