
#####################################################################
#SIMULATE OMIC MATRIX
#################################################################################################
#' Simulate an omic matrix using a Diritchlet-Multinomial distribution
#'
#' Function to create networkss and Gaussian Graphs
#' @param nfiles number of files to simulate
#' @param ncols number of columns to simulate)
#' @param abun.col frequency/abundance for each column
#' @return simulated matrix
#' @export
#' #'
#' @examples
#' Omic.matrix<-Simulate.matrix(nfiles=50, ncols = 10, abun.col= 2000)
#' #define the experimental groups
#' labels1<- c(rep("G1", 2),rep("G2", 5),rep("G3", 3))
#' colnames(Omic.matrix)<-labels1
#' #Simulated omic matrix with 50 files x 10 columns
#' Omic.matrix

#' @references
#' Guilanya R, Monleon-Getino T. 2018. GAIA, un programari d’ analisi metagenomica. 2018. Lulu Press Inc.


#matriu matriz de frecuencias (OTUxsamples)
Simulate.matrix <- function(nfiles=50, ncols = 10, abun.col= 20)
{

  #Parametros del modelo de simulacion
  nsites<- nfiles #NUMERO DE OTUs (especies)
  nsimulac<-ncols #numero de replicas
  ab.total<-abun.col #abundancia
  library(LearnBayes)
  ppp <- rdirichlet(1, par = rep(1, nsites))
  #ppp
  #X
  #N
  matriu <- array(0, dim=c(nsites, nsimulac))
  for(i in 1:nsimulac){
    X <- as.vector(rmultinom(1, size =ab.total , prob = ppp))
    matriu[,i]<-X
    N <- sum(X)
  }

  return(matriu) #matriz simulada multinomial que tiene 7 r?plicas, abundancia equitativa
  #sum(matriu)

}
