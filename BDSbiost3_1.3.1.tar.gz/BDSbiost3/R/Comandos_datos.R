###### Codigos para partes de la libreria
### para introducir los datos
# load("D:/Dropbox_Toni/Dropbox/Doctorado (1)/2016 articulo 2 MULV_EXP/SIMULACIONES METAGENOMICAS/BDSbiost3/data/simulacionesoct2018.Rda")
# ### cambio los nombres de las columnas y de las filas , para anonimizar las muestras.
# usethis::use_data(resultados.iNEXT.simulacion,overwrite = TRUE)
# install_deps(".")
# library(devtools)
# install_deps("/path/to/package",dependencies="logical")
