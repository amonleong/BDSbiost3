
#toni monleon (26-08-2019)

##################################################################################################
# PROJECTION ON SURVIVAL FUNCTION USING Cumulative Incidence Curves:
# FUNCTION WEIBULL: SATURATIVE FUNCTION WITH MULTIPLE USES
#################################################################################################
#' Project at infinitum time a survival curve (1-S(t) Cumulative Incidence Curves) and estimate 90,95 and 99 of maximum 1-S(t)
#'
#' @param cumulative.survival.data.frame data frame with data.frame(time,surv,std.err, lower, upper)
#' @param type=F Saturative model with Weibull 4p function, type = T non saturative model
#' @return print x.for.maximum.90_1, x.for.maximum.95_1, x.for.maximum.99_1
#' @export
#' #'
#' @examples
#'
#' #Example with a tongue cancer of the survival package from library KMsurv (Time to death or on-study time, weeks)

#' #=====> 1. Load libraries: survival and KMsurv <=====#
#' #Esample with the data-set tongue.
#' # R packages : survival & KMsurv
#' library(survival)
#' library(KMsurv)
#' #=====> 2. Data-set tongue from KMsurv <=====#
#' data(tongue)
#' attach(tongue)
#' #see the events done in the data-frame (see +)
#' mySurvObject <- Surv(time, delta)
#' mySurvObject
#' detach(tongue)
#' #=====> 3. Kaplan-Meier estimate and pointwise bounds <=====#
#' data(tongue)
#' attach(tongue)
#' mySurv <- Surv(time[type==1], delta[type==1])
#' #Estimate the survival mean and CI95
#' (myFit <- survfit(mySurv ~ 1))
#' #the life table with the survival funtion estimation and CI95
#' summary(myFit)
#' #outputs of the Kaplan-Meier estimate:
#' myFit$surv # outputs the Kaplan-Meier estimate at each t_i
#' myFit$time # t_i
#' myFit$n.risk # Y_i
#' myFit$n.event # d_i
#' myFit$std.err # standard error of the K-M estimate at t_i
#' myFit$lower # lower pointwise estimates (alternatively, $upper)
#' # plot Kaplan-Meier estimate
#' plot(myFit, main="Kaplan-Meier estimate with 95% confidence bounds",
#'      xlab="time", ylab="survival function")
#'
#'
#' #Create the Function Cumulative.Incidence.Curves()
#' Cumulative.Incidence.Curves <- function(survival.data.frame) {
#'
#'   #1-S(t)
#'   survival.data.frame$surv_1 <- 1- survival.data.frame$surv
#'   survival.data.frame$lower_1 <- 1- survival.data.frame$lower
#'   survival.data.frame$upper_1 <- 1- survival.data.frame$upper

#'   survival.data.frame$upper_1
#'   survival.data.frame$lower_1
#'   survival.data.frame$surv_1


#'   plot(survival.data.frame$time, survival.data.frame$surv_1, ylim=c(0,1), ylab="1-S(t)", xlab="Time", lty=1, type="l")

#'   lines(survival.data.frame$time, survival.data.frame$lower_1, ylim=c(0,1), ylab="1-S(t)", xlab="Time", lty=3, type="l")

#'   lines(survival.data.frame$time, survival.data.frame$upper_1, ylim=c(0,1), ylab="1-S(t)", xlab="Time", lty=3, type="l")

#'   #return the new data-frame with the 1-S(t)
#'   return(survival.data.frame)

#' }

#' #use the new function
#' #1.First:store the life table in a new data-frame
#' attach(myFit)
#' myfit.data.frame <- data.frame(time,surv,std.err, lower, upper)
#' myfit.data.frame
#' #2.Second: Calculate 1-S(t) and plot a graph
#' res <- Cumulative.Incidence.Curves(myfit.data.frame)
#' # funtion to transform Survival Cumulative Incidence Curves

#' #example of use the function Weibull.cumulative.incidence()
#' #use the new function Weibull.cumulative.incidence()


#' #1.First:store the life table in a new data-frame
#' attach(myFit)
#' myfit.data.frame <- data.frame(time,surv,std.err, lower, upper)
#' myfit.data.frame

#' #2.Second: Calculate 1-S(t) and plot a graph
#' res1 <- Cumulative.Incidence.Curves(myfit.data.frame)
#' res1

#' #3.Calculate a Weibull function and analyse 1-S(t) curve and its parameters
#' a<-Weibull.cumulative.incidence(res1,type = F) #WEIBULL 4 PARAMETERS METHOD
#' #plot the lines obtained before (90,95 and 99% of maximum survival)
#' abline(v=c(193.9024, 245.9908, 361.7547),lwd=0.5,lty=2,col="green")
#'
#' #4.Calculate a Weibull function and analyse 1-S(t) curve and its parameters
#' a<-Weibull.cumulative.incidence(res1,type = T) #USING A loess METHOD
#' #plot the lines obtained before (90,95 and 99% of maximum survival)
#' abline(v=c(158.1066, 176.8298, 193.1702),lwd=0.5,lty=2,col="pink")



#' @references
#' CI Rodríguez-Casado, A Monleon-Getino, M Cubedo, M Ríos- Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32
#'
#' A Monleon-Getino. Survival curves projection and benefit time points estimation using a new statistical method (Pending of publication, 2019)



#For survival functions: projection and estimation of 90,95 and 99% of 1-S(t)
#function Weibull.cumulative.incidence()
Weibull.cumulative.incidence <- function(cumulative.survival.data.frame, type=F) {
  options(show.error.messages = F)

  #define the as.lm.nls() function to the CI95%:
  as.lm <- function(object, ...) UseMethod("as.lm")

  as.lm.nls <- function(object, ...) {
    if (!inherits(object, "nls")) {
      w <- paste("expected object of class nls but got object of class:",
                 paste(class(object), collapse = " "))
      warning(w)
    }

    gradient <- object$m$gradient()
    if (is.null(colnames(gradient))) {
      colnames(gradient) <- names(object$m$getPars())
    }

    response.name <- if (length(formula(object)) == 2) "0" else
      as.character(formula(object)[[2]])

    lhs <- object$m$lhs()
    L <- data.frame(lhs, gradient)
    names(L)[1] <- response.name

    fo <- sprintf("%s ~ %s - 1", response.name,
                  paste(colnames(gradient), collapse = "+"))
    fo <- as.formula(fo, env = as.proto.list(L))

    do.call("lm", list(fo, offset = substitute(fitted(object))))

  }



  #load the proto and nls2 library()
  library(proto)
  library(nls2)

  #myfit.data.frame <- res
  myfit.data.frame <- cumulative.survival.data.frame
  #build the Weibull model using nls2()
  model.SSweibull<-NA
  if  (type==F) {

      #check if is correct:
     out2222 <- try(model.SSweibull <- nls2(surv_1 ~ SSweibull(time, Asym, Drop, lrc, pwr), data = myfit.data.frame  ))
     if (substr(out2222[1],1,5) != "Error"){
       #no hay errores
        #if (class(model.SSweibull) =="nls"){
        #Weibull 4 parameters
        #Self-Starting Nls Asymptotic Regression Model through the Origin: modelo weibull sencillo 2 par?metros
        #See more at: https://stat.ethz.ch/R-manual/R-devel/library/stats/html/SSasympOrig.html
        #summary
        summary(model.SSweibull)
        print("Estimation of the Weibull 4 parameters model for the cumulative.survival.data.frame")
        print(summary(model.SSweibull))
        print("###########################################################3")

        #R2-goodness of fit----------------------------------
        library(rcompanion)
        good.fit.model<-accuracy(list(model.SSweibull),
                                 plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
        print("Efron.r.squared: weibull4p nls2")
        print(good.fit.model)


        #plot the 1- S(t) and CI95%:
        plot(myfit.data.frame$time, myfit.data.frame$surv_1, ylim=c(0,1), ylab="1-S(t)", xlab="Time", lty=1, type="l")

        lines(myfit.data.frame$time, myfit.data.frame$lower_1, ylim=c(0,1), ylab="1-S(t)", xlab="Time", lty=3, type="l")

        lines(myfit.data.frame$time, myfit.data.frame$upper_1, ylim=c(0,1), ylab="1-S(t)", xlab="Time", lty=3, type="l")

        #Plot in the 1-S(t)plot the estimation of the Weibull model
        curve(summary(model.SSweibull)$parameters[1]-summary(model.SSweibull)$parameters[2]*exp(-exp(summary(model.SSweibull)$parameters[3])*x^summary(model.SSweibull)$parameters[4]), col = "RED", lwd = 2, add = TRUE)

        #print("s1")
        #Interval of prediction of CI95%
        predCI <- predict(as.lm.nls(model.SSweibull), interval = "confidence", level = 0.95)
        print("s2")
        #plot the CI95% Weibull model
        xx<- myfit.data.frame$time
        lines(xx,predCI[,2],col="blue",lty=2)
        lines(xx,predCI[,3],col="blue",lty=2)
        #print("s3")


        #effort to reach a time of the 90%, 95% and 99% of the maximum of the cumulative.survival curve
        #We use the inverse of the Weibull function():
        #x <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)


        #summary(model.SSweibull)
        Asym<-summary(model.SSweibull)$parameters[1]
        Drop<-summary(model.SSweibull)$parameters[2]
        lrc<-summary(model.SSweibull)$parameters[3]
        pwr<-summary(model.SSweibull)$parameters[4]

        #1.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
        y <- 0.90*Asym
        x.para.maximo.90<- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
        x.para.maximo.90
        print("effort to reach a time of the 90% of the maximum of the cumulative.survival curve")
        print(x.para.maximo.90)
        print("-------------------------------------------")

        #2.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
        y <- 0.95*Asym
        x.para.maximo.95<- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
        x.para.maximo.95
        print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve")
        print(x.para.maximo.95)
        print("-------------------------------------------")

        #3.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
        y <- 0.99*Asym
        x.para.maximo.99<- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
        x.para.maximo.99
        print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
        print(x.para.maximo.99)
     }
     #hay errores
     if (substr(out2222[1],1,5) == "Error"){
       library(rcompanion)
       model.SSweibull<-Weibull4p(X<-myfit.data.frame$time,
                      Y<-myfit.data.frame$surv_1, a=max(Y), b=a, c=3, Print.curve = T)
      #el resultado es una lista
       #return(list(a.w4p, b.w4p, c.w4p, d.w4p, x.para.maximo.90_1, x.para.maximo.95_1, x.para.maximo.99_1, vec.curve, good.fit.model))
       #summary(model.SSweibull)
       print("Estimation of the Weibull 4 parameters model for the cumulative.survival.data.frame")
       print((model.SSweibull))
       print("###########################################################3")

       #R2-goodness of fit----------------------------------
       library(rcompanion)
       good.fit.model<-accuracy(list(model.SSweibull),
                                plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
       print("Efron.r.squared: weibull4p nls2")
       print(good.fit.model)

       #plot the 1- S(t) and CI95%:
       plot(myfit.data.frame$time, myfit.data.frame$surv_1, ylim=c(0,1), ylab="1-S(t)", xlab="Time", lty=1, type="l")

       lines(myfit.data.frame$time, myfit.data.frame$lower_1, ylim=c(0,1), ylab="1-S(t)", xlab="Time", lty=3, type="l")

       lines(myfit.data.frame$time, myfit.data.frame$upper_1, ylim=c(0,1), ylab="1-S(t)", xlab="Time", lty=3, type="l")

       #Plot in the 1-S(t)plot the estimation of the Weibull model
       #curve(summary(model.SSweibull)$parameters[1]-summary(model.SSweibull)$parameters[2]*exp(-exp(summary(model.SSweibull)$parameters[3])*x^summary(model.SSweibull)$parameters[4]), col = "RED", lwd = 2, add = TRUE)
       lines(unlist(model.SSweibull[[8]]$x),unlist(model.SSweibull[[8]]$y), col = "RED", lwd = 2)
       #print("s1")

       #Interval of prediction of CI95%
       #predCI <- predict(as.lm.nls(model.SSweibull), interval = "confidence", level = 0.95)
       #print("s2")
       #plot the CI95% Weibull model
       #xx<- myfit.data.frame$time
       #lines(xx,predCI[,2],col="blue",lty=2)
       #lines(xx,predCI[,3],col="blue",lty=2)
       #print("s3")


       #effort to reach a time of the 90%, 95% and 99% of the maximum of the cumulative.survival curve
       #We use the inverse of the Weibull function():
       #x <- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)


       #summary(model.SSweibull)
       Asym<-unlist(model.SSweibull[[1]])
       Drop<-unlist(model.SSweibull[[2]])
       lrc<-unlist(model.SSweibull[[3]])
       pwr<-unlist(model.SSweibull[[4]])

       #1.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
       #y <- 0.90*Asym
       x.para.maximo.90<- unlist(model.SSweibull[[5]]) #(log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
       #x.para.maximo.90
       print("effort to reach a time of the 90% of the maximum of the cumulative.survival curve")
       print(unlist(model.SSweibull[[5]]))
       print("-------------------------------------------")

       #2.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
       #y <- 0.95*Asym
       x.para.maximo.95<- unlist(model.SSweibull[[6]]) #(log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
       x.para.maximo.95
       print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve")
       print(unlist(model.SSweibull[[6]]))
       print("-------------------------------------------")

       #3.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
       #y <- 0.99*Asym
       x.para.maximo.99<- (unlist(model.SSweibull[[7]])) #(log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
       x.para.maximo.99
       print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
       print(unlist(model.SSweibull[[7]]))
     }
  }

  #no satura el modelo y hay que hacer los c?lculos con splines LOESS
  if (type==T) {
    #if (class(model.SSweibull) != "nls") {

    #plot( x.1, y.1)
    X1<-myfit.data.frame$time
    X2<-myfit.data.frame$surv_1
    plx<-loess(X2 ~ X1, control = loess.control(surface =  "direct"), se=T)
    aaa<- predict(plx, data.frame(X1 = X1), se = TRUE)
    x.1.1 <- X1
    lines(x.1.1, aaa$fit, col = "red")
    lines(x.1.1,aaa$fit - qt(0.975,aaa$df)*aaa$se, lty=2, col = "red")
    lines(x.1.1,aaa$fit + qt(0.975,aaa$df)*aaa$se, lty=2, col = "red")

    #PSUDO-R2 PARA LOESS
    ss.Y <- sum(scale(X2, scale=FALSE)^2)
    ss.resid <- sum(resid(plx)^2)
    PSEUDO.R2<-1-ss.resid/ss.Y
    print("Pseudo-r.squared: LOESS")
    print(PSEUDO.R2)

    maxim <- max(aaa$fit)
    num.row <- length(X1) #num of rows data-frame
    #toni-aquiii 30-11-2016
    i<-1
    while(aaa$fit[i]<maxim ){
      punt_t <- X1[i]
      i <- i + 1
    }

    #calculo el 90% maximo
    y.i <- 0.90*maxim
    data.x.y <- data.frame(x=X1, y=aaa$fit)
    x.para.maximo.90<- inverse.function(data.x.y, y.i, punt_t)

    print("effort to reach a time of the 90% of the maximum of the cumulative.survival curve")
    print(x.para.maximo.90)


    #calculo el 95% maximo
    maxim <- max(aaa$fit)

    y.i <- 0.95*maxim
    data.x.y <- data.frame(x=X1, y=aaa$fit)
    x.para.maximo.95<- inverse.function(data.x.y, y.i, punt_t)

    print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve")
    print(x.para.maximo.95)

    #calculo el 95% maximo
    maxim <- max(aaa$fit)
    y.i <- 0.99*maxim
    data.x.y <- data.frame(x=X1, y=aaa$fit)
    x.para.maximo.99<- inverse.function(data.x.y, y.i, punt_t)

    print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
    print(x.para.maximo.99)

   # }
  }




}


#Statistical analysis of the cumulative incidence curve using the nls Weibull
inverse.function <- function(data.x.y, y.i, punt_t){
  #calculate the inverse function of a spline

  #punt_t es el punto en el cual se encuentra el maximo de la funci?n fitted
  # y.i es el maximo

  #y.i <- 6.5
  #data.x.y <- data.frame(x=c(1,2,3,4,5, 6, 7), y=c(2,4,6,8,10, 12, 14))
  attach(data.x.y)
  data.x.y <- subset(data.x.y, x < punt_t)
  attach(data.x.y)

  plx<-loess(x ~ y, control = loess.control(surface =  "direct"), data=data.x.y)
  aaa<- predict(plx, data.frame(y = y.i), se = TRUE)
  aaa$fit
  LCI<-aaa$fit - qt(0.975,aaa$df)*aaa$se
  UCI<-aaa$fit + qt(0.975,aaa$df)*aaa$se


  return(c(aaa$fit, LCI,  UCI))
}






##### as.lm function:

as.lm <- function(object, ...) UseMethod("as.lm")

as.lm.nls <- function(object, ...) {
  if (!inherits(object, "nls")) {
    w <- paste("expected object of class nls but got object of class:",
               paste(class(object), collapse = " "))
    warning(w)
  }

  gradient <- object$m$gradient()
  if (is.null(colnames(gradient))) {
    colnames(gradient) <- names(object$m$getPars())
  }

  response.name <- if (length(formula(object)) == 2) "0" else
    as.character(formula(object)[[2]])

  lhs <- object$m$lhs()
  L <- data.frame(lhs, gradient)
  names(L)[1] <- response.name

  fo <- sprintf("%s ~ %s - 1", response.name,
                paste(colnames(gradient), collapse = "+"))
  fo <- as.formula(fo, env = as.proto.list(L))

  do.call("lm", list(fo, offset = substitute(fitted(object))))

}

############## End as.lm function ####################

#### proto function avaible in https://github.com/hadley/proto/blob/master/R/proto.R

##### proto function:

proto <- function(. = parent.env(envir), expr = {},
                  envir = new.env(parent = parent.frame()), ...,
                  funEnvir = envir) {
  parent.env(envir) <- .
  envir <- as.proto.environment(envir)  # must do this before eval(...)
  # moved eval after for so that ... always done first
  # eval(substitute(eval(quote({ expr }))), envir)
  dots <- list(...); names <- names(dots)
  for (i in seq_along(dots)) {
    assign(names[i], dots[[i]], envir = envir)
    if (!identical(funEnvir, FALSE) && is.function(dots[[i]]))
      environment(envir[[names[i]]]) <- funEnvir
  }
  eval(substitute(eval(quote({
    expr
  }))), envir)
  if (length(dots))
    as.proto.environment(envir)
  else
    envir
}

#' @export
#' @rdname proto
as.proto <- function(x, ...) {
  UseMethod("as.proto")
}

#' @export
#' @rdname proto
as.proto.environment <- function(x, ...) {
  assign(".that", x, envir = x)
  assign(".super", parent.env(x), envir = x)
  structure(x, class = c("proto", "environment"))
}

#' @export
#' @rdname proto
as.proto.proto <- function(x, ...) {
  x
}
as.proto.list <- function(x, envir, parent, all.names = FALSE, ...,
                          funEnvir = envir, SELECT = function(x) TRUE) {
  if (missing(envir)) {
    if (missing(parent))
      parent <- parent.frame()
    envir <- if (is.proto(parent))
      parent$proto(...)
    else
      proto(parent, ...)
  }
  for (s in names(x))
    if (SELECT(x[[s]])) {
      assign(s, x[[s]], envir = envir)
      if (is.function(x[[s]]) && !identical(funEnvir, FALSE))
        environment(envir[[s]]) <- funEnvir
    }
  if (!missing(parent))
    parent.env(envir) <- parent
  as.proto.environment(envir)  # force refresh of .that and .super
}

#' @export
"$<-.proto" <- function(this,s,value) {
  if (s == ".super")
    parent.env(this) <- value
  if (is.function(value))
    environment(value) <- this
  this[[as.character(substitute(s))]] <- value
  this
}
is.proto <- function(x) inherits(x, "proto")

#' @export
"$.proto" <- function(x, name) {
  inherits <- substr(name, 1, 2) != ".."

  res <- get(name, envir = x, inherits = inherits)
  if (!is.function(res))
    return(res)

  if (deparse(substitute(x)) %in% c(".that", ".super"))
    return(res)

  structure(
    function(...) res(x, ...),
    class = "protoMethod",
    method = res
  )
}

#' @export
print.protoMethod <- function(x, ...) {
  cat("<ProtoMethod>\n")
  print(attr(x, "method"), ...)
}

# modified from Tom Short's original
#' @export
str.proto <- function(object, max.level = 1, nest.lev = 0,
                      indent.str = paste(rep.int(" ", max(0, nest.lev + 1)), collapse = ".."),
                      ...) {
  cat("proto", name.proto(object), "\n")
  Lines <- utils::capture.output(utils::str(
    as.list(object), max.level = max.level,
    nest.lev = nest.lev, ...
  ))[-1]
  for (s in Lines)
    cat(s, "\n")
  if (is.proto(parent.env(object))) {
    cat(indent.str, "parent: ", sep = "")
    utils::str(parent.env(object), nest.lev = nest.lev + 1, ...)
  }
}

#' @export
print.proto <- function(x, ...) {
  if (!exists("proto_print", envir = x, inherits = TRUE))
    return(NextMethod())

  x$proto_print(...)
}

############# End proto function ##############
