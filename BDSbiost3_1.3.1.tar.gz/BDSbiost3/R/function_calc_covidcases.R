#old---- eliminar!!!!!!!!!!!!!!

###########################################################################################
#funcion de densidad de casos y de distribucion (acumulados) y su analisis
######################################################################################
######################################################################################
# MODELO AD-HOC BASADO EN MODELO PARAMETRICO WEIBULL + NORMAL + LOESS
# PERMITE PREDECIR CASOS DE PERSONAS AFECTADAS POR COVID-19
#####################################################################################




#toni monleon (5-04-2020)

##################################################################################################
# FUNCTION TO CALCULATE CASES AND CUM CASES OF COVID-19 PANDEMIA
#################################################################################################
# FUNCTION TO CALCULATE CASES AND CUM CASES OF COVID-19 PANDEMIA USING A PARAMETRIC MODEL AND LOESS
#
# @param X day number
# @param Y cases affected by disease
# @param max.cases.free parameter a (asymptote value) free value (max.cases.free=F)
# @param max.cases value of parameter a (aymptote) defect= 8000
# @param sdv_dias1 value of sdv of days for the model (descent part)
# @param rest99.1 value of sdv of days for the model (plateau part)
# @param lim.days number of days to represent (temporal horizon)
# @param iterations number of iterations in the nlr calculations
# @param label.ind label for the plot
# @return plot and calculations related with time and projection in time
# @export
#
# @examples
# #COVID19 cases in Spain (February-April 2020)
# COVID19.Spain<- data.frame(n.day=  seq(1:48),
#                           Cases = c(0,    0,    0,    0,    1,    7,    6,   13,   14,   22,   48,   35,   46,   44,  126,   22,  140,  480,
#                                     600,  511,  812, 1201, 1714, 1854, 1451, 2029, 2538, 3431, 2833, 4946, 3646, 4517, 6584, 7937, 8578, 7871,
#                                     8189, 6549, 6398, 9222, 7719, 8102, 7472, 7026, 6023, 4273, 5478, 6180) )
# plot(COVID19.Spain$n.day,COVID19.Spain$Cases, xlim=c(0,100), col="red", main="Projection plot and parameters estimation", sub="using a Weibull function 4p")

# #Predict evolution of cases in Spain with an "ad-hoc" model ()
# pred.Casos.diarios<-covid.cases.cumcases(X=COVID19.Spain$n.day, Y=COVID19.Spain$Cases, max.cases.free=T, max.cases = max(COVID19.Spain$Cases) , sdv_dias1=15, rest99.1 = 7, lim.days=100,iterations = 20, label.ind="SPAIN: PREDICTION COVID-19 (DAY1: 20/2/2020)")
# @references
#
# Monleon-Getino, T; Canela, J. Next weeks of SARS-CoV-2: Projection model to predict time evolution scenarios of accumulated cases in Spain (Pending of publication)



#funcion nueva--------------------------
covid.cases.cumcases<- function(X=country$n.day, Y=country$Cases, max.cases.free=F, max.cases = 8000 , sdv_dias1=5, rest99.1 = 0, lim.days=300, iterations=10, label.ind="label title plot" ){

  library(BDSbiost3)
  if(max.cases.free==F){
    max.cases.f<-max.cases
  }
  if(max.cases.free==T){
    max.cases.f <- max(Y)
  }
      #casos
      plot(Y ~ X,ylim=c(1,1.5*max(Y)), xlim=c(1,lim.days), ylab="cases COVID-19",xlab="days from day1", col="red", main=label.ind, sub=" (Prediction by T.Monleon-Getino[BIOST3/GRBIO-UB])")
      #casos obtenidos por derivacion F(X)-> f(X)

      #subida hasta el maximo
      if(max.cases.free==T){
        res.model.weibull2<-Weibull4p.monle1(X,  Y, a=max.cases.f, b=max.cases, c=-20, d=12, Print.curve = T, force.a = F, brfr.it=iterations)
        res.model.weibull2
        abline(v=res.model.weibull2[c(5,6,7)],col="red",lwd=0.5, lty =2)
        max.cases<-res.model.weibull2[[1]]
        day.maximo<-res.model.weibull2[[7]]

      }
      if(max.cases.free==F){
        res.model.weibull2<-Weibull4p.monle1(X,  Y, a=max.cases.f, b=a, c=-2, d=10, Print.curve = T, force.a = T, brfr.it=iterations)
        res.model.weibull2
        abline(v=res.model.weibull2[c(5,6,7)],col="red",lwd=0.5, lty =2)
        max.cases<-res.model.weibull2[[1]] #1296
        day.maximo<-round(res.model.weibull2[[7]],0) #29
      }
      #comprobar si el dia maximo es infinito
      if(day.maximo==Inf){day.maximo<-2*lim.days}
      #los otros parametros d elos casos son
      a_cas<-res.model.weibull2[[1]]
      b_cas<-res.model.weibull2[[2]]
      c_cas<-res.model.weibull2[[3]]
      d_cas<-res.model.weibull2[[4]]


      #meseta y bajada
      #situacion1
      a= max.cases# aaa1[[1]] #maximo numero de casos diagnosticados
      days99<- day.maximo #aaa1[[7]] #dias hasta el 99 maximo
      rest99 <- 0 #(8 days in the maximum)
      sdv_dias<- sdv_dias1
      x <- seq(days99+1, lim.days, length=100)
      y <- dnorm(x, mean=days99, sd=sdv_dias)
      #linea empieza en punto calculado por W(X)
      x1 = a/y[1]
      x11<- x+rest99
      y11 <- x1*dnorm(x, mean=days99, sd=sdv_dias)
      #plot(x,y,add=T)
      lines(x11, y11,col="cyan")

      #VERIFICAR SI LA FECHA ACTUAL ES POSTERIOR A PUNTO MAXIMO (YA HA LLEGADO PUNTO MAXIMO DE CASOS)
      if(day.maximo<max(X)){
        #day.maximo<-max(X)
        #max.cases<-Y[max(X)]
        #Y[max(X)]
        #linea empieza en punto calculado por MAZ(y)
        x1 = max(Y[days99:max(X)])/y[1]
        x11a<- x+rest99.1
        y11a <- x1*dnorm(x, mean=days99, sd=sdv_dias)
        #plot(x,y,add=T)
        lines(x11a, y11a,col="cyan")
      }







      #lo junto todo
      #casos
      plot(Y ~ X, ylim=c(1,1.2*max(max.cases.f,max(Y))), xlim=c(1,lim.days), ylab="cases COVID-19",xlab="days from day1", col="red", main=label.ind, sub=" (Prediction by T.Monleon-Getino[BIOST3/GRBIO-UB])")
      if(day.maximo>=max(X)){
        X1<-c(X, x11)
        X2<-c(Y, y11)
      }

      if(day.maximo<max(X)){
        X1<-c(X, x11,x11a)
        X2<-c(Y, y11,y11a)
      }

      #REPRESENTAR EL DIA QUE SE LLEGA AL 99% DE LOS CASOS SEGUN W(x)
      abline(v=day.maximo,col="red",lwd=0.5, lty =2)

      #LINEAS MEDIAS DEL MODELO PREDICHO CON LOESS()
      plx<-loess(X2 ~ X1, se=T,span=0.15,control = loess.control(surface =  "direct"))
      aaa<- predict(plx, data.frame(X1 = 1:lim.days), se = TRUE)
      x.1.1 <- 1:lim.days
      lines(x.1.1, aaa$fit, col = "magenta", lwd=2, lty=1) #casos predichos
      lines(x.1.1,aaa$fit - qt(0.975,aaa$df)*aaa$se, lwd=1, lty=2, col = "magenta")
      lines(x.1.1,aaa$fit + qt(0.975,aaa$df)*aaa$se, lwd=1, lty=2, col = "magenta")
      #dia actual
      abline(v=max(X),col="yellow",lwd=2, lty =2)


      #cumcases
      plot(cumsum(Y) ~ X, xlim=c(0,lim.days), ylim=c(0,max(cumsum(round(aaa$fit,0)),max(cumsum(Y)))), ylab="CUM-cases COVID-19",xlab="days from day1", col="red", main=label.ind, sub=" (Prediction by T.Monleon-Getino[BIOST3/GRBIO-UB])")

      #casos acumulados: reales + predichos modelo
      cumcases_pred<-cumsum( c(Y[1:length(X)], round(aaa$fit,0)[(length(X)+1):lim.days]) )      #reales + predichos
      lines(x.1.1, cumcases_pred, col = "magenta", lwd=2, lty=1) #casos predichos
      cumcases_pred_ll<-cumsum( c(Y[1:length(X)], round(aaa$fit- qt(0.975,aaa$df),0)[(length(X)+1):lim.days]) )
      lines(x.1.1, cumcases_pred_ll, col = "magenta", lwd=1, lty=1) #casos predichos
      cumcases_pred_ul<-cumsum( c(Y[1:length(X)], round(aaa$fit+ qt(0.975,aaa$df),0)[(length(X)+1):lim.days]) )
      lines(x.1.1, cumcases_pred_ul, col = "magenta", lwd=1, lty=1) #casos predichos
      #old
      #lines(x.1.1, cumsum(round(aaa$fit,0)), col = "magenta", lwd=2, lty=1) #casos predichos
      #lines(x.1.1, cumsum(aaa$fit - qt(0.975,aaa$df)), col = "magenta", lwd=1, lty=1) #casos predichos
      #lines(x.1.1, cumsum(aaa$fit + qt(0.975,aaa$df)), col = "magenta", lwd=1, lty=1) #casos predichos


      #maximum of cases acumulated cases
      #round(aaa$fit - qt(0.975,aaa$df),0)
      m<-cumcases_pred #round(cumsum(round(aaa$fit,0)),0)
      m.ll<-cumcases_pred_ll #round(cumsum(aaa$fit - qt(0.975,aaa$df)),0)
      m.ul<-cumcases_pred_ul #round(cumsum(aaa$fit + qt(0.975,aaa$df)),0)

    #plot(m ~ x.1.1)
    #modelo de casos acumulados parametros
    res.model.weibull1<-Weibull4p.monle1(X=x.1.1,  Y=m, a=max(m), b=a, c=-20, d=12, Print.curve = T, force.a = T, brfr.it=30)

    #res.model.weibull1
    abline(v=res.model.weibull1[c(5,6,7)],col="green",lwd=0.5, lty =2)
    #dia actual en el que estamos
    abline(v=max(X),col="yellow",lwd=2, lty =2)

    #REPRESENTAR EL DIA QUE SE LLEGA AL 99% DE LOS CASOS SEGUN W(x)
    abline(v=day.maximo,col="red",lwd=0.5, lty =2)

    #calculo con funcion loess del tiempo hasta 90,95 y 99%
    res.BTI<-Calculate.BTI(maxim=max(m),vector.X =x.1.1,  vector.Y=m )
    abline(v=res.BTI[c(1,2,3)],col="magenta",lwd=0.5, lty =2)

    #parametros calculados con una W(X)
    c<-round(res.model.weibull1[[3]],1)
    d<-round(res.model.weibull1[[4]],1)
    d90<-round(res.model.weibull1[[5]],0)
    d95<-round(res.model.weibull1[[6]],0)
    d99<-round(res.model.weibull1[[7]],0)

    #parametros calculados con una funcion loess
    #res.BTI
    d90_loess<-round(res.BTI[[1]],0)
    d95_loess<-round(res.BTI[[2]],0)
    d99_loess<-round(res.BTI[[3]],0)


    print("################################################################")
    print(paste("Maximum number of accumulated cases. Mean=", max(m), ",CI95% = (", max(m.ll), "-",max(m.ul), ")",sep=""))
    print(paste("Parameters cum cases W(X). c=", c, ",d=", d, ", day90%=",d90, ", day95%=",d95, ", day99%=",d99, sep=""))

    #prediccion casos nuevos proximos dias
    cases_pred<- c(Y[1:length(X)], round(aaa$fit,0)[(length(X)+1):lim.days])       #reales + predichos
    cases_pred_ll<- c(Y[1:length(X)], round(aaa$fit- qt(0.975,aaa$df),0)[(length(X)+1):lim.days]) #reales + predichos
    cases_pred_ul<- c(Y[1:length(X)], round(aaa$fit+ qt(0.975,aaa$df),0)[(length(X)+1):lim.days]) #reales + predichos
    next.days.cases<-cases_pred[(length(X)+1):lim.days]
    next.days.cases_ll<-cases_pred_ll[(length(X)+1):lim.days]
    next.days.cases_ul<-cases_pred_ul[(length(X)+1):lim.days]
    next.days.cumcases<-cumcases_pred[(length(X)+1):lim.days]

    #devuelvve las variables solicitadas
    r2_cases<-res.model.weibull1[[9]][3]
    r2_cumcases<-res.model.weibull2[[9]][3]
    return(list(day.maximo, max(X), c, d, d90_loess, d95_loess, d99_loess,res.model.weibull1[[1]], next.days.cases, next.days.cases_ll, next.days.cases_ul, a_cas,
                b_cas,
                c_cas,
                d_cas, d90, d95, d99, next.days.cumcases,r2_cases, r2_cumcases))
}

#uso de la funcion para españa
#covid.cases.cumcases(X=country$n.day, Y=country$Cases, max.cases.free=F, max.cases = 8000 , sdv_dias1=3, rest99 = 0, lim.days=120)


#########################################################################
#calcular el maximo y los BTI mediante un spline
#vector.Y<- vector.Y
Calculate.BTI<- function(maxim, vector.X, vector.Y ){
  maxim <- max(vector.Y)
  num.row <- length(vector.Y) #num of rows data-frame
  #toni-aquiii 30-11-2016
  i<-1
  while(vector.Y[i]<maxim ){
    punt_t <- vector.X[i]
    i <- i + 1
  }

  #calculo el 90% maximo
  y.i <- 0.90*maxim
  data.x.y <- data.frame(x=vector.X, y=vector.Y)
  x.para.maximo.90<- inverse.function(data.x.y, y.i, punt_t)

  print("effort to reach a time of the 90% of the maximum of the cumulative.survival curve")
  print(x.para.maximo.90)


  #calculo el 95% maximo
  maxim <- max(vector.Y)

  y.i <- 0.95*maxim
  data.x.y <- data.frame(x=vector.X, y=vector.Y)
  x.para.maximo.95<- inverse.function(data.x.y, y.i, punt_t)

  print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve")
  print(x.para.maximo.95)

  #calculo el 95% maximo
  maxim <- max(vector.Y)
  y.i <- 0.99*maxim
  data.x.y <- data.frame(x=vector.X, y=vector.Y)
  x.para.maximo.99<- inverse.function(data.x.y, y.i, punt_t)

  print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
  print(x.para.maximo.99)

  return(list(x.para.maximo.90[1], x.para.maximo.95[1], x.para.maximo.99[1]))
}
