#############################################################################3
# SAMPLE SIZE IN METAGENOMICS: DETERMINATION OF RICHNESS AND EFFORT OF SAMPLING
##############################################################################

# Toni Monleon. Biost3. 8-2017


#############################################################
# Functions to sample size and rarefaction in metagenomics
#############################################################

#' Sample size (genes, taxon) for omic data: Function to calculate rarefaction and sampling effort index based on sampling
#'
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param zero delete all values without numbers
#' @param niter number of iteration to estimate sample size using bootstrap or jacknife-1
#' @param est.esp method to estimate especies using poolaccum function of Vegan (chao, jack1, boot)
#' @param l90 represent vertical line of 90 percent
#' @param l99 represent vertical line of 99 percent
#' @param bandplot represent bootstrap and analysis of it using bandplot
#' @param plot.rep represent plot and graphical analysis and the bandplot
#' @return Effort sampling: Richness, 95% sampling Effort (sample size), Rarefaction, plot samples vs richness
#' @export
#' #'
#' @examples
#' library(HMP) #16S rRNA Sequencing Data from the Human Microbiome Proje
#' data(saliva) #saliva metagenomic test (sample vs taxa)
#' saliva1<- data.frame(t(saliva))
#'
#' #Richness analysis and effort sampling in function of number of samples
#' PILI.MetagenSample.size.b(matriu=saliva1, niter = 10,bandplot = T) #Saturation
#'
#' @references
#' Monleon-Getino T. Frias-Lopez, T. 2020. A priori estimation of sequencing effort in complex microbial metatranscriptomes. Ecology and evolution (pending of publication).
#' Monleon-Getino T. 2018. Quantitative metagenomics. Lulu Press inc.



################################################################################
#1-funcion para el calculo de  curva de rarefaccion (parametrico MCMC) en metagenomics y sample size
################################################################################
PILI.MetagenSample.size.b <- function(matriu, zero=T, niter = 10, est.esp = "jack1", l99=F, l90=F, bandplot=F, plot.rep=T, len.1=100) {

  #limpiar todo grafico anterior
  #dev.new()

  #funcion con cambios 20-12-2018.
  #utiliza las funciones logistica y la funcion Michalis-menten

  #library(R2jags) #JAGS
  library(vegan)
  library(proto)
  library(nls2)
  library(ggtern)
  library(gplots)
  library(rcompanion) #calcula la R2 aproximada para los modelos

  #options(show.error.messages = F)
  options(show.error.messages = T)
  options(warn = -1)

  nsimulac<- ncol(matriu)
  nsites <- nrow(matriu)
  #niter <- 50

  #toda la parte bayesiana (solo si se pide o numero de muestras es <=3###############################################################
  if(nsites <4){
    print("THE SAMPLE SIZE MUST BE > 3")
    stop("Ending function")
  }



  #MODELO BASICO PARA LA PREDICCION DEL NUMERO DE OTUS-MAXIMO Y DEL ESFUERO DE MUESTREO (SAMPLING EFFORT)
  #remove 0 if all the columns are 0 or not
  if(zero==T){ #solo funciona si no hay filas con 0 OTUs y con mas de 3 muestras
    matriu<-matriu[which(rowSums(matriu) > 0),]

    #recojo todas las Y
    #out.y <- matrix(NA, 500 )

    #representar la prediccion de especies por bootstrap
    #repetirlo nsim veces y recoger los estadisticos de lo que pasa
    #for (i in 1:nsim){
    for(i in 1:niter){
      #i<-2
      #niter<-100
      #prediccion de especies mediante poolaccum de VEGAN
      out2 <- try(res1<-  poolaccum(t(matriu)))
      #data.apilado<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$chao[,1]))
      if(i==1){
        if (est.esp=="jack1"){
          data.apilado<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$jack1[,1]))
        }
        if (est.esp=="boot"){
          data.apilado<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$boot[,1]))
        }
        if (est.esp=="chao"){
          data.apilado<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$chao[,1]))
        }
      }
      if(i>1){
        if (est.esp=="jack1"){
          data.apilado1<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$jack1[,1]))
        }
        if (est.esp=="boot"){
          data.apilado1<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$boot[,1]))
        }
        if (est.esp=="chao"){
          data.apilado1<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$chao[,1]))
        }
        #data.apilado1<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$est.esp[,1]))
        data.apilado<-rbind(data.apilado,data.apilado1)
      }
    }
    xx<-data.apilado$xx
    yy<-data.apilado$yy
    #plot(xx,yy)
    #datos del boottrap para predecir especies
    #xx<-c(0, 0.01, res1$N)
    #yy<-c(0, 0.01, res1$est.esp[,1])
    #prediccion inicial del num especies de Bootstrap
    #predicted.otu.boot <- res1$est.esp[length(res1$N),1]
    #predicted.otu.boot <- mean(data.apilado[data.apilado$xx==max(data.apilado$xx),2])

    #media con smoothing loess de todos los x,y
    plx<-predict(loess(yy~xx,degree=2), se=T) #loess medio
    #max.a<-max(plx$fit)
    #max(yy)
    #plx$fit media
    #xx,plx$fit+2*plx$s maximo ci95%
    #xx,plx$fit+2*plx$s minimo ci95%

    #transformo la curva a una curva de datos medios
    #xx<-xx
    yy<-plx$fit

    #calculo de las asindotas mediantes 2 modelos saturativos utilizando fuerza bruta
    ###################################################################################
    #regresion no linear - modelo de saturacion logistico y michaelis y menten----------
    #logistic saturative model - curve (logistic)-two steps
    fo.log <- yy ~ a/(1+exp(-(b+c*xx)))
    st1 <- expand.grid(a = seq(max(yy), max(yy)*3, len = len.1),
                       b = seq(-300, 1, len = 0.1*len.1), c=seq(1, 200, len = 0.1*len.1))

    out22 <- try(logistic <- nls2(fo.log, start = st1, algorithm = "brute-force"))
    logistic
    logistic.1<-nls2(fo.log, start = coef(logistic),algorithm = "plinear-random") #algoritmo plinear
    a.logistic<-summary(logistic.1)$coefficients[1,1]
    res.5<-accuracy(list(logistic.1),
                    plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
    print("Efron.r.squared: Logistic nls2 Brute-force")
    print(res.5)


    #model Michaelis-Menten (saturative, pero mas tarde?)
    fo.mime <- yy ~ (a*xx) / (b+xx)
    st2 <- expand.grid(a = seq(max(yy), max(yy)*3, len = len.1),
                       b = seq(-50, 50, len = len.1))
    out2 <- try(mi.me <- nls2(fo.mime, start = st2, algorithm = "brute-force"))
    #if (substr(out2[1],1,5)=="Error"){print("error aqui nls2-brute force") }
    #if (substr(out2[1],1,5)!="Error"){
    mi.me
    # use nls object mod1 just calculated as starting value for
    # nls optimization.  Same as:
    mi.me<-nls2(fo.mime, start = coef(mi.me),algorithm = "plinear-random")
    a.mi.me<-summary(mi.me)$coefficients[1,1]
    #max(unlist(ksmooth.log))
    res.6<-accuracy(list(mi.me),
                    plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
    print("Efron.r.squared: Michaelis-Menten nls2 Brute-force")
    print(res.6)

    #para determinar la escala X max que se necesita
    rr<-Weibull3p(X<-xx,Y<-yy, a = a.mi.me, b = a.mi.me, c=-10, d=3,Print.curve = T)
    #print("Weibull 4p")
    #print(res.WEIBUL3P.mime[1:3])
    plot(0,0, ylim=c(0, 1.2*max(c(a.logistic, a.mi.me))), xlim=c(0, max(5+nsimulac, as.numeric(rr[8]))))

    ########### calculo del modelo final ########################################################################
    #WEIBULL3P
    res.WEIBUL3P.log<-Weibull3p(X<-xx,Y<-yy, a = a.logistic, b = a.logistic, c=-5, d=1,Print.curve = F)
    #Weibull3p<- function(X, Y, asindota.weibull.W, b = asindota.weibull.W, c, d, suggest.w4p=F, Print.curve = T, brfr.it=10){
   #sugiero utilizar una weibull3p
    print("Weibull 4p")
    print(res.WEIBUL3P.log[1:3])

    res.WEIBUL3P.mime<-Weibull3p(X<-xx,Y<-yy, a = a.mi.me, b = a.mi.me, c=-10, d=3,Print.curve = F)
    print("Weibull 4p")
    print(res.WEIBUL3P.mime[1:3])

    #dev.new()
    #solo si pido representarlo
    if(plot.rep ==T){
      dev.off() #quitar el grafico anterior
      plot(0,0,type = 'l',xlab="SAMPLES" ,ylab="Future OTUs",
           main="OTU ACCUMULATION CURVE", sub="Red=logistic model, Blue=Michalis-menten model, Green=Jack,Chao,Boot",
           ylim=c(0, 1.2*max(c(a.logistic, a.mi.me))), xlim=c(0, max(5+nsimulac,as.numeric(res.WEIBUL3P.mime[8]))), col="green")


      if(bandplot==T){
        #polygon(xx, yy, col = "green", lty = 3, lwd = 3, border = "white", density = c(10, 20), angle = c(-45, 45))
        polig<-data.frame(xx.p=xx, yy.p=yy)
        polig<-polig[polig$xx.p!=c(0),]
        polig<-polig[polig$xx.p!=c(0.01),]
        polygon(polig$xx.p, polig$yy.p, col = "green", lty = 1, lwd = 2, border = "white", density = c(10, 10), angle = c(-45, 45))
        bandplot(yy.p ~ xx.p, data=polig, sd.col=c("magenta", "orange", "cyan", "orange", "magenta"),add=T)
        sav<-bandplot(yy.p ~ xx.p, data=polig, sd.col=c("magenta", "orange", "cyan", "orange", "magenta"),add=T)

      }


      #modelo weibull 4p (media) - con a logistic
      xxx.log<-unlist(lapply(res.WEIBUL3P.log[6], "[",1 ))
      yyy.log<-unlist(lapply(res.WEIBUL3P.log[6], "[",2 ))
      lines(as.numeric(xxx.log),as.numeric(yyy.log),lty=1,col="red",lwd=1)

      #modelo weibull 4p (lower ci) - con a mime
      xxx.mime<-unlist(lapply(res.WEIBUL3P.mime[6], "[",1 ))
      yyy.mime<-unlist(lapply(res.WEIBUL3P.mime[6], "[",2 ))
      lines(as.numeric(xxx.mime),as.numeric(yyy.mime),lty=1,col="blue",lwd=1)

      #numero maximo de otus sugrido con a logis
      abline(h=res.WEIBUL3P.log[4], col="red", lwd=0.5, lty=3)
      text(1,res.WEIBUL3P.log[4], paste("n=",round(as.numeric(res.WEIBUL3P.log[4]),1),",(",round(max(yy),1),")",sep=""),cex=0.75, col="red")


      #numero maximo de otus sugrido con a mime
      abline(h=res.WEIBUL3P.mime[4], col="blue", lwd=0.5, lty=3)
      text(1,res.WEIBUL3P.mime[4], paste("n=",round(as.numeric(res.WEIBUL3P.mime[4]),1),",(",round(max(yy),1),")",sep=""),cex=0.75, col="blue")


      #numero de muestras sugerido, para 95% maximo - con a logistic
      abline(v=res.WEIBUL3P.log[8], col="red", lwd=3, lty=3)
      #numero de muestras sugerido, para 95% maximo - con a weibull
      abline(v=res.WEIBUL3P.mime[8], col="blue", lwd=3, lty=3)

      #numero de muestras actual
      abline(v=nsimulac, col="green", lwd=2, lty=3)
    }


  }



  #decision de si satura o no satura
  #MODELOS
  as.numeric(res.WEIBUL3P.log[8])
  as.numeric(res.WEIBUL3P.mime[8])
  #actual
  nsimulac
  #MEDIA DE LOS MODELOS:
  media.num.samples95<-(as.numeric(res.WEIBUL3P.mime[8]) +  as.numeric(res.WEIBUL3P.log[8]))/2
  #numero de muestras medio
  abline(v=media.num.samples95, col="orange", lwd=4, lty=3)
  SATURATIVE.res<-NA
  #"NON-SATURATIVE-MODEL"---------
  if(media.num.samples95>nsimulac){
        SATURATIVE.res<-0
        result.sat<- "NON SATURATIVE-MODEL"
  }
  #"SATURATIVE-MODEL"
  if(media.num.samples95<nsimulac){
      SATURATIVE.res<-1
      result.sat<- "SATURATIVE-MODEL"
  }

  #indicar si la muestra testada stura o no
  if(plot.rep ==T){mtext(result.sat, col = "orange",cex = 2)}

  #salvar para calculos andreu paytuvi
  if(plot.rep ==T){
    #print(c(X1,range),c(X2,newdata))
    #salvar data-frame con datos curva esfuerzo y santuracion
    print("Se salvan en data.frame OTU.ACCUMULATION.CURVE")
    OTU.ACCUMULATION.CURVE.SAMPLES <-
      data.frame(samples=as.matrix(unlist(lapply(res.WEIBUL3P.log[6], "[",1 ))),
      predicted.OTU.LOGIS=as.matrix(unlist(lapply(res.WEIBUL3P.log[6], "[",2 ))), #logistic model
      predicted.OTU.MM=as.matrix(unlist(lapply(res.WEIBUL3P.mime[6], "[",2 ))), #MM model
      x.para.maximo.90.LOGIS=as.numeric(res.WEIBUL3P.log[7]), #logistic model
      x.para.maximo.95.LOGIS=as.numeric(res.WEIBUL3P.log[8]), #logistic model
      x.para.maximo.99.LOGIS=as.numeric(res.WEIBUL3P.log[9]), #logistic model
      x.para.maximo.90.MM=as.numeric(res.WEIBUL3P.mime[7]), #MM model
      x.para.maximo.95.MM=as.numeric(res.WEIBUL3P.mime[8]), #MM model
      x.para.maximo.99.MM=as.numeric(res.WEIBUL3P.mime[9]), #MM model
      max.LOGISTIC.model =as.numeric(res.WEIBUL3P.log[4]), #blue line horizontal
      max.MM.model =as.numeric(res.WEIBUL3P.mime[4]), #red line horizontal
      CURRENT.EFFORT.result=result.sat,
      samples.REAL=nsimulac)

    write.csv(OTU.ACCUMULATION.CURVE.SAMPLES, file = "OTU.ACCUMULATION.CURVESAMPLES.csv")


  }


  #resultados obtenidos
  samples=as.matrix(unlist(lapply(res.WEIBUL3P.log[6], "[",1 )))
  predicted.OTU.LOGIS=as.matrix(unlist(lapply(res.WEIBUL3P.log[6], "[",2 ))) #logistic model
  predicted.OTU.MM=as.matrix(unlist(lapply(res.WEIBUL3P.mime[6], "[",2 ))) #MM model
  x.para.maximo.90.LOGIS=as.numeric(res.WEIBUL3P.log[7]) #logistic model
  x.para.maximo.95.LOGIS=as.numeric(res.WEIBUL3P.log[8]) #logistic model
  x.para.maximo.99.LOGIS=as.numeric(res.WEIBUL3P.log[9]) #logistic model
  x.para.maximo.90.MM=as.numeric(res.WEIBUL3P.mime[7]) #MM model
  x.para.maximo.95.MM=as.numeric(res.WEIBUL3P.mime[8]) #MM model
  x.para.maximo.99.MM=as.numeric(res.WEIBUL3P.mime[9]) #MM model
  max.LOGISTIC.model =as.numeric(res.WEIBUL3P.log[4]) #blue line horizontal
  max.MM.model =as.numeric(res.WEIBUL3P.mime[4]) #red line horizontal
  CURRENT.EFFORT.result=result.sat
  samples.REAL=nsimulac

  if(plot.rep ==F){
    dev.off() #quitar el grafico anterior
  }
  #return
  return(list(c(nsimulac, max.LOGISTIC.model, max.LOGISTIC.model, max.MM.model,
                x.para.maximo.95.LOGIS,  x.para.maximo.95.MM, CURRENT.EFFORT.result, SATURATIVE.res)))

}



#creo que esta funcion es old-desfasada 2019
################################################################################
#1-funcion para el calculo de  curva de rarefaccion (parametrico MCMC) en metagenomics y sample size
################################################################################
PILI.MetagenSample.size <- function(matriu, zero=T, niter = 10, est.esp = "jack1", l99=F, l90=F, bandplot=F, plot.rep=T) {

  #funcion del 1.1.2018 al 18.12.2018

      #utiliza las funciones logistica y la funcion Michalis-menten

      #library(R2jags) #JAGS
      library(vegan)
      library(proto)
      library(nls2)
      library(ggtern)
      library(gplots)
      library(rcompanion) #calcula la R2 aproximada para los modelos

      #options(show.error.messages = F)
      options(show.error.messages = F)
      options(warn = -1)

      nsimulac<- ncol(matriu)
      nsites <- nrow(matriu)
      #niter <- 50

      #toda la parte bayesiana (solo si se pide o numero de muestras es <=3###############################################################
      if(nsites <4){
        print("THE SAMPLE SIZE MUST BE > 3")
        stop("Ending function")
      }



      #MODELO BASICO PARA LA PREDICCION DEL NUMERO DE OTUS-MAXIMO Y DEL ESFUERO DE MUESTREO (SAMPLING EFFORT)
      #remove 0 if all the columns are 0 or not
      if(zero==T){ #solo funciona si no hay filas con 0 OTUs y con mas de 3 muestras
          matriu<-matriu[which(rowSums(matriu) > 0),]

          #recojo todas las Y
          #out.y <- matrix(NA, 500 )

          #representar la prediccion de especies por bootstrap
          #repetirlo nsim veces y recoger los estadisticos de lo que pasa
          #for (i in 1:nsim){
          for(i in 1:niter){
            #i<-2
            #prediccion de especies mediante poolaccum de VEGAN
            out2 <- try(res1<-  poolaccum(t(matriu)))
            #data.apilado<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$chao[,1]))
            if(i==1){
              if (est.esp=="jack1"){
                data.apilado<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$jack1[,1]))
              }
              if (est.esp=="boot"){
                data.apilado<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$boot[,1]))
              }
              if (est.esp=="chao"){
                data.apilado<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$chao[,1]))
              }
            }
            if(i>1){
               if (est.esp=="jack1"){
                  data.apilado1<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$jack1[,1]))
                }
                if (est.esp=="boot"){
                  data.apilado1<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$boot[,1]))
                }
                if (est.esp=="chao"){
                  data.apilado1<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$chao[,1]))
                }
              #data.apilado1<- data.frame(xx=c(0, 0.01, res1$N),yy=c(0, 0.01, res1$est.esp[,1]))
              data.apilado<-rbind(data.apilado,data.apilado1)
            }
          }
          xx<-data.apilado$xx
          yy<-data.apilado$yy
            #datos del boottrap para predecir especies
            #xx<-c(0, 0.01, res1$N)
            #yy<-c(0, 0.01, res1$est.esp[,1])
            #prediccion inicial del num especies de Bootstrap
            #predicted.otu.boot <- res1$est.esp[length(res1$N),1]
            predicted.otu.boot <- mean(data.apilado[data.apilado$xx==max(data.apilado$xx),2])

            #######################################################
            #PROBAR MODELOS COMO WEIBULL Y LOS OTROS Y CALCULAR R2
            #print("ajuste de modelos no lineales: Efron.r.squared")
            #model.SSlogis<-NA
            #out2 <- try(model.SSlogis <- nls(yy ~ SSlogis(xx, a, b, c)))
            #SSlogis.model<-accuracy(list( model.SSlogis),
            #                plotit=TRUE, digits=3)$Fit.criteria[,c(1,5,10)]
            #print("logis model")
            #print(SSlogis.model)

            #model.SSasympOrig<-NA
            #out2 <- try(model.SSasympOrig <- nls(yy ~ SSasympOrig(xx, a, b)))
            #SSasympOrig.model<-accuracy(list( model.SSasympOrig),
            #                plotit=TRUE, digits=3)$Fit.criteria[,c(1,5,10)]
            #print("SSasympOrig")
            #print(SSasympOrig.model)



            #model.SSgompertz<-NA
            #out2 <- try(model.SSgompertz <- nls(yy ~ SSgompertz(xx, a, b, c)))
            #SSgompertz.model<-accuracy(list( model.SSgompertz),
            #                plotit=TRUE, digits=3)$Fit.criteria[,c(1,5,10)]
            #print("SSgompertz")
            #print(SSgompertz.model)


            #model.SSmicmen<-NA
            #out2 <- try(model.SSmicmen <- nls(yy ~ SSmicmen(xx, a, b)))
            #SSmicmen.model<-accuracy(list(model.SSmicmen),
            #                plotit=TRUE, digits=3)$Fit.criteria[,c(1,5,10)]
            #print("SSmicmen")
            #print(SSmicmen.model)

            #model.SSweibull<-NA
            #out2 <- try(model.SSweibull <- nls(yy ~ SSweibull(xx, a, b, c, d)))
            #SSweibull.model<-accuracy(list(model.SSweibull),
            #                plotit=TRUE, digits=3)$Fit.criteria[,c(1,5,10)]
            #print("SSweibull")
            #print(SSweibull.model)


            #model.SSasymp<-NA
            #out2 <- try(model.SSasymp <- nls(yy ~SSasymp(xx, a, b, c)))
            #SSasymp.model<-accuracy(list(model.SSasymp),
            #                plotit=TRUE, digits=3)$Fit.criteria[,c(1,5,10)]
            #print("SSasymp")
            #print(SSasymp.model)

            #################################################3

            #logistic saturative model - curve (logistic)-two steps
            out2 <- try(logistic<-nls2(yy~predicted.otu.boot/(1+exp(-(b+c*xx))),
                        start=list(b=-8,c=100),trace=F))
            #if (substr(out2[1],1,5)=="Error"){ "error aqui nls2-logistic"}
            #if (substr(out2[1],1,5)!="Error"){
              a1<-predicted.otu.boot
              b1<-summary(logistic)$coefficients[1,1]
              c1<-summary(logistic)$coefficients[2,1]
              summary(logistic)

              logistic<-nls2(yy~a/(1+exp(-(b1+c*xx))),
                             start=list(a=a1, c=c1),trace=F)
              a1<-summary(logistic)$coefficients[1,1]
              predicted.otu.boot.2 <- a1
              #predict logistic by means spline
              ksmooth.log<-ksmooth(xx, predict(logistic), "normal", bandwidth = 3)
              smoothingSpline = smooth.spline(ksmooth.log$x, ksmooth.log$y)
              aaa.lo<-predict(smoothingSpline, data.frame(xx = seq(0, max(xx)+5, by = 0.5)) )
              res.6<-accuracy(list(logistic),
                              plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
              #print("Efron.r.squared: logistic nls2")
              #print(res.6)
            #}

            #model Michaelis-Menten (no saturativo?)
            #for simple models nls find good starting values for the parameters even if it throw a warning
            #mi.me<-nls2(yy~(a*xx)/(b+xx),start=list(a=predicted.otu.boot,b=.9))
            #a.mi.me<-summary(mi.me)$coefficients[1,1]
            #b<-summary(mi.me)$coefficients[2,1]
            #predict MM
            #ksmooth.log<-ksmooth(xx, predict(mi.me), "normal", bandwidth = 3)
            #smoothingSpline1 = smooth.spline(ksmooth.log$x, ksmooth.log$y)
            #aaa.me<-predict(smoothingSpline1, data.frame(xx = seq(0, max(xx)+5, by = 0.5)) )
            #mi.me<-nls2(yy~(a*xx)/(b+xx),start=list(a=predicted.otu.boot))
            #a.mi.me<-summary(mi.me)$coefficients[1,1]
            fo <- yy ~ (a*xx) / (b+xx)
            # pass our own set of starting values
            # returning result of brute force search as nls object
            st1 <- expand.grid(a = seq(0, predicted.otu.boot*2, len = 150),
                               b = seq(-20, 20, len = 150))
            out2 <- try(mi.me <- nls2(fo, start = st1, algorithm = "brute-force"))
            #if (substr(out2[1],1,5)=="Error"){print("error aqui nls2-brute force") }
            #if (substr(out2[1],1,5)!="Error"){
              mi.me
              # use nls object mod1 just calculated as starting value for
              # nls optimization.  Same as:
              mi.me<-nls2(fo, start = coef(mi.me),algorithm = "plinear-brute")
              ksmooth.log<-ksmooth(xx, predict(mi.me), "normal", bandwidth = 4)
              smoothingSpline1 = smooth.spline(ksmooth.log$x, ksmooth.log$y)
              aaa.me<-predict(smoothingSpline1, data.frame(xx = seq(0, max(xx)+5, by = 0.5)) )
              #lines(as.matrix(aaa.me$y)~as.matrix(aaa.me$x))
              a.mi.me<-summary(mi.me)$coefficients[1,1]
              #max(unlist(ksmooth.log))
              res.6<-accuracy(list(mi.me),
                              plotit=F, digits=3)$Fit.criteria[,c(1,5,10)]
              #print("Efron.r.squared: Michaelis-Menten nls2")
              #print(res.6)


              #para el modelo michalis-mente, comprobar si el vector va bien o no
              a.mi.me<-summary(mi.me)$coefficients[1,1]
              l1<-length(as.matrix(aaa.me$y))
              if(a1<(as.matrix(aaa.me$y)[l1])){
                  a.mi.me<-as.matrix(aaa.me$y)[l1]
                  # cambiar tambien la predicción si da más bajo que el logistico, no puede ser pendiente negativa
                  #aaa.me$y <- smoothingSpline1$y
                  #aaa.me$x <- smoothingSpline1$x
              }
              #comprobar para el modelo Michaelis-menten si el ultimo valor del vector es menor que la estimacion asindotica (probelma numerico)
              if(a.mi.me<(as.matrix(aaa.me$y)[l1])){
                a.mi.me<-as.matrix(aaa.me$y)[l1]
              }
            #}
            #plot
            #plot(xx,yy,type = 'l',xlab="SAMPLES" ,ylab="Future OTUs",
            #     main="OTU ACCUMULATION CURVE", sub="Red=logistic model, Blue=Michalis-menten model, Green=real",
            #     ylim=c(0, 1.2*max(c(a1, a.mi.me))), xlim=c(0, 5+nsimulac), col="green")
            #par(bg="yellow")

            #solo si pido representarlo
            if(plot.rep ==T){
                  plot(0,0,type = 'l',xlab="SAMPLES" ,ylab="Future OTUs",
                       main="OTU ACCUMULATION CURVE", sub="Red=logistic model, Blue=Michalis-menten model, Green=Jack,Chao,Boot",
                       ylim=c(0, 1.2*max(c(a1, a.mi.me))), xlim=c(0, 5+nsimulac), col="green")


                  if(bandplot==T){
                    #polygon(xx, yy, col = "green", lty = 3, lwd = 3, border = "white", density = c(10, 20), angle = c(-45, 45))
                    polig<-data.frame(xx.p=xx, yy.p=yy)
                    polig<-polig[polig$xx.p!=c(0),]
                    polig<-polig[polig$xx.p!=c(0.01),]
                    polygon(polig$xx.p, polig$yy.p, col = "green", lty = 1, lwd = 2, border = "white", density = c(10, 10), angle = c(-45, 45))
                    bandplot(yy.p ~ xx.p, data=polig, sd.col=c("magenta", "orange", "cyan", "orange", "magenta"),add=T)
                  }
                    #modelo logistico
                  lines(as.matrix(aaa.lo$x),as.matrix(aaa.lo$y),lty=2,col="red",lwd=4)
                  #get some estimation of goodness of fit
                  #modelo MM
                  lines(as.matrix(aaa.me$x),as.matrix(aaa.me$y),lty=2,col="blue",lwd=4)
                  #lines(xx,predict(wilson),lty=2,col="blue",lwd=3)
                  #prediction.otu<-summary(m)$coefficients[1,1]
                  #text(2,0,  round(summary(m)$coefficients[1,1],1))
                  #text(4,0,  round(summary(m)$coefficients[2,1],1))
                  #modelo logistico
                  abline(h=predicted.otu.boot.2, col="red", lwd=0.5, lty=3)
                  text(1,predicted.otu.boot.2, paste("n=",round(predicted.otu.boot.2,1),",(",round(predicted.otu.boot,1),")",sep=""),cex=0.75, col="red")

                  #modelo michalis-menten
                  abline(h=a.mi.me, col="blue", lwd=0.5, lty=3)
                  text(1,predicted.otu.boot.2 -15, paste("n=",round(a.mi.me,1),sep=""),cex=0.75, col="blue")

                  #numero de muestras actual
                  abline(v=nsimulac, col="green", lwd=2, lty=3)
            }


            #predicted.otu.boot/(1+exp(-(b1+c1*0.1)))

            #FUNCION LOGISTICA#################################################################
            #calculo de los esfuerzos con la funcion logistica SATURATIVA-----------------
            #funcion logistica y = a*X/(b+X)
            #coef(myFit1) #coeficientes a y b de la funcion
            #inversa de la logistica X= yb/(a-y)  str(myFit1 )
            #get some estimation of goodness of fit
            #cor(X2,predict(myFit1))
            #a<-15



            effort.sample <- function(xx, model=logistic, y.90, y.95, y.99){
              #funtion to estimate the x effort sampling (sample)
              #predict logistic by means spline
              ksmooth.mod<-ksmooth(xx, predict(model), "normal", bandwidth = 4)
              smoothingSpline.b = smooth.spline(ksmooth.mod$x, ksmooth.mod$y)
              aaa.b<-predict(smoothingSpline.b, data.frame(xx = seq(0, max(xx)+5, by = 0.25)) )


              long<-as.numeric(length(as.matrix(aaa.b$x)))
              for (i in 1:long){
                #i<-12
                #funcion
                #xi<-10
                #val.y<-(a*xi)/(b+xi)
                #val.y<-(a*12.05)/(b+12.05)
                xi1<-as.matrix(aaa.b$x)[i]
                val.y <- as.matrix(aaa.b$y)[i]
                #print(xi1)
                #print(val.y)
                if(val.y<=y.90){x.90=xi1}
                if(val.y<=y.95){x.95=xi1}
                if(val.y<=y.99){x.99=xi1}
                #print(unlist(aaa.b$y)[i])
              }
              return(list(x.90, x.95, x.99))
            }
            #esfuerzo 90%, 95 Y 99%-logistic
            y.90.lo <- 0.90*predicted.otu.boot
            y.95.lo <- 0.95*predicted.otu.boot
            y.99.lo <- 0.99*predicted.otu.boot
            eff.sam<-effort.sample(xx, model=logistic, y.90.lo, y.95.lo, y.99.lo)
            if(plot.rep ==T){
              abline(v=eff.sam[2],col="red", lwd=2, lty=4)
              if(l99==T){abline(v=eff.sam[3], col="red",lwd=0.25, lty=5)}
              if(l90==T){abline(v=eff.sam[1], col="red",lwd=0.25, lty=2)}
            }

            #abline(v=eff.sam[3], col="blue",lwd=0.25, lty=2)
            eff.lo<-c(eff.sam[1], eff.sam[2], eff.sam[3])
            #esfuerzo 90%, 95 Y 99%-MM non saturativ
            y.90.mime <- 0.90*a.mi.me
            y.95.mime <- 0.95*a.mi.me
            y.99.mime <- 0.99*a.mi.me
            eff.sam<-effort.sample(xx, model=mi.me, y.90.mime, y.95.mime, y.99.mime)
            if(plot.rep ==T){
              abline(v=eff.sam[2],col="blue", lwd=2, lty=4)
              if(l99==T){abline(v=eff.sam[3], col="blue",lwd=0.25, lty=5)}
              if(l90==T){abline(v=eff.sam[1], col="blue",lwd=0.25, lty=2)}
            }

            eff.mi.me<-c(eff.sam[1], eff.sam[2], eff.sam[3])

            #TEXT CON SI DETERMINA QUE EL MODELO SATURA O NO
            un1<-saturation.curve(matriu=matriu, a1<-predicted.otu.boot.2,a2<-a.mi.me )
            if(un1[1]=="NON-SATURATIVE-MODEL"){
              if(plot.rep ==T){text(1.5,1.2*max(c(a1, a.mi.me)), un1[1], col="blue",cex = 0.75)}
              SATURATIVE.res<-0
            }
            if(un1[1]=="SATURATIVE-MODEL"){
              if(plot.rep ==T){text(1.5,1.2*max(c(a1, a.mi.me)), un1[1], col="red",cex = 0.75)}
              SATURATIVE.res<-1
            }

            #escribir x95lo y x95 mime
            aaa2<-as.numeric(eff.lo[2])
            if(plot.rep ==T){text(eff.lo[2],0, aaa2,cex = 0.75)}
            aaa3<-as.numeric(eff.mi.me[2])
            if(plot.rep ==T){text(eff.mi.me[2],0, aaa3,cex = 0.75)}

          #print los resultados, si se lo solicito
          if(plot.rep ==T){
            print("Max number of OTUS (bootstrap)-logistic saturative: ----------")
            print(predicted.otu.boot)
            print(predicted.otu.boot.2)
            print("Max number of OTUS (bootstrap)-MM non saturative: ----------")
            print(a.mi.me)

            print("Sample effort (logistic saturative model):-----------------------------")
            print("samples 90%, 95% y 99%")
            print(eff.lo)


            print("Sample effort (MM non saturative model):-----------------------------")
            print("samples 90%, 95% y 99%")
            print(eff.mi.me)
          }
    }

      #lines(as.matrix(aaa.lo$x),as.matrix(aaa.lo$y),lty=2,col="blue",lwd=4)
      #get some estimation of goodness of fit
      #modelo MM
      #lines(as.matrix(aaa.me$x),as.matrix(aaa.me$y),lty=2,col="red",lwd=4)

      #print("###############datos curva#####################")
      #diferencia.predicts <-100*abs(as.numeric(y.95.mime) - as.numeric(y.95.lo))/as.numeric(y.95.mime)

      #resultado
      mean.y.95.mime.lo<-NA
      result<-"sampling-ok"
      if(as.numeric(eff.mi.me[2])>nsimulac | as.numeric(eff.lo[2])>nsimulac){
        result<-"under-sampled"
        result.1<-0
        mean.y.95.mime.lo<- mean(c(unlist(eff.lo)[2], unlist(eff.mi.me)[2]))
        if(plot.rep ==T){abline(v=mean.y.95.mime.lo,col="orange", lwd=3, lty=5)}
        #par(bg = 'yellow')
        if(plot.rep ==T){mtext(result, col = "yellow",cex = 2)}
      }
      if(as.numeric(eff.mi.me[2])<=nsimulac & as.numeric(eff.lo[2])<=nsimulac){
          result<-"over-sampled"
          result.1<-1
          if(plot.rep ==T){mtext(result, col = "magenta",cex = 2)}
      }
      if(as.numeric(eff.mi.me[2])<=nsimulac & as.numeric(eff.lo[2])<=nsimulac & un1=="SATURATIVE-MODEL"){
        #result<-"sampling-ok"
        #mtext(result, col = "green" ,cex = 2)

      }

      if(plot.rep ==T){
            #print(c(X1,range),c(X2,newdata))
            #salvar data-frame con datos curva esfuerzo y santuracion
            print("Se salvan en data.frame OTU.ACCUMULATION.CURVE")
            OTU.ACCUMULATION.CURVE.SAMPLES <- data.frame(samples=as.matrix(aaa.lo$x),
                                                 predicted.OTU.LOGIS=as.matrix(aaa.lo$y), #logistic model
                                                 predicted.OTU.MM=as.matrix(aaa.me$y), #MM model
                                                 x.para.maximo.90.LOGIS=as.numeric(eff.sam[1]), #logistic model
                                                 x.para.maximo.95.LOGIS=as.numeric(eff.sam[2]), #logistic model
                                                 x.para.maximo.99.LOGIS=as.numeric(eff.sam[3]), #logistic model
                                                 x.para.maximo.90.MM=as.numeric(eff.lo[1]), #MM model
                                                 x.para.maximo.95.MM=as.numeric(eff.lo[2]), #MM model
                                                 x.para.maximo.99.MM=as.numeric(eff.lo[3]), #MM model
                                                 max.LOGISTIC.model =as.matrix(aaa.lo$y), #blue line horizontal
                                                 max.MM.model =as.matrix(aaa.me$y), #red line horizontal
                                                 CURRENT.EFFORT.result=result,
                                                 samples.REAL=nsimulac)
            write.csv(OTU.ACCUMULATION.CURVE.SAMPLES, file = "OTU.ACCUMULATION.CURVESAMPLES.csv")

            #print(OTU.ACCUMULATION.CURVE)
            print("###################################################")
            print("Suggested mean Mime-logistic")
            print(mean.y.95.mime.lo)
      }
      return(list(c(nsimulac, predicted.otu.boot, predicted.otu.boot, a.mi.me, eff.lo[2],
                    eff.mi.me[2], result.1, SATURATIVE.res)))



}



####################################################################################################################
# 2-Funcion inverse.function() -LOESS: calculate loess the inverse function of a spline
####################################################################################################################
inverse.function <- function(data.x.y, y.i, punt_t){

  #options( warn = -1 )

  #calculate the inverse function of a spline

  #punt_t es el punto en el cual se encuentra el maximo de la funci?n fitted
  # y.i es el maximo

  #y.i <- 6.5
  #data.x.y <- data.frame(x=c(1,2,3,4,5, 6, 7), y=c(2,4,6,8,10, 12, 14))
  #attach(data.x.y)
  data.x.y <- subset(data.x.y, x < punt_t)
  #attach(data.x.y)

  plx<-loess(x ~ y, control = loess.control(surface =  "direct",degree = 3), data=data.x.y)
  aaa<- predict(plx, data.frame(y = y.i), se = TRUE)
  aaa$fit
  LCI<-aaa$fit - qt(0.975,aaa$df)*aaa$se
  UCI<-aaa$fit + qt(0.975,aaa$df)*aaa$se


  return(c(aaa$fit, LCI,  UCI))
  #detach(data.x.y)
}




####################################################################################################################
# 3-funcion saturation.curve() - ANALISIS GRaFICO DE LA SATURACION DE UNA CURVA DE RAREFACCION: CURVA SATURA/ NO SATURA
####################################################################################################################
#model.loess=plx,range=c(0,1,2,3,4,5,6,7,8,9,20)
#aasd<-saturation.curve(matriu)
saturation.curve <- function(matriu, a1, a2, tol=2){

  options(show.error.messages = T)


  #model.loess=plx,range
  #ejemplo de prueba
  #X1=c(0,1,2,3)
  #X2=c(0, 70, 92, 96)
  #plot(X1,X2)

  #options(warn=0)
  #(PASO 1.2) Local Polynomial Regression Fitting (LPR):  CALCULAR LA ASINDOTA Y ver si la curva satura o no satura entre 1 a 15M
  #se hace una regresi?n para ver los valores
  #x.1<- range  #c(5, 10, 15)

  #regression loess del chao
  #res1<-poolaccum(t(matriu))
  #plot(c(0,res1$N),c(0,res1$chao[,1]))
  #data.x.y <- data.frame(x=res1$N, y=res1$boot[,1])
  #ksmooth.pred<-ksmooth(data.x.y$x, data.x.y$y, "normal", bandwidth = 4)
  #smoothingSpline1 = smooth.spline(ksmooth.log$x, ksmooth.log$y)
  #aaa.me<-predict(smoothingSpline1, data.frame(xx = seq(0, max(xx)+5, by = 0.5)) )
  #res <- lm(as.matrix(aaa.me$y)~as.matrix(aaa.me$x))
  #    summary(res)
  #    res$coefficients #si la pendiente es negativa -> SATURACION / si la pendiente es >1-> NO SATURACION
  #    Asym1.sp.pendiente <- res$coefficients[2] #R2 para pendiente de la asindota segun la funcion polinomica splines
  if( abs(a2- a1) <=tol | a2<a1){ #cuidado
  #    if (res$coefficients[2]<=1){ #no saturan SI PENDIENTE DE CURVA > 1
        #(PASO 1.3) Local Polynomial Regression Fitting (LPR):  CALCULO EL MAXIMO DE GENES PARA LOS QUE NO SATURAN
        #si no tiene asindota antes de los 15 millones
        #x.1<-c(1, 5, 10, 15, 17, 19, 20, 21, 22, 23, 24, 25, 30, 33, 35, 40, 42, 45, 50, 55, 75, 100, 125,200)
        #ass1 <- predict(model.loess, data.frame(x.1), se = TRUE) #ASINDOTA PARA LAS CURVAS QUE NO SATURAN
        #y.11<-ass1$fit
        #res1 <- lm(y.11~x.1)
        #summary(res1)
        #ass1$fit
        #res1$coefficients[2]
        #Asym1.sp <- max(ass1$fit)

        #print("La curva no satura: HAY QUE HACER MAS SAMPLES")
        #print("maximo numero de OTU a 2 veces el numero de samples:")
        #print(max(ass$fit))
        Asym1.sp.pendiente.label <-"SATURATIVE-MODEL"
      } else {
        #si que se saturan
        #Asym1.sp <- max(ass$fit) #asindota segun la funcion polinomica splines
        #print("La curva satura: NO HAY QUE HACER MAS SAMPLES")
        Asym1.sp.pendiente.label <-"NON-SATURATIVE-MODEL"
      }
  #}



  #print(Asym1.sp)

  return(list(Asym1.sp.pendiente.label))

      options (show.error.messages = F)
}







##########################################################################
# 4-funcion plot.Weibull.CI() - ANALISIS GRaFICO DEL TAMANO MUESTRAL EN METAGENOMICA CON FUNCION DE CRECIMIENTO SATURATIVA WEIBULL
###########################################################################

#matriu<-data.frame(matyy[2])
#representar grafica weibull para la situacion concreta
#funci?n search.OTU.N()
plot.Weibull.CI <- function(matriu, noptima=F, esfuerzo90=0, esfuerzo95=0, esfuerzo99=0, etiq="% discrim", esfuerzo.actual=0) {

  #options(warn=0)

  #par?metros: matriz de los datos del remuestreo, esfuerzos del 90 al 99% de los otus

  #defino funciones previas
  ##################################################################################
  # funcion as.lm.nls() para intervalo de prediccion 95% Weibull o de cualquier nls
  # funcion interna para los IC9%% Weibull
  ##################################################################################
  as.lm <- function(object, ...) UseMethod("as.lm")

  as.lm.nls <- function(object, ...) {
    if (!inherits(object, "nls")) {
      w <- paste("expected object of class nls but got object of class:",
                 paste(class(object), collapse = " "))
      warning(w)
    }

    gradient <- object$m$gradient()
    if (is.null(colnames(gradient))) {
      colnames(gradient) <- names(object$m$getPars())
    }

    response.name <- if (length(formula(object)) == 2) "0" else
      as.character(formula(object)[[2]])

    lhs <- object$m$lhs()
    L <- data.frame(lhs, gradient)
    names(L)[1] <- response.name

    fo <- sprintf("%s ~ %s - 1", response.name,
                  paste(colnames(gradient), collapse = "+"))
    fo <- as.formula(fo, env = as.proto.list(L))

    do.call("lm", list(fo, offset = substitute(fitted(object))))

  }



  #mODELO WEIBULL DE 4 PARAMETROS
  mat.res.weib <- matriu #data.frame de los resultados
  #GRAFICA DE TODOS LOS REMUESTREOS:
  if (noptima==F){ #representacion experimento
    plot(mat.res.weib$X1, mat.res.weib$X2, col="blue", xlab="% OTU", ylab=etiq, xlim=c(0,100))
  }
  if (noptima==T){ #calculo tama?o muestral

    #crear el data frame de los untos de n encontrados:

    #mat.res.weib

    as1<- data.frame(mat.res.weib$X2, mat.res.weib$X5)
    colnames(as1)=c("X1", "X2")
    as2<- data.frame(mat.res.weib$X2, mat.res.weib$X6)
    colnames(as2)=c("X1", "X2")
    as3<- data.frame(mat.res.weib$X2, mat.res.weib$X7)
    colnames(as3)=c("X1", "X2")
    mat.res.weib1<- rbind(as1, as2, as3)
    mat.res.weib1 <- mat.res.weib1[order(mat.res.weib1[,1]),]
    plot(mat.res.weib1$X1, mat.res.weib1$X2, col="blue", xlab="N (sample size/group)", ylab=etiq, ylim=c(0,max(mat.res.weib1$X2)))
  }

  #calculo de la muestra
  if (noptima==T){ #an?lisis del calculo tama?o muestral con splines

    #plot( x.1, y.1)
    plx<-loess(X2 ~ X1, control = loess.control(surface =  "direct"), se=T, data=mat.res.weib1)
    aaa<- predict(plx, data.frame(X1 = mat.res.weib1$X1), se = TRUE)
    x.1.1 <- mat.res.weib1$X1
    lines(x.1.1, aaa$fit)
    lines(x.1.1,aaa$fit - qt(0.975,aaa$df)*aaa$se, lty=2, col = "red")
    lines(x.1.1,aaa$fit + qt(0.975,aaa$df)*aaa$se, lty=2, col = "red")


    #analisis del m?ximo local
    i.max <- as.numeric(localMaxima(aaa$fit)[1])#maximo local con el primer par?metro que se indique
    x.max <- mat.res.weib1[i.max,1]
    abline(v=x.max, col="red")
    abline(v=esfuerzo90, col="green")
    abline(v=esfuerzo95, col="green")
    abline(v=esfuerzo99, col="green")

    "Optimum Sample size (OSS)"
    plot(0,0)
    mtext( "Sample size (local maximum):",  line = -10)
    mtext( round(x.max,0), col="red",  line = -11)
    mtext(" Sample size(bootstrap): 90%,95%,99% for max.",  line = -5)
    mtext( round(esfuerzo90,0), col="green",  line = -6)
    mtext( round(esfuerzo95,0), col="green",  line = -7)
    mtext( round(esfuerzo99,0), col="green",  line = -8)



  }

  #funciones weibull para representar y analizar la grafica
  if (noptima==F){ #representacion experimento con remuestreos
    #modelo Weibull de 4 par?metros:
    model.SSweibull <- try(nls2(X2 ~ SSweibull(X1, Asym, Drop, lrc, pwr), data = mat.res.weib ))
    if (class(model.SSweibull) =="nls"){
      print("entra en weibull 4 parametros")
      #MODELO WEIBULL DE 4 PARAMeTRos
      summary(model.SSweibull)   #ver los par?metros estimados
      Asym1<-summary(model.SSweibull)$parameters[1]
      Asym1#se guarda en este array
      EE.Asym1 <- summary(model.SSweibull)$parameters[1,2] #error estandart de la estimaci?n
      EE.Asym1
      #intervalos de confianza de las predicciones
      Asym1.l95 <-  Asym1 - 1.96* EE.Asym1
      Asym1.l95
      Asym1.u95 <-  Asym1+ 1.96* EE.Asym1
      Asym1.u95
      #parametro del punto de inflexion en X (n? OTU)
      pwr <- summary(model.SSweibull)$parameters[4]
      pwr.l95 <- summary(model.SSweibull)$parameters[4] - 1.96*summary(model.SSweibull)$parameters[4,1] #parametro pwr asindota CI95% inferior
      pwr.u95 <- summary(model.SSweibull)$parameters[4] + 1.96*summary(model.SSweibull)$parameters[4,1] #parametro pwr asindota CI95% inferior

      #representar modelo Weibull estimado de 4 par?metros
      curve(summary(model.SSweibull)$parameters[1]-summary(model.SSweibull)$parameters[2]*
              exp(-exp(summary(model.SSweibull)$parameters[3])*x^summary(model.SSweibull)$parameters[4]), col = "RED", lwd = 2, add = TRUE)


      #prediccion del 95%. IC95%
      predCI <- predict(as.lm.nls(model.SSweibull), interval = "confidence", level = 0.95)
      class(predCI)

      #lineas de los intervalos de confianza
      xx<- mat.res.weib$X1
      lines(xx,predCI[,2],col="blue",lty=2)
      lines(xx,predCI[,3],col="blue",lty=2)

      #escribir en el plot:
      text(70, 0.08, "nls Weibull growth model 4 parameters", cex = .8)
      pwr.l95ll <- as.numeric(pwr.l95)
      if(pwr.l95ll < 0){pwr.l95ll<- 0.1}
      abline(v=pwr.u95, lty=3, col= "green")
      abline(v=pwr.l95ll, lty=3, col= "green")

      #dibujar los esfuerzos:
      #abline(v=esfuerzo90, col="green", lty=3)
      #abline(v=esfuerzo95, col="green", lty=3)
      #abline(v=esfuerzo99, col="green", lty=3)
      #summary(model.SSweibull)
      Asym<-summary(model.SSweibull)$parameters[1]
      Drop<-summary(model.SSweibull)$parameters[2]
      lrc<-summary(model.SSweibull)$parameters[3]
      pwr<-summary(model.SSweibull)$parameters[4]

      print("Asimptote:")
      print(Asym)
      print("Asimptote CI95% LL:")
      print(Asym1.l95)
      print("Asimptote CI95% LL:")
      print(Asym1.u95)

      print("-------------------------------------------")
      print("ESFUERZO ACTUAL (% respect maximum)")
      #esfuerzo para el 90% del maximo de genes
      #el modelo es: Asym*(1 - exp(-exp(lrc)*input))
      #la funcion inversa es: log((y/Asym)-1)/(-exp(lrc))
      alt<- Asym-Drop*exp(-exp(lrc)*esfuerzo.actual^pwr)
      esf.a<- 100*(alt/Asym)
      print(esf.a)
      print("-------------------------------------------")

      print("Drop:")
      print(Drop)
      print("lrc:")
      print(lrc)
      print("pwr:")
      print(pwr)
      #1.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
      y <- 0.90*Asym
      x.para.maximo.90<- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr) #inversa
      x.para.maximo.90
      print("effort to reach a time of the 90% of the maximum of the cumulative.survival curve")
      print(x.para.maximo.90)
      print("-------------------------------------------")

      #2.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
      y <- 0.95*Asym
      x.para.maximo.95<- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
      x.para.maximo.95
      print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve")
      print(x.para.maximo.95)
      print("-------------------------------------------")

      #3.effort to reach a time of the 90% of the maximum of the cumulative.survival curve
      y <- 0.99*Asym
      x.para.maximo.99<- (log((Asym-y)/Drop)/-exp(lrc))^(1/pwr)
      x.para.maximo.99
      print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
      print(x.para.maximo.99)
      print("FINAL DE LA FUNCION")

    }

    if (class(model.SSweibull) != "nls") {
      #weibull 2 parametros
      #Self-Starting Nls Asymptotic Regression Model through the Origin: modelo weibull sencillo 2 par?metros
      #https://stat.ethz.ch/R-manual/R-devel/library/stats/html/SSasympOrig.html
      #MODELO WEIBULL DE 2 PARAMATRos
      #print("entra antes de en weibull 2 parametros")
      model.SSweibull1 <- nls(X2 ~ SSasympOrig(X1, Asym, lrc), data = mat.res.weib)
      if (class(model.SSweibull1) =="nls"){

        #si todo va bien:
        #ver los par?metros estimados
        summary(model.SSweibull1)
        Asym1<-summary(model.SSweibull1)$parameters[1]
        Asym1#se guarda en este array
        Asym1
        EE.Asym1 <- summary(model.SSweibull1)$parameters[1,2] #error estandart de la estimaci?n
        EE.Asym1

        #intervalos de confianza de las predicciones
        Asym1.l95 <-  Asym1 - 1.96* EE.Asym1
        Asym1.l95
        Asym1.u95 <-  Asym1+ 1.96* EE.Asym1
        Asym1.u95

        #parametro del n? de otus optimo
        pwr <- NA
        pwr.l95 <- NA
        pwr.u95 <- NA

        #representar modelo Weibull estimado de 4 par?metros
        curve(summary(model.SSweibull1)$parameters[1]*(1-exp(-exp(summary(model.SSweibull1)$parameters[2])*x)), col = "RED", lwd = 2, add = TRUE)

        #modelo:       Asym*(1 - exp(-exp(lrc)*input)).


        #prediccion del 95%. IC95%
        predCI <- predict(as.lm.nls(model.SSweibull1), interval = "confidence", level = 0.95)
        class(predCI)

        #lineas de los intervalos de confianza
        x<- mat.res.weib$X1
        #lines(x,predCI[,1],col="red",lty=2)
        #lines(x,predCI[,2],col="blue",lty=2)
        #lines(x,predCI[,3],col="blue",lty=2)


        #escribir en el plot:
        text(70, 0.08, "nls Weibull growth model 2 parameters", cex = .8)
        #pwr.l95ll <- as.numeric(pwr.l95)
        #if(pwr.l95ll < 0){pwr.l95ll<- 0.1}
        #abline(v=pwr.u95, lty=3, col= "green")
        #abline(v=pwr.l95ll, lty=3, col= "green")

        #dibujar los esfuerzos:
        #abline(v=esfuerzo90, col="grey", lty=3)
        #abline(v=esfuerzo95, col="grey", lty=3)
        #abline(v=esfuerzo99, col="grey", lty=3)


        #weibull 2 parametros:
        print("-------------------------------------------")
        print("Estimated parameters")
        print("Asimptote:")
        print(Asym1)
        Asym1<-summary(model.SSweibull1)$parameters[1]
        Asym1#se guarda en este array
        Asym1
        EE.Asym1 <- summary(model.SSweibull1)$parameters[1,2] #error estandart de la estimaci?n
        EE.Asym1

        #intervalos de confianza de las predicciones
        Asym1.l95 <-  Asym1 - 1.96* EE.Asym1
        Asym1.l95
        Asym1.u95 <-  Asym1+ 1.96* EE.Asym1
        Asym1.u95
        print("Asymptote CI LL:")
        print(Asym1.l95)
        print("Asymptote CI UL:")
        print(Asym1.u95)




        Asym<-summary(model.SSweibull1)$parameters[1]
        lrc<-summary(model.SSweibull1)$parameters[2]

        print("-------------------------------------------")
        print("ESFUERZO ACTUAL (% respect maximum)")
        #esfuerzo para el 90% del maximo de genes
        #el modelo es: Asym*(1 - exp(-exp(lrc)*input))
        #la funcion inversa es: log((y/Asym)-1)/(-exp(lrc))


        alt<- Asym*(1 - exp(-exp(lrc)*esfuerzo.actual))
        esf.a<- 100*(alt/Asym)
        print(esf.a)
        print("-------------------------------------------")

        #90% del esfuerzo maximo
        y <- 0.90*Asym
        x.para.maximo.90<- as.numeric(log(1-(y/Asym))/(-exp(lrc)) )
        print("effort to reach a time of the 90% of the maximum of the cumulative.survival curve 2 par")
        print(x.para.maximo.90)
        print("-------------------------------------------")

        #95% esfuerzo maximo
        y <- 0.95*Asym
        x.para.maximo.95<- as.numeric(log(1-(y/Asym))/(-exp(lrc)) )
        print("effort to reach a time of the 95% of the maximum of the cumulative.survival curve 2p")
        print(x.para.maximo.95)
        print("-------------------------------------------")

        #99% esfuerzo maximo
        y <- 0.99*Asym
        x.para.maximo.99<- as.numeric(log(1-(y/Asym))/(-exp(lrc)) )

        print("effort to reach a time of the 99% of the maximum of the cumulative.survival curve")
        print(x.para.maximo.99)
        print("-------------------------------------------")



      }


      #todo va mal
      if (class(model.SSweibull1) !="nls"){
        #intervalos de confianza de las predicciones
        Asym1<- NA
        Asym1.l95<- NA

        Asym1.u95<- NA

        #parametro del n? de otus optimo
        pwr <- NA
        pwr.l95 <- NA
        pwr.u95 <- NA
      }

    }


  }

  par(mfrow=c(1,1))

}



#####################################################################
# N-MIXTURES ABUNDANCE-RICHNESS MODEL OF SIMULATION
#####################################################################
################ MATRIZ SIMULADA CON VARIAS SUB-POBLACIONES CON N-MIXT##############################
#ver aqui
#https://groups.nceas.ucsb.edu/non-linear-modeling/projects/nmix/WRITEUP/nmix.pdf
#funcion para hacer simulaciones de N-mixturas
data.fn <-  function(R = 10, T = 5, lambda = 5, p0 = 1, p1 = 1, pSD = 0.5, nG = 40, xSD = 1){
  #     R: number of surveyed sites
  #     T: number of surveys at each site
  #     lambda: expected abundance
  #     p0: intercept of detection probability (logit scale)
  #     p1: slope of detection probability on covariate x (logit scale)
  #     pSD:       standard deviation of normal distribution from
  #     which observer effects u are drawn
  #     nG    : number of different observers    (called K in section 2)
  #     xSD: standard deviation of zero    -      mean normal distribution from
  #     which covariate values x are generated

  #     State equation:       Generate abundance from Poisson distribution
  N <-      rpois(R, lambda)

  # Draw values of covariate X
  x <-      rnorm(R, 0, xSD)

  # Generate observer ID array
  gID <-matrix(sort(rep(1:nG, 25)), nrow = R, ncol = T, byrow = TRUE)

  # Draw values of   covariate X
  x <-rnorm(R, 0, xSD)

  # Draw values of observer effects u and put them in R-T matrix
  u0 <-rnorm(nG, 0, pSD)
  u <-matrix(rep(u0, each =25), nrow = R, byrow = TRUE)

  # Compute R-T matrix of detection probability
  p <-plogis(p0 + p1 * x + u)

  #  Observation equation: Generate counts from Binomial distribution
  y <-array(dim = c(R, T))
  for(t in 1:T){
    y[,t] <-rbinom(R, N, p)
  }

  # Return stuff
  return(list(R=R, T=T, lambda=lambda, N=N, nG=nG, p0=p0, p1=p1, p=p,
              gID=gID, pSD=pSD, x=x, y=y, xSD=xSD, u=u, u0=u0))
}


