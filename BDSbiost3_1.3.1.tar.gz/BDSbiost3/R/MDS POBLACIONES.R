
#toni monleon (5-4-2019) (8-11-2017)


##################################################################################################
# #EXPLORATORY DATA AND MDS, DISCRIMINANT BETWEEN GROUPS
#################################################################################################
#' Exploratory multivariate analysis for frequencies (MDS, MOSAIC plot, Heatmap-cluster): using a Battacharya distance and Kulvart Leivert divergence
#'
#' Function to explore data using MDS and discriminant analysis
#' @param matriu data-set matrix with data containing the metegenomic frequencies
#' @param use.conditions use experimental conditions (levels of a factor)
#' @param perc percentage of sample richness permitted (cuttoff)
#' @param distance  Battachryya distance (BT) by defect; Kulvart Leivert divergence (KL); Jaccard (JC) or bray Curtis distance (JC)
#' @param OTU if OTU = T, matrix of OTUS in the rows, OTU = F matrix of samples in columns
#' @param label.yes microorganism net complexity
#' @param vector.labels parameter
#' @param nrows number of rows at maximum to represent (OTU)
#' @param subgroup.kmeans do a SVD-KMEANS analysis of subgroups
#' @param K number of subgroups at SVD
#' @param vector.labels2 labels for subgroups of columns (samples)
#' @return print of MDS results
#' @export
#' #'
#' @examples
#'library(HMP) #16S rRNA Sequencing Data from the Human Microbiome Proje
#'data(saliva) #saliva metagenomic test (sample vs taxa)
#'library(BDSbiost3)
#'saliva1<- t(data.frame(saliva))
#'
#'#Exploratory analysis based on frequencies and Battacharya distance
#'LinesMDS(matriu=saliva1, use.conditions=F, distance="BT", OTU=T, label.yes=T, vector.labels, nrows=10)
#'
#'#Exploratory analysis based on frequencies and Kullbart-Leiver divergence
#'LinesMDS(matriu=saliva1, use.conditions=F, distance="KL", OTU=T, label.yes=T, vector.labels, nrows=10)
#'
#'#Exploratory analysis in a sparse matrix (computer problems)
#'sparse.matrix<-Simulate.matrix(nfiles = 90, ncols = 100, abun.col = 4)
#'sparse.matrix.emptycols <- sparse.matrix[1:40,]
#'colSums(sparse.matrix.emptycols)
#'LinesMDS(matriu=sparse.matrix.emptycols, use.conditions=F, distance="BC", OTU=T, label.yes=F, vector.labels=rep(1:100, 1), nrows=50)


#' @references
#' CI Rodriguez-Casado, A Monleon-Getino, M Cubedo, M Rios-Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32




#####################################################################################
#####   LinesMDS
#####################################################################################



#Multivariate description of a metgenomic matrix, based on Rodriguez & Monleon(2017)
# using a Battacharya distance or KL
LinesMDS<- function(matriu, use.conditions=F, distance="BT", OTU=T, label.yes=F, vector.labels, nrows=50) {

  library(entropy)
  library(gplots)
  library(gplots)
  library(RColorBrewer)
  library(e1071) #SVM
  require(kohonen)
  require(RColorBrewer)
  library(RCurl)
  library(magrittr)
  library(xgboost)
  library(caret)

  #funcion para la descripcion multivariante y reduccion de la dimension de la matriz
  # ver articulo en el IOS Journal of Mathematics (Rodriguez et al, 2017)

  #Check if matriu is a matrix
  if (is.matrix(matriu)==F){
    matriu<- as.matrix(matriu)
  }
  #nrows es el numero de otus O rows que selecciono
  if(dim(matriu)[1]<10){
    print("Number of matrix rows < 10. Is not possible perform the analysis")
  }

  #Si hay alguna columna que sume 0, no tiene sentido
  if(sum(which(colSums(matriu)==0))>0){
    print("You have empty columns/rows: their dissimilarities may be meaningless in method")
    print("Columns with empty data")
    print(which(colSums(matriu)==0))
    xQuestion <- readline("Would you like to remove empty columns? (Y/N)")
    if(xQuestion=="Y"){
      print("Removed empty columns, columns with 0 sum()")
      matriu = matriu[,colSums(matriu) > 0]
      print("Now your matrix has the columns with > 0 elements:")
      print(colSums(matriu))
    }

  }

  ################## check number of experimental conditions #######################################
  #condition depending on the experimental conditions
  if(use.conditions==F){ #No subgrups/experimental conditions
    n1<-1 #only one class/group
    #change the names of the columns
    #colnames(matriu)<-rep("TOTAL_SAMPLE",dim(matriu)[2])
    vector.labels<-colnames(matriu)
    vector.labels2<-colnames(matriu)
  }
  if(use.conditions==T){ #subgrups/experimental conditions
    n1<-length(levels(factor(vector.labels))) #numero de grupos diferentes
  }

  #labels de las rows: OTU
  labels.rows <- rownames(matriu)

  #class(labels.rows)
  #vector.labels<- vector.labels1
  #parametros de la funci?n: matriu=matriz OTUS X SAMPLES DE FRECUENCIAS 16S, 18S,
  # perc. PARA EL HEATMAP PORCENTAJE DE FREC RELATIVA EN SAMPLES MEDIO QUE SE QUIERE VISUALIZAR

  #varios graficos a la vez
  #par(mfrow=c(2,2))
  #matriu <- t(matriu[,1:100])


  ############ transform count matrix in a percent matrix ###########################################################################
  #se transforma la matriz de contajes a matriz de porcentajes en tanto por uno
  #las filas suman 1 para cada columna
  #funcion que transforma filas a tanto por uno
  Get.matrix.CODA <- function(matriu1) {
    m<-ncol(matriu1) #cols
    n<-nrow(matriu1) #filas
    matriu.CODA<-matrix(0,nrow = n,ncol = m)
    #sum(matriz_mdsHP.1[,2])
    for (i in 1:m){ #col
      for (j in 1:n){ #row
        #print(samp)
        matriu.CODA[j,i]<-as.numeric(matriu1[j,i]/sum(matriu1[,i]))
      }
    }
    #entregable:
    matriu.CODA <<- matriu.CODA
    #sum(matriu.CODA[,3])
  }


  #dim(matriu.CODA)
  #se requiere la matriz de OTUs, OTU in the rows, columns samples
  #if (OTU == T){
  #matriu.ORDERED<-Get.matrix.CODA(matriu)
    #matriu.ORDERED[,1]
    #}

  #SE FILTRA POR NUMERO DE FILAS MAS ABUNDANTES
  #se requiere la matriz de samples, samples in the rows, columns OTU, hay que limitarla a una cantidad nrows
  #if (OTU == F){
    #row.names(matriu) <- list
    DF<- (matriu) #ordenar la matriz por la suma de otus de las filas
    DF<- DF[order(rowSums(DF),decreasing=T),]
    if(nrows > dim(DF)[1]){
      print("Error in DF[1:nrows, ] : subscript out of bounds. Check function parameters and empty data")
      print("Now nrows selected = number of columns/rows")
      nrows <- dim(DF)[1]
    }
    DF <- DF[1:nrows,] #escoger solo unas cuantas otus, nrows primeras

    #fijar las filas que se eligen
    DF1<-(matriu)
    row.names(DF1)<-seq.int(nrow(DF1))
    DF1<- DF1[order(rowSums(DF1),decreasing=T),]
    DF1 <- DF1[1:nrows,] #escoger solo unas cuantas otus, nrows primeras
    elegidas.rows <- as.numeric(row.names(DF1))


    #rowSums(DF)
    #row.names(DF)
    #View(t(DF))
    print("Most abundace rows:-----------------")
    print(row.names(DF))
    print("-------------------------------------")

    matriu.ORDERED<-Get.matrix.CODA(matriu1=t(DF))
    #View(matriu.ORDERED)
    #View(DF)
    #dim(t(DF))
    #dim(matriu.ORDERED)
    #matriu.ORDERED[,1]
    #}

  #library(MASS)
  #write.table(matriu.ORDERED, file = "mat_jf.csv", sep = ",", col.names = NA,
  #            qmethod = "double")

  ###########calculo de la distancia de Battacharya ######################################################################
  if (distance=="BT") {
    #CALCULO DE LA DISTANCIA DE BATTACHARIA MATRICIALMENTE
    # Coeficient de Bhattacharyya (cal escalar les dades entre 0 i 1)
    #class(matriu.ORDERED) #ha de ser una matriz
    Q <- sqrt(matriu.ORDERED)
    BC <- Q%*%t(Q)
    # Dist?ncia de Bhattacharyya (al quadrat)
    BC <- ifelse(BC>1., 1., BC)
    D2B <- acos(BC)
    D2B
    #class(D2B)
    lletra <- "Metric MDS using Battacharyya distance"
  }
  #calculate the dissimilarity of Bray-Curtis & MDS
  #D2B<-vegdist((matriu),method="bray")


  ############################## metrica con la divergencia de Kullback-Leiwer ###########################
  #si se pide divergencia de Kullback-Leiwer
  #See at: https://www.stat.cmu.edu/~cshalizi/754/2006/notes/lecture-28.pdf
  #In probability theory and information theory, the Kullback-Leibler divergence,[1][2] also called information divergence, information gain, relative entropy, KLIC, or KL divergence, is a measure (but not a metric) of the non-symmetric difference between two probability distributions P and Q. The Kullback-Leibler divergence was originally introduced by Solomon Kullback and Richard Leibler in 1951 as the directed divergence between two distributions; Kullback himself preferred the name discrimination information.[3] It is discussed in Kullback's historic text, Information Theory and Statistics.[2]
  #Expressed in the language of Bayesian inference, the Kullback-Leibler divergence from Q to P, denoted DKL(P???Q), is a measure of the information gained when one revises one's beliefs from the prior probability distribution Q to the posterior probability distribution P. In other words, it is the amount of information lost when Q is used to approximate P.[4] In applications, P typically represents the "true" distribution of data, observations, or a precisely calculated theoretical distribution, while Q typically represents a theory, model, description, or approximation of P.
  if (distance=="KL" ) {

      lletra<- "Metric MDS using Kullback-Leiwer divergence"
      #pairwise comparations #############################3
      #calcular la matriz de DIVERGENCIAS de Kullback-Leiwer

      f<-(as.matrix(DF))
      c<-ncol((as.matrix(DF)))
      KL.matrix <- matrix(0, c, c)
      n<-1
      for (i in 1:ncol(f)){
        for (j in n:ncol(f)){
          #i<-1
          #j<-2
          KL.matrix[i,j]<-KL.Dirichlet(f[,i], f[,j], a1=1/10, a2=1/10)
        }
        n= n+1
      }

      #matriz simetrica de distancias
      for (i in 1:ncol(KL.matrix)){
        for (j in 1:ncol(KL.matrix)){
          KL.matrix[j,i]<-KL.matrix[i,j]
        }
      }
      D2B<-KL.matrix
    }

    #Bray curtis distance
    if (distance=="BC" ) {
      library(vegan)
      D2B<-as.matrix(vegdist(t(as.matrix(DF)),method="bray"))
      lletra<- "Metric MDS using Bray-Curtis distance"
    }

    #Jaccard curtis distance
    if (distance=="JC" ) {
      library(vegan)
      D2B<-as.matrix(vegdist(t(as.matrix(DF)),method="jaccard"))
      lletra<- "Metric MDS using Jaccard distance"
    }


  ################## mds #############################################################
  #MAKE THE MDS
  fit.mds <- cmdscale(D2B, eig = TRUE, k = 3)
  x <- fit.mds$points[, 1]
  y <- fit.mds$points[, 2]
  #summary(fit.mds)
  #fit.mds$eig
  eigen <- data.frame(fit.mds$eig, x, y)
  #eigen[266,2:3]

  #VALOR DE LOS COMPONENTES PRINCIPALES (EJES)
  #CRITERIO DE mardia
  print(" ########### MDS RESULTS ##########################")
  #round(sum(fit.mds$eig^2))
  un<-round((100*fit.mds$eig[1]^2)/sum(fit.mds$eig^2),3)
  dos<-round((100*fit.mds$eig[2]^2)/sum(fit.mds$eig^2),3)
  total<-round((100*fit.mds$eig[1]^2 + fit.mds$eig[2]^2)/sum(fit.mds$eig^2),3)
  cat("Mardia criteria: MDS1=", un, "% ,MDS2=", dos, "% ,TOTAL=", total, "%", fill=T, sep=""  )

  #criterio de ls eigenvalues
  #sum(abs(fit.mds$eig))
  un<-round((100*fit.mds$eig[1])/sum(abs(fit.mds$eig)),3)
  dos<-round((100*fit.mds$eig[2])/sum(abs(fit.mds$eig)),3)
  total<-round((100*fit.mds$eig[1] + fit.mds$eig[2])/sum(abs(fit.mds$eig)),3)
  cat("Eigenvalues criteria: MDS1=", un, "% ,MDS2=", dos, "% ,TOTAL=", total, "%", fill=T, sep=""  )

  #plot the MDS with good colors and labels
  #fit.mds$GOF
  plot(x, y,
       xlab=paste("MDS1:",un, "%"), ylab=paste("MDS2:",dos, "%"),
       main=lletra, sub="Rodriguez and Monleon, 2017", col="blue", cex = 1, lty = "solid")
  abline(h=0, v=0)

  if (label.yes==TRUE) {
    text(x, y, labels=vector.labels, cex= 0.6,
         pos=4, col= "black") #samples
  }
  if (label.yes==F) {
    text(x, y, labels=as.factor(vector.labels), cex= 0.6,
         pos=4, col= "black") #samples
  }



  #MULTIVARIATE EXPLORATION
  #HEATMAPS AND KOHONEN MAPS TO EPLORE GROUPS
  if (OTU==T){
      #from https://rpubs.com/crazyhottommy/PCA_MDS
      ## get a gradient of colors for grey, green, red.
      ## one can do better use other libraries such RcolorBrewer. see examples later.
      aa = grep("blue",colors())
      bb = grep("green",colors())
      cc = grep("red",colors())
      gcol2<- colors()[c(aa[1:30],bb[1:20],rep(cc,2))]

      #heatmap
      ## use the genes that drive the first PC1. This is the first major patter in the data
      k=1
      #Selecciono las nrows mC!s abundantes
      ord1<- order(abs(fit.mds$points[,k]),decreasing=TRUE)
      matriu<-data.frame(matriu) #si no se convierte en data frame no funciona la seleccion de las rows
      #x1<- as.matrix(matriu[c(ord1[1:nrows]),])
      x1<- as.matrix(matriu[elegidas.rows,]) #elegir nrows mas abundantes de la matriz original

      #heatmap(x1,col=gcol2)

#toni por aqui 4-7-2019

      #devuelve la matriz seleccionada con nrows mas abundantes
      Selected.nrow.OTUS.Most.abundant <-x1
      #return(Selected.nrow.OTUS.Most.abundant)
      write.table(Selected.nrow.OTUS.Most.abundant, file = "Selected_nrow_OTUS.csv",
                  sep = ",", col.names = NA,
                  qmethod = "double")
      #hacer un analisis de las frecuencias entre muestras
      library("graphics")
      #dev.new(width=5, height=10)

      #MOSAIC PLOT CON LAS NROWS MAS ABUNDANTES
      mosaicplot((x1) , shade = TRUE, las=2,type = 'pearson',
                 main = "MOSAIC - Frequencies: OTUS & samples")
      fm <- loglin(x1, list(1,2),iter = 1000)
      #result of the test
      print("Mosaic test Pearson's chi-squared based on loglin()")
      print(pchisq(fm$pearson, fm$df, lower.tail = FALSE))

      print("Approximate Fisher exact test (simulate.p.value) of the contingency table - in order to test MOSAIC PLOT")
      print("Please be patient. Can be slow - !!!!!!!!!!!!!")
      res.fisher<-fisher.test(x1, simulate.p.value = TRUE, B = 1e4)
      print(res.fisher)

      #super-exact test for multicategorical tables
      #https://cran.r-project.org/web/packages/SuperExactTest/vignettes/set_html.html
      #library(SuperExactTest)
      #data("eqtls")
      #str(cis.eqtls)
      #total=18196
      #res=supertest(as.matrix(x1))
      #plot(res, sort.by="size", margin=c(2,2,2,2), color.scale.pos=c(0.85,1), legend.pos=c(0.9,0.15))
      #summary(res)
      #plot(res, Layout="landscape", degree=2:4, sort.by="size", margin=c(0.5,5,1,2))

      #more heatmaps of the rows (OTUS) and columns (groups)
      #values = matrix(x1, nrow=nrows, dimnames=list(ord1[1:nrows], colnames(matriu)))
      #dev.new(width=5, height=10)
      #heatmap(values)

      #best heatmaps: http://www.molecularecologist.com/2013/08/making-heatmaps-with-r-for-microbiome-analysis/
      #library(gplots)  # for heatmap.2
     # to install packages from Bioconductor:
      #source("http://bioconductor.org/biocLite.R")
      #biocLite("Heatplus")  # annHeatmap or annHeatmap2
      #library(Heatplus)
     # load the RColorBrewer package for better colour options
      #library(RColorBrewer)

      hclustfunc <- function(x) hclust(x, method="complete")
      distfunc <- function(x) dist(x,method="euclidean")

      d <- distfunc((x1))
      fit <- hclustfunc(d)
      clusters <- cutree(fit, h=100)
      nofclust.height <-  length(unique(as.vector(clusters)));

      # Colorings
      hmcols <- rev(bluered(2750))
      selcol <- colorRampPalette(brewer.pal(12,"Set3"))
      selcol2 <- colorRampPalette(brewer.pal(9,"Set1"))
      clustcol.height = selcol2(nofclust.height)

      #otus
      #dev.new(width=5, height=10)
      #Heatmap OTUS
      heatmap.2(as.matrix(((x1))),
                trace='none',
                dendrogram='both',
                key=F,
                Colv=T,
                scale='col',
                hclust=hclustfunc, distfun=distfunc, col=hmcols,
                symbreak=T,
                margins=c(7,10), keysize=0.1,
                lwid=c(5,0.5,3), lhei=c(0.05,0.5),
                lmat=rbind(c(5,0,4),c(3,1,2)),
                labRow=rownames(((x1))),
                #ColSideColors=c(1,1,3,1,1,1,1,8,9,1,1),  # This line doesn't work
                RowSideColors=clustcol.height[clusters])
                #title(main = "HEATMAP OTUS")

                #samples:
                #dev.new(width=5, height=10)

                #Plot HEATMAP
                heatmap.2(as.matrix(t(x1)),
                trace='none',
                dendrogram='both',
                key=F,
                Colv=T,
                scale='col',
                hclust=hclustfunc, distfun=distfunc, col=hmcols,
                symbreak=T,
                margins=c(7,10), keysize=0.1,
                lwid=c(5,0.5,3), lhei=c(0.05,0.5),
                lmat=rbind(c(5,0,4),c(3,1,2)),
                #labRow=vector.labels2, #rownames(t(x1)),
                labRow=rownames(t(x1)),
                #ColSideColors=c(1,1,3,1,1,1,1,8,9,1,1),  # This line doesn't work
                RowSideColors=clustcol.height[clusters])
                #title(main = "HEATMAP SUB-GROUPS")

      #RowSideColors = c(    # grouping row-variables into different
      #rep("gray", 3),   # categories, Measurement 1-3: green
      #rep("blue", 3),    # Measurement 4-6: blue
      #rep("black", 4)))    # Measurement 7-10: red

      #par(lend = 1)           # square line ends for the color legend
      #legend("topright",      # location of the legend on the heatmap plot
      #legend = c("category1", "category2", "category3"), # category labels
      #col = c("gray", "blue", "black"),  # color key
      #lty= 1,             # line style
      #lwd = 10   )         # line width


      #MACHINE LEARNING MAPS - COM
      #The Self-Organizing Maps (SOMs) network is a neural network based method for dimension reduction.
      ##som_model <- som(scale(Selected.nrow.OTUS.Most.abundant), grid = somgrid(6, 3, "rectangular"))
      #plot(NBA.SOM1)
      #som_model <- som(scale(Selected.nrow.OTUS.Most.abundant),
      #                 grid=somgrid(10, 10, "hexagonal"),
      #                 rlen=100,
      #                 alpha=c(0.05),
      #                 keep.data = TRUE)

      #plot machine learning maps
      #dev.new(width=5, height=10)
      ##plot(som_model, type="dist.neighbours",main = "ML SOMs NETWORK")
      #plot(som_model, type="codes")

      #OTRO TIPO DE MAPA DE GRUPOS
      #groups = 4
      #iris.hc = cutree(hclust(dist(Selected.nrow.OTUS.Most.abundant)), groups)
      #dev.new(width=5, height=10)

      #plot cutree
      #plot(som_model, type="codes", bgcol=rainbow(groups)[iris.hc])
      #cluster boundaries
      #add.cluster.boundaries(som_model, iris.hc)

  }





}







